--
-- PostgreSQL database dump
--

\restrict vVfY2LDKcZ1g6bLSzD8vqJVXDvQASrHS0NeHGcUEGbJtqJocN0TieLeFV81WlIt

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: partykind; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.partykind AS ENUM (
    'partner',
    'capper'
);


ALTER TYPE public.partykind OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_websites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_websites (
    id integer NOT NULL,
    account_id integer NOT NULL,
    website character varying(255) NOT NULL
);


ALTER TABLE public.account_websites OWNER TO postgres;

--
-- Name: account_websites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_websites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.account_websites_id_seq OWNER TO postgres;

--
-- Name: account_websites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_websites_id_seq OWNED BY public.account_websites.id;


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    username character varying(255),
    password_enc text,
    balance numeric(14,2),
    max_win numeric(14,2),
    city character varying(255),
    created_at timestamp with time zone NOT NULL,
    balance_text character varying(100),
    max_win_text character varying(100)
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounts_id_seq OWNER TO postgres;

--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: admin_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_credentials (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    CONSTRAINT single_admin CHECK ((id = 1))
);


ALTER TABLE public.admin_credentials OWNER TO postgres;

--
-- Name: figures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.figures (
    id integer NOT NULL,
    party_id integer NOT NULL,
    account_id integer NOT NULL,
    figure numeric(14,2) NOT NULL,
    figure_date date NOT NULL,
    start_date date,
    end_date date,
    entered_by integer,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.figures OWNER TO postgres;

--
-- Name: figures_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.figures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.figures_id_seq OWNER TO postgres;

--
-- Name: figures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.figures_id_seq OWNED BY public.figures.id;


--
-- Name: parties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parties (
    id integer NOT NULL,
    kind public.partykind NOT NULL,
    name character varying(255) NOT NULL,
    name_key character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.parties OWNER TO postgres;

--
-- Name: parties_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parties_id_seq OWNER TO postgres;

--
-- Name: parties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parties_id_seq OWNED BY public.parties.id;


--
-- Name: party_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.party_accounts (
    id integer NOT NULL,
    party_id integer NOT NULL,
    account_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.party_accounts OWNER TO postgres;

--
-- Name: party_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.party_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.party_accounts_id_seq OWNER TO postgres;

--
-- Name: party_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.party_accounts_id_seq OWNED BY public.party_accounts.id;


--
-- Name: site_figures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.site_figures (
    id integer NOT NULL,
    account_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    site_figure numeric(14,2) NOT NULL,
    calculated_by integer,
    calculated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.site_figures OWNER TO postgres;

--
-- Name: site_figures_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.site_figures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.site_figures_id_seq OWNER TO postgres;

--
-- Name: site_figures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.site_figures_id_seq OWNED BY public.site_figures.id;


--
-- Name: account_websites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_websites ALTER COLUMN id SET DEFAULT nextval('public.account_websites_id_seq'::regclass);


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: figures id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.figures ALTER COLUMN id SET DEFAULT nextval('public.figures_id_seq'::regclass);


--
-- Name: parties id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parties ALTER COLUMN id SET DEFAULT nextval('public.parties_id_seq'::regclass);


--
-- Name: party_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.party_accounts ALTER COLUMN id SET DEFAULT nextval('public.party_accounts_id_seq'::regclass);


--
-- Name: site_figures id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_figures ALTER COLUMN id SET DEFAULT nextval('public.site_figures_id_seq'::regclass);


--
-- Data for Name: account_websites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_websites (id, account_id, website) FROM stdin;
28	28	Bestbets.vip
29	29	Bestbets.vip
30	30	Bestbets.vip
31	31	Bestbets.vip
32	32	Bestbets.vip
33	33	Bestbets.vip
34	34	Bestbets.vip
35	35	Bestbets.vip
36	36	Bestbets.vip
37	37	Bestbets.vip
38	38	Bestbets.vip
39	39	Bestbets.vip
45	45	Bestbets.vip
46	46	Bestbets.vip
47	47	Bestbets.vip
48	48	Playbetnow.com
49	49	betwindycity.com
50	50	Bettingzoo.com
51	51	Sunwager.com
52	52	elitesports.now
53	53	elitesports.now
54	54	Crazywager247.com
55	55	Hsb55.com
56	56	Bluecoins.ag
57	57	Betbigcity.ag
58	58	overtime.ag
59	59	Platinumsportz.com
60	60	trylnk.com
61	61	333locks.com
62	62	Actionbets.ag
63	63	vip365.ag
64	64	vip365.ag
65	65	purewage.com
66	66	wagerhouse.ag
67	67	nextplay24.com
68	68	Wagershack.com
69	69	empire.ag
70	70	Loxandspreads.com
71	71	Jwsportsinfo.com
72	72	Loxandspreads.com
73	73	betbuckeyesports.com
74	74	slick247.com
75	75	goldbook.ag
76	76	Bestbets.vip
77	77	Bestbets.vip
78	78	Bestbets.vip
79	79	Bestbets.vip
80	80	Bestbets.vip
81	81	gameday777.com
82	82	Bone.ag
83	83	Playbetnow.com
84	84	Sunwager.com
85	85	sportingnews.life
86	86	Bestbets.vip
87	87	Play23.ag
88	88	rizzbets.ag
89	89	Probooknyc.com
90	90	Betfastaction.ag
91	91	Rum88.com
92	92	betvip247.net
93	93	anybet365.com
94	94	Ez3388.ag
95	95	Ez3388.ag
96	96	Ez3388.ag
97	97	win88.ag
98	98	play23.ag
99	99	sonic66.com
100	100	be77.net
101	101	Betfan88.com
102	102	gameon39.com
103	103	Pis.ag
104	104	pick7s.com
105	105	pick7s.com
106	106	pick7s.com
107	107	pick7s.com
108	108	Pick7s.com
109	109	Pick7s.com
110	110	gameon39.com
111	111	Abcodds.com
112	112	Tigertd.com
113	113	Tigertd.com
114	114	win88.ag
115	115	bettingzoo.ag
116	116	369bets.com
117	117	369bets.com
118	118	369bets.com
119	119	369bets.com
120	120	369bets.com
121	121	Phobolsa39.com
122	122	livebet88.eu
123	123	livebet88.eu
124	124	livebet88.eu
125	125	black702.com
126	126	diamondsb.com
127	127	diamondsb.com
128	128	diamondsb.com
129	129	diamondsb.com
130	130	diamondsb.com
131	131	diamondsb.com
132	132	diamondsb.com
133	133	diamondsb.com
134	134	diamondsb.com
135	135	diamondsb.com
136	136	diamondsb.com
137	137	diamondsb.com
138	138	diamondsb.com
139	139	diamondsb.com
140	140	diamondsb.com
141	141	diamondsb.com
142	142	diamondsb.com
143	143	diamondsb.com
144	144	diamondsb.com
145	145	ezplay247.com
146	146	ezplay247.com
147	147	ezplay247.com
148	148	ezplay247.com
149	149	ezplay247.com
150	150	ezplay247.com
151	151	ezplay247.com
152	152	ezplay247.com
153	153	ezplay247.com
154	154	ezplay247.com
155	155	ezplay247.com
156	156	ezplay247.com
161	161	leftcoast797.com
166	166	Smash66.com
171	171	Liveactionbets.com
157	157	ezplay247.com
162	162	leftcoast797.com
167	167	5racks.com
158	158	leftcoast797.com
163	163	leftcoast797.com
168	168	5racks.com
159	159	leftcoast797.com
164	164	leftcoast797.com
169	169	5racks.com
160	160	leftcoast797.com
165	165	leftcoast797.com
170	170	5racks.com
172	172	Picks25.com
173	173	Picks25.com
174	174	Picks25.com
175	175	diamondsb.com
176	176	trylnk.com
177	177	333locks.com
178	178	Overtime.ag
179	179	Skullbet.com
180	180	Picks25.com
181	181	wcsports1.com
182	182	Diamondsb.com
183	183	Diamondsb.com
184	184	ezplay247.com
185	185	Leftcoast797.com
186	186	Leftcoast797.com
187	187	Aceshigh.ag
188	188	Bone.ag
189	189	Bone.ag
190	190	vip365.ag
191	191	bluebird00.com
192	192	goldbook.ag
193	193	8plays.com
194	194	play305.com
195	195	thewagerguys.com
196	196	yoursportsbetting.com
197	197	5starwagerz.com
198	198	Winwager.eu
199	199	betvegas777.com
200	200	Play23.ag
201	201	Betfastaction.ag
202	202	Vip365.ag
203	203	Wagershack.com
204	204	Sweatcity.ag
205	205	action527.com
206	206	EC-Investor.com
207	207	legacy365.net
208	208	legacy365.net
209	209	actionbets.com
210	210	Sportscappers.io
211	211	Sportscappers.io
212	212	Sportscappers.io
213	213	Sportscappers.io
214	214	Thevault.ag
215	215	woopig.io
216	216	Sportscappers.io
217	217	Sportscappers.io
218	218	Sundaytilt.com
219	219	888east.com
220	220	Wagerpalace.ag
221	221	BESTBETS.VIP
222	222	red409.com
223	223	red409.com
224	224	Bestbets.vip
225	225	Bestbets.vip
226	226	Bestbets.vip
227	227	Bestbets.vip
228	228	Aceshigh.ag
229	229	Aceshigh.ag
230	230	Aceshigh.ag
231	231	Aceshigh.ag
232	232	Aceshigh.ag
233	233	cherrybet.ag
234	234	aceshigh.ag
235	235	gobetya.net
236	236	Square999.com
237	237	Square999.com
238	238	betnow187.com
239	239	Ec-investor.com
240	240	dragon17.com
241	241	texas55.com
242	242	texas55.com
243	243	texas55.com
244	244	sportscappers.io
245	245	Bettingzoo.ag
246	246	Sunwager.com
247	247	Sunwager.com
248	248	Sportsmans-lounge.com
249	249	Sportsmans-lounge.com
250	250	Sportsmans-lounge.com
251	251	Sportsmans-lounge.com
252	252	Sonic66.com
253	253	Buzzerbeater.ag
254	254	Sun22.ag
255	255	Square999.com
256	256	Crashsb.com
257	257	Axenlight.com
258	258	Axenlight.com
259	259	fantasy702.com
260	260	333locks.com
261	261	actionpro.io
262	262	Betempire.ag
263	263	play23.ag
264	264	betselite.com
265	265	betselite.com
266	266	luckypanda.ag
267	267	play47.com
268	268	Green909.com
269	269	betallstar.ag
270	270	betallstar.ag
271	271	mks888.com
272	272	eag.ag
273	273	eag.ag
274	274	gameday.ag
275	275	blitzbet.io
276	276	elitesports.now
277	277	c2cbets.ag
278	278	c2cbets.ag
279	279	247lines.com
280	280	Betemnow.com
281	281	Betemnow.com
282	282	Platinumsportz.com
283	283	Maxplay.ag
284	284	Onemorebet.com
285	285	Bet888.ag
286	286	Housesports77.com
287	287	Play23.live
288	288	Fastaction88.com
289	289	Yopig.ag
290	290	Spwagers.com
291	291	77silver.com
292	292	77silver.com
293	293	Lonestar28.com
294	294	Lonestar28.com
295	295	Lonestar28.com
296	296	Lonestar28.com
297	297	Fire22.com
298	298	Fire22.com
299	299	elitesports.now
300	300	Betsafe777.net
301	301	Red409.com
302	302	Rum88.com
303	303	Rum88.com
304	304	Rum88.com
305	305	Rum88.com
306	306	Sunwager.com
307	307	Sunwager.com
308	308	Sunwager.com
309	309	Sunwager.com
310	310	Sunwager.com
311	311	Sunwager.com
312	312	Sunwager.com
313	313	Sunwager.com
314	314	Sunwager.com
315	315	Sunwager.com
316	316	Sunwager.com
317	317	Sunwager.com
318	318	Sunwager.com
319	319	Sunwager.com
320	320	Sunwager.com
321	321	Sunwager.com
322	322	Sunwager.com
323	323	Hsb55.com
328	328	Queenofspades.live
333	333	Solidout360.com
338	338	betfastaction.ag
343	343	Fire22.com
348	348	Lionwager.com
353	353	Highrollers409.com
358	358	Tigertd.com
363	363	Bombay711.com
368	368	Goldbook.ag
373	373	Goldbook.ag
378	378	Sunwager.com
383	383	Bettingzoo.ag
388	388	Bettingzoo.ag
393	393	Odds2wager.com
398	398	Bombay711.com
403	403	betcatalinasports.com
408	408	Bettingzoo.ag
413	413	Rum88.com
418	418	Rum88.com
423	423	housesports77.com
428	428	ibet.ag
433	433	Bettorlock.com
438	438	Goldbook.ag
443	443	Sunwager.com
448	448	Sunwager.com
453	453	Sunwager.com
458	458	Sunwager.com
463	463	Lonestar28.com
468	468	Red409.com
473	473	Betplayboys.ag
478	478	Bettingzoo.ag
483	483	Lionwager.com
488	488	Lionwager.com
493	493	2bettvs.com
498	498	eag.ag
503	503	Rygbyrex.com
508	508	Bombay711.com
513	513	Highrollers409.com
518	518	xpressplays.com
523	523	Odds2wager.com
528	528	playcr.ag
533	533	Phoenix22.com
538	538	77silver.com
543	543	diamondsb.ag
548	548	Mastermindbets.com
553	553	Outtaspaceplays.com
558	558	action247.ag
563	563	Bettingzoo.ag
324	324	Hsb55.com
329	329	falcon.ag
334	334	2x2wagers.com
339	339	Fire22.com
344	344	Lionwager.com
349	349	Lionwager.com
354	354	Xutu.ag
359	359	Tigertd.com
364	364	Goldbook.ag
369	369	Goldbook.ag
374	374	Goldbook.ag
379	379	Sunwager.com
384	384	Bettingzoo.ag
389	389	Spwagers.com
394	394	Bombay711.com
399	399	gameday.ag
404	404	bettingzoo.ag
409	409	Bettingzoo.ag
414	414	Rum88.com
419	419	Rum88.com
424	424	ezplay247.com
429	429	playnow365.com
434	434	tigertd.com
439	439	Sunwager.com
444	444	Sunwager.com
449	449	Sunwager.com
454	454	Sunwager.com
459	459	Sunwager.com
464	464	Lonestar28.com
469	469	Red409.com
474	474	betsoffshore.io
479	479	77silver.com
484	484	Lionwager.com
489	489	Betthechamp.com
494	494	vaultwagers.com
499	499	Betvegas777.com
504	504	silver707.com
509	509	Wagershack.com
514	514	Superbook888.com
519	519	Betvipsports.com
524	524	Bluecoins.ag
529	529	333locks.com
534	534	Bigwave99.com
539	539	77silver.com
544	544	betvegas23.ag
549	549	betwar.com
554	554	blackpointsb.com
559	559	Square999.com
564	564	dontbackupstackup.com
325	325	Black99.net
330	330	Crazywager247.com
335	335	2x2wagers.com
340	340	Fire22.com
345	345	Lionwager.com
350	350	Lionwager.com
355	355	Xutu.ag
360	360	Tigertd.com
365	365	Goldbook.ag
370	370	Goldbook.ag
375	375	Goldbook.ag
380	380	Sunwager.com
385	385	Bettingzoo.ag
390	390	Saber77.com
395	395	Bombay711.com
400	400	betcatalinasports.com
405	405	bettingzoo.ag
410	410	Betemnow.com
415	415	Rum88.com
420	420	Crazywager247.com
425	425	Monkeywager.com
430	430	playnow365.com
435	435	Bettingzoo.ag
440	440	Sunwager.com
445	445	Sunwager.com
450	450	Sunwager.com
455	455	Bombay711.com
460	460	Sunwager.com
465	465	Lonestar28.com
470	470	Goldbook.ag
475	475	Bettingzoo.ag
480	480	Fire22.com
485	485	Lionwager.com
490	490	Betthechamp.com
495	495	blue42.pro
500	500	Betvegas23.com
505	505	Bombay711.com
510	510	Riskthefarm.com
515	515	Spwagers.com
520	520	Sbplay.com
525	525	maxplay.ag
530	530	333locks.com
535	535	Steam22.com
540	540	Rum88.com
545	545	betfastaction.ag
550	550	2x2wagers.com
555	555	77silver.com
560	560	Falcon.ag
326	326	Platinumsportz.com
331	331	Crazywager247.com
336	336	2x2wagers.com
341	341	Fire22.com
346	346	23platinum.com
351	351	Lionwager.com
356	356	Xutu.ag
361	361	Wagershack.com
366	366	Goldbook.ag
371	371	Goldbook.ag
376	376	probet365.co
381	381	Sunwager.com
386	386	Bettingzoo.ag
391	391	Properbets.io
396	396	Bombay711.com
401	401	betcatalinasports.com
406	406	Bettingzoo.ag
411	411	Lionwager.com
416	416	Rum88.com
421	421	Crazywager247.com
426	426	wagersus5.com
431	431	pgwsports.com
436	436	Bettingzoo.ag
441	441	Sunwager.com
446	446	Sunwager.com
451	451	Sunwager.com
456	456	Sunwager.com
461	461	Sunwager.com
466	466	Lonestar28.com
471	471	Blue678.com
476	476	Bettingzoo.ag
481	481	Fire22.com
486	486	Lionwager.com
491	491	Betthechamp.com
496	496	black99.net
501	501	Betvegas23.com
506	506	Bombay711.com
511	511	Rukes42.com
516	516	Spwagers.com
521	521	ezplay247.com
526	526	ocbet.ag
531	531	333locks.com
536	536	black88.vip
541	541	Rum88.com
546	546	betfastaction.ag
551	551	Playbig777.com
556	556	77silver.com
561	561	Livewager247.com
327	327	Coinaction.ag
332	332	Lion44.com
337	337	betfastaction.ag
342	342	Fire22.com
347	347	Lionwager.com
352	352	Lionwager.com
357	357	Tigertd.com
362	362	Bombay711.com
367	367	Goldbook.ag
372	372	Goldbook.ag
377	377	Betbuckeyesports.com
382	382	Sunwager.com
387	387	Bettingzoo.ag
392	392	Sportsplay2.com
397	397	Bombay711.com
402	402	betcatalinasports.com
407	407	Bettingzoo.ag
412	412	Lionwager.com
417	417	Rum88.com
422	422	Crazywager247.com
427	427	Maxplay.ag
432	432	Wisewager13.com
437	437	Goldbook.ag
442	442	Sunwager.com
447	447	Sunwager.com
452	452	Sunwager.com
457	457	Sunwager.com
462	462	Lonestar28.com
467	467	Lonestar28.com
472	472	Goldbook.ag
477	477	Bettingzoo.ag
482	482	Lionwager.com
487	487	Lionwager.com
492	492	Betthechamp.com
497	497	eag.ag
502	502	Betvegas23.com
507	507	Bombay711.com
512	512	c2cbets.ag
517	517	Spwagers.com
522	522	primeplays53.com
527	527	Mvpqb.com
532	532	onemorebet.com
537	537	ocbet.ag
542	542	Rum88.com
547	547	readyforgamble.com
552	552	2x2wagers.com
557	557	action247.ag
562	562	sonic66.com
565	565	28outs.com
566	566	Aceshigh.ag
567	567	Tigertd.com
568	568	Square999.com
569	569	Square999.com
570	570	Platinumsportz.com
571	571	bojump.com
572	572	EAG.AG
573	573	betthechamp.com
574	574	2betesi.com
575	575	Snow77.com
576	576	Rocket29.com
577	577	Vigsweep.com
578	578	Bigdog247.com
579	579	Lonestarwagering.com
580	580	Spikebet.com
581	581	2bet.ag
582	582	monkeywager.com
583	583	betme333.com
584	584	Fantasy702.com
585	585	Square999.com
586	586	gobetya.net
587	587	betvegas23.com
588	588	bigdog247.com
589	589	cobra55.com
590	590	Gameday.ag
591	591	gameday777.com
592	592	Sunwager.com
593	593	Blanco123.com
594	594	Snow77.com
595	595	Snow77.com
596	596	Phoenix22.com
597	597	Blackpointsb.com
598	598	Gamehaven247.com
599	599	betwar.ag
600	600	Square999.com
601	601	Probet42.com
602	602	thevault.ag
603	603	kingdomsports43.com
604	604	Aceshigh.ag
605	605	333locks.com
606	606	dog234.com
607	607	Wrigley22.com
608	608	hw999.org
609	609	sharp77.net
610	610	trylnk.com
611	611	Luckysides247.com
612	612	thewagerguys.com
613	613	ocbet.ag
614	614	ocbet.ag
615	615	Diamondsb.ag
616	616	betvegas23.com
617	617	wcsports1.com
618	618	Red409.com
619	619	thewagerguys.com
620	620	sunwager.com
621	621	Betsincity.com
622	622	Winningwagers.eu
623	623	Winningwagers.eu
624	624	Winningwagers.eu
625	625	Sportsbets.ag
626	626	betny.ag
627	627	Bestbets.vip
628	628	Bestbets.vip
629	629	Bestbets.vip
630	630	sunwager.com
631	631	Wagertheboard.com
632	632	Luckywager777.com
633	633	Wisewager13.com
634	634	Wisewager13.com
635	635	Wisewager13.com
636	636	Square999.com
637	637	wagershack.com
638	638	Betcapri.com
639	639	Aceshigh.ag
640	640	playcr.ag
641	641	Playwager.ag
642	642	Snow77.com
643	643	playbetnow.com
644	644	Betallstar.ag
645	645	Betallstar.ag
646	646	wagerlodge.com
647	647	Gameday.ag
648	648	bet1234.com
649	649	nojuice.ag
650	650	nojuice.ag
651	651	Diamondsb.com
652	652	Diamondsb.com
653	653	Diamondsb.com
654	654	Anybet365.com
655	655	Anybet365.com
656	656	Anybet365.com
657	657	Anybet365.com
658	658	Anybet365.com
659	659	Anybet365.com
660	660	Anybet365.com
661	661	Anybet365.com
662	662	Anybet365.com
663	663	spwagers.com
664	664	spwagers.com
665	665	bettingzoo.ag
666	666	Steam22.com
667	667	Steam22.com
668	668	Wrigley22.com
669	669	Whq.ag
670	670	Whq.ag
671	671	Rum88.com
672	672	Overtime.ag
673	673	be77.net
674	674	Bombay711.com
675	675	Bluecoins.ag
676	676	Redzone247.com
677	677	Openforaction.com
678	678	Steam22.com
679	679	Vip365.ag
680	680	trylnk.com
681	681	Red409.com
682	682	Red409.com
683	683	Zzr888.com
684	684	Anybet365.com
685	685	Vodka77.com
686	686	Betfan88.com
687	687	rukes42.com
688	688	rukes42.com
689	689	sunwager.com
690	690	Allweeksports.com
691	691	Bluecoins.ag
692	692	betonit.ag
693	693	wisewager13.com
694	694	Bestbets.vip
695	695	Housesports77.com
696	696	333locks.com
697	697	HSB55.COM
698	698	sportingnews.life
699	699	Gameday777.com
700	700	wagerpalace.ag
701	701	ebet2.com
702	702	Primepicks.ag
703	703	Buzzerbeater.ag
704	704	beatthelines.ag
705	705	Action23.ag
706	706	Nukebets.com
707	707	Locksandspreads.com
708	708	betvegas23.com
709	709	Betallweek.com
710	710	Bestbets.vip
711	711	Bestbets.vip
712	712	Bestbets.vip
713	713	Bestbets.vip
714	714	1absolutewager.com
715	715	bet23.ag
716	716	bet23.ag
717	717	Blue42.pro
718	718	kingofsports247.com
719	719	whq.ag
720	720	duster365.com
721	721	m.dog234.com
722	722	Diamondsb.com
723	723	2x2wagers.com
724	724	Gameday777.com
725	725	Gamehaven247.com
726	726	Bohica.ag
727	727	Bohica.ag
728	728	Luckysp.com
729	729	Tigertd.com
730	730	Bettingzoo.ag
731	731	betpacificsports.com
732	732	Alamo88.ag
733	733	sweetwatersports.com
734	734	betme333.com
735	735	Wagershack.com
736	736	Gameday777.com
737	737	Steam22.com
738	738	Sunwager.com
739	739	Sunwager.com
740	740	333black.com
741	741	333black.com
742	742	95blue.com
743	743	redzone.wtf
744	744	bettexas.net
745	745	Betdallas.com
746	746	Sunwager.com
747	747	Sunwager.com
748	748	Sunwager.com
749	749	Betvegas23.com
750	750	Betvegas23.com
751	751	Fwcsport.com
752	752	betab325.com
753	753	crazywager247.com
754	754	bestbet365.vip
755	755	proleagues365.com
756	756	linescenter.com
757	757	Mks888.com
758	758	Mks888.com
759	759	Just4bettors.com
760	760	ats365.com
761	761	betvegas23.com
762	762	thehotplay.com
763	763	bong868.com
764	764	10stack.com
765	765	10stack.com
766	766	333black.com
767	767	333black.com
768	768	333black.com
769	769	333black.com
770	770	Sunwager.com
771	771	Sunwager.com
772	772	tdsports.com
773	773	Cougar713.com
774	774	Cougar713.com
775	775	Goldbook.ag
776	776	bigdog247.com
777	777	bigdog247.com
778	778	Snow77.com
779	779	Snow77.com
780	780	Snow77.com
781	781	Snow77.com
782	782	333black.com
783	783	333black.com
784	784	Crownsports.bet
785	785	pig11.com
786	786	eag.ag
787	787	2bet.ag
788	788	2bet.ag
789	789	Just4bettors.com
790	790	Playlt365.com
791	791	Playlt365.com
792	792	betorigin.com
793	793	luckylion247.com
794	794	Ezplay2001.com
795	795	Sunwager.com
796	796	Cover2sports.net
797	797	palmpicks.com
798	798	Coverthefield27.com
799	799	vaultwagers.com
800	800	strikerdot.com
801	801	Strikerich.ag
802	802	Wagershack.com
803	803	betorigin.com
804	804	Betolive.ag
805	805	Yo11pro.com
806	806	nojuice.ag
807	807	blue42.biz
808	808	strikerich.ag
809	809	stikerdot.com
810	810	coverthefield27.com
811	811	crazywager247.com
812	812	betorigin.com
813	813	status.games
814	814	Loxandspreads.com
815	815	trylnk.com
816	816	Bluestartbets.com
817	817	betorigin.com
818	818	loxandspreads.com
819	819	Yo11pro.com
820	820	Trylnk.com
821	821	Gameday777.com
822	822	Bettingzoo.ag
823	823	bettordays.ag
824	824	bettordays.ag
825	825	bettordays.ag
830	830	Dailysports365.com
835	835	coverthefield27.com
840	840	strikerdot.com
845	845	whq.ag
850	850	Allgames365.com
858	858	Yo11pro.com
861	861	pig11.com
866	866	sunwager.com
871	871	Playsports247.com
876	876	Strikerdot.com
879	879	Just4bettors.com
888	888	placebets365.com
890	890	trylnk.com
892	892	1absolutewager.com
895	895	trylnk.com
900	900	Supremepicks.com
902	902	Red105.com
904	904	Bulldog888.com
908	908	Panda77.com
913	913	Sportsplay2.com
918	918	pig11.com
923	923	red409.com
928	928	247lines.com
933	933	Sunwager.com
938	938	4cents.asia
943	943	tigertd.com
948	948	bettingzoo.ag
953	953	Diamondsb.com
958	958	Diamondsb.com
963	963	Odds.ag
826	826	bettordays.ag
828	828	betorigin.com
833	833	gameday777.com
838	838	pig11.net
843	843	Sunwager.com
848	848	thunderwager.com
853	853	Bestbets.vip
855	855	Topset9.com
859	859	just4bettors.com
864	864	rugbyrex.com
869	869	Cobra55.com
874	874	Blue808.com
877	877	sunwager.com
880	880	Just4bettors.com
884	884	Sunwager.com
891	891	1absolutewager.com
894	894	trylnk.com
899	899	southernstarsports.com
901	901	Rover22.com
907	907	wagerhouse.ag
912	912	Red409.com
917	917	sundaysweats.ag
922	922	Rum88.com
927	927	Sonic66.com
932	932	Sunwager.com
937	937	Sonic66.com
942	942	leftcoast797.com
947	947	369bets.com
952	952	ezplay247.com
957	957	Diamondsb.com
962	962	Thewagerguys.com
967	967	bettingzoo.com
827	827	bettordays.ag
829	829	Coverthefield27.com
834	834	Sunwager.com
839	839	betolive.ag
844	844	007wagers.com
849	849	vip365.ag
854	854	Bestbets.vip
856	856	placebets365.com
857	857	Gameday777.com
860	860	sunsetsportsclub.com
865	865	2bet888.com
870	870	coverthefield27.com
875	875	Hotwajer.com
883	883	dog234.com
887	887	vodka55.com
889	889	Kettleplays.com
896	896	trylnk.com
903	903	Rover22.com
905	905	trylnk.com
909	909	Sunwager.com
914	914	infosports19.com
919	919	ray44.com
924	924	red409.com
929	929	Bettingzoo.ag
934	934	Gameday777.com
939	939	38ways.win
944	944	blackhawk77.com
949	949	Bling99.com
954	954	Diamondsb.com
959	959	Diamondsb.com
964	964	1bettor.com
831	831	loxandspreads.com
836	836	Yo11pro.com
841	841	Outtaspaceplays.com
846	846	Crazywager247.com
851	851	play03.net
862	862	sports38.com
867	867	Betselite.com
872	872	Betorigin.com
878	878	ace23.ag
881	881	playlt365.com
885	885	Red105.com
893	893	Lvaction.com
898	898	Placebets365.com
911	911	pgwsports.com
916	916	steam22.com
921	921	Bettingzoo.ag
926	926	Sonic66.com
931	931	Sunwager.com
936	936	Wisewager13.com
941	941	ezplay247.com
946	946	black702.com
951	951	ezplay247.com
956	956	Diamondsb.com
961	961	2x2wagers.com
966	966	bookiebarn.com
832	832	betselite.com
837	837	Betorigin.com
842	842	Sunwager.com
847	847	bettordays.ag
852	852	B21.ag
863	863	sports38.com
868	868	Sportsedge247.com
873	873	Gameday777.com
882	882	Redorange333.com
886	886	2bet.ag
897	897	Placebets365.com
906	906	Gamehaven247.com
910	910	betemnow.com
915	915	Fire22.com
920	920	tigertd.com
925	925	red409.com
930	930	Sportsplay2.com
935	935	betthechamp.com
940	940	Gameon39.com
945	945	sunwager.com
950	950	Bling99.com
955	955	Diamondsb.com
960	960	Bet888.ag
965	965	Crazywager247.com
968	968	overtime.ag
969	969	Aceshigh.ag
970	970	5racks.com
971	971	Diamondsb.com
972	972	Diamonds.ag
973	973	bone.ag
974	974	bone.ag
975	975	bone.ag
976	976	bone.ag
977	977	bestbets.vip
978	978	Spwagers.com
979	979	77silver.com
980	980	sportszone1.com
981	981	Lonestar28.com
982	982	4sfold.com
983	983	primetime100.com
984	984	primetime100.com
985	985	primetime100.com
986	986	primetime100.com
987	987	wagerus.ag
988	988	Probooknyc.com
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, username, password_enc, balance, max_win, city, created_at, balance_text, max_win_text) FROM stdin;
28	Bc152	gAAAAABqzhr5UnL9L-_lVHiUfWWZG0BOFt0wAOoAqUKlWbt9RnGEvvDYowvsZeyni_rAH1GUIt93NixXDVr5nzWQDeWh3uVivw==	25000.00	\N	\N	2026-10-13 17:20:17.078099+05:30	\N	\N
29	Bc163	gAAAAABqzhr5nquvoMmt0rf5Ibypw7CY-e_HYQ9MBcBsjgv_jmfP_ts0GVDNiV6WE_z6IvzNEnkNkdk61_Kmt0Hp-ONzsDZ22w==	25000.00	\N	\N	2026-10-13 17:20:17.091897+05:30	\N	\N
30	Bc164	gAAAAABqzhr5DOWyNTr3BYMAZJzzWC6etGrC4BOXeb1tgJR5Jifpb1keYbVEivbtFIybH4g2bQW0aWM77AoAClxvDDuhh3K7XQ==	25000.00	\N	\N	2026-10-13 17:20:17.104956+05:30	\N	\N
31	Bc165	gAAAAABqzhr5D9XEYN_dEbpQpKEP9yureXkMZwFZRIn6GI_hmbVJe19MKww9vPiFObpD9HamftCBz26Zq7x3sJL_Vsazf86VnA==	25000.00	\N	\N	2026-10-13 17:20:17.117949+05:30	\N	\N
32	Bc166	gAAAAABqzhr5SY7f5kfKYNADNWSOHoBI0onjPCO5_ZR8EkBmRMpvpbVz5-kHpvG20vq3RrjPj7JjV1uqCfSpL72mCL8en29UzA==	25000.00	\N	\N	2026-10-13 17:20:17.130237+05:30	\N	\N
33	Bc167	gAAAAABqzhr5Jiz3znU8V1kYHXC_7kAH1Nz_wuLmGLiK-Mmgmd_oNAueXrjmAaLXjk2qXmyknpFUX7rlFPC2aUCFbPVbJY1IFw==	25000.00	\N	\N	2026-10-13 17:20:17.144974+05:30	\N	\N
34	Bc168	gAAAAABqzhr5ryUehv6MMpZ8Z8K2He7GdUeyoS7RNjHKcDIMWmHikvqXVb2gH7P_05qvVy4mT7eT24yBIuYA5hwF1wO9TOnf7A==	25000.00	\N	\N	2026-10-13 17:20:17.159256+05:30	\N	\N
35	Bc169	gAAAAABqzhr5Pu7JUGRYyO3ilpE4dp-HRRAEL2R1Hn84FP7FZivk_0Bn0dN4H6948-ZE-12C1oQTvNA0PbEOYV9lIYhq3yqMng==	25000.00	\N	\N	2026-10-13 17:20:17.171812+05:30	\N	\N
36	Bc170	gAAAAABqzhr58gcZmE-AEXA0F3dIjlM2YFQ76LvLRcljWJ43PyzRXyxTXkye0fHx6j5z4b4OpR_O5REv1DssvV-PUgVaEoMDWA==	25000.00	\N	\N	2026-10-13 17:20:17.187389+05:30	\N	\N
37	Bc171	gAAAAABqzhr5Nd7jz1iGnWMhXdGooji4sBsYCCIikJAS3JNTks0Tx2VNRGJMc7JzG-3j-hzYI9IkP2PmZz4N3QIJmO9tuYI2Aw==	25000.00	\N	\N	2026-10-13 17:20:17.2018+05:30	\N	\N
38	Bc172	gAAAAABqzhr5Mn480oo2NODCelxmRxx9szHr30SGCXnzsWZogK5pRZ1dq7UbFJPnvsLrOaldLnC0mB6cJ8CRYLEi2DqSFff-Kw==	25000.00	\N	\N	2026-10-13 17:20:17.214706+05:30	\N	\N
39	Bc173	gAAAAABqzhr5csSmBiFSxDAqT3QJrO0Zgv-De4dbecxKhGEK0WKErKiFIoZeVfbOz5L8nq1By55CkUbhbFx2STV6-wl6U2vmvg==	25000.00	\N	\N	2026-10-13 17:20:17.227514+05:30	\N	\N
45	Bc180	gAAAAABqzhr5k8SeQLkOZaUz2kXbE-2Al5HlKR7pqzoBBexIt4jO5ndB6sJhD6WmLUmid72H8vc-JeAvQjC4VpKJWTbAwXGRcg==	25000.00	\N	\N	2026-10-13 17:20:17.356623+05:30	\N	\N
46	Bc266	gAAAAABqzhr5q-zVaIKskTddEuRjcBRS35d-IiqLP8muye9ZGw6AwlmR-2pPfVMEB-4zBzrFAagHnkPh-urVj29nX8_FZZu5vA==	25000.00	\N	\N	2026-10-13 17:20:17.371253+05:30	\N	\N
47	Bc267	gAAAAABqzhr5flQvH1NZ85AFHkpQARnDK7ZETYVvGYtclBxpyVY1jYoovsVcle5a9la8trGIbq-Xu2rIwWcMPHlQ6RTBqei5mA==	25000.00	\N	\N	2026-10-13 17:20:17.385138+05:30	\N	\N
49	Wtz363	gAAAAABqzlnlhnR3shvQQuh1M9FZ-Podh1P5G5ORhLEkuiNyeXAa22nXE25DrwmGE2jlZZsVvRprrfDrJi4T6rk3OyaRyQ4Pjg==	500.00	1000.00	Chicago	2026-10-13 21:48:45.546454+05:30	\N	\N
50	Fsu117	gAAAAABqzlnl2kIbqxeWYuZIHEwE4stAEUp_r3-TjfXk2TBO-Mabfep5TA9OE1NAkCSiQ4xyLVqaMflauzQU3wc6ogqgMnyNdw==	25000.00	50000.00	Las Vegas	2026-10-13 21:48:45.575683+05:30	\N	\N
51	Coop02	gAAAAABqzlqHUXj-nWeGB2YKl0L6AvAOmxxxpSt1TGlpeyFplVSGimCl7eLZx3hBAzC1LDt1EIuha37bsb-yJHWMBIkBDL_MMQ==	20000.00	20000.00	Dallas	2026-10-13 21:51:27.235724+05:30	\N	\N
52	Garnone1	gAAAAABqzmE8HtZErn5Ccg6_OVtYYU543V3Rr139pGgtPlDH-QkswfmfjRWXUlDWBOwsXIcWGERWFx1rNiGIcerVdrkKOKBD8A==	5000.00	10000.00	NYC	2026-10-13 22:20:04.1437+05:30	\N	\N
53	Kevin9	gAAAAABqzmE8NMs-jTHy_vLCeAO0uJQwi77wsQOLw51njwndIxIf9IIliej-F6Xttf2QQxnqrR5brg-w-uWhrVesPM4nEmXRTw==	20000.00	20000.00	NYC	2026-10-13 22:20:04.173524+05:30	\N	\N
54	Sb975	gAAAAABqzmE8pWVKiYhyU_3KzcUZMYC5UQ1jL_wBlGEzhk9VI3kJXMpyE4o0OiiJLW_C4yge_ycGmGfuNiFtFLe8eQYYuX3s2g==	20000.00	10000.00	NYC	2026-10-13 22:20:04.190365+05:30	\N	\N
55	Whale267	gAAAAABqzmE8oIUFAnxXm597jE-3PTQo_osQiay5-_XOoLWZhU9jqHmOAKEtWshWFOOnvAFnydiwoJAlWcjsy6FBnSsfCSrYtw==	60000.00	10000.00	NYC	2026-10-13 22:20:04.205906+05:30	\N	\N
56	A7908	gAAAAABqzmE8B9nkyLQNDZr8FZ7H_nrizCG7JySyYG1YgiR5U0w1T83nf1UNf3i2AH1LIsUG4lFf2gqyQHrbjTOIHNGMTtTpfg==	5000.00	10000.00	NYC	2026-10-13 22:20:04.222752+05:30	\N	\N
57	Q6572	gAAAAABqzmE8msFL9LeeOLxpPlCl9Qn5QtMDXUMv2Y5M0uhT2BLDDp2wV9gcX2Vr87So6Bq6ygdaouoLDih9sKR18jApg-X_pQ==	2000.00	10000.00	NYC	2026-10-13 22:20:04.239774+05:30	\N	\N
58	Bax108	gAAAAABqzmE8kpqTDBcuF8V4Bi4jcaKPpEnO0Rp9o9U-bYH7GpTZF1t0U4KEamItHIZGydeYK4SbRziX63OCPyH6-AFWZPmYIg==	15000.00	10000.00	NYC	2026-10-13 22:20:04.258542+05:30	\N	\N
59	Plat14704	gAAAAABqzmJ6m6asYI9sQPcDyq_FE2bUyceNh3l20FgaCPWw-3k8EBQVbX61L1rutVZrFGpoP4y5w3valula1qGX58CLrVewBQ==	10000.00	\N	Dallas	2026-10-13 22:25:22.44062+05:30	\N	\N
60	lnk98213	gAAAAABqzmMI2xYFO3LH_kLe4G38gJDICzl0m_rbGN_99W2_fKyNa32-RAlTIn4193s-KNvSuS53AkGyFXWW3ZAh-DPJRJWQkw==	1000.00	2000.00	San Diego	2026-10-13 22:27:44.186422+05:30	\N	\N
61	Ron00x	gAAAAABqzmMIkk-cJPmq-12ztQEHpDimdTACossSYtT0UMh0sbR71XSaGG6s9xtF_kpJutgXMkVs3HcbYyHDLGtb4vsOEFP13Q==	750.00	1000.00	San Diego	2026-10-13 22:27:44.213438+05:30	\N	\N
62	ronpat321	gAAAAABqzmMIn5Ng9XV-u-7HEjWcwEMWqz6H23U2etwITHPrlWyZTrMQrQdjXYEsJxe1hait-FJcgIf5cZk4FE5bgUFIeF8P0Q==	1000.00	1500.00	San Diego	2026-10-13 22:27:44.291725+05:30	\N	\N
63	md23550	gAAAAABqzmMIR34X13xL_Na6CiNtBbABVZIp-mxUup0Tf-KwBZ8PW9Clh5ZYHrJMOZXi5AN1F4koP4_ctnYu35Xdi3P-n1yQPg==	500.00	1500.00	San Diego	2026-10-13 22:27:44.307575+05:30	\N	\N
64	RODEO2	gAAAAABqzmMIQHZKzE3aqJFgiHzhOAZYFFpT6jpBASA1jEwaRGOC_Nd1hm5_YutRpNfDhlovCxurEJ30Aw4ngys3gJproNPCVA==	500.00	1500.00	San Diego	2026-10-13 22:27:44.324646+05:30	\N	\N
65	patel714	gAAAAABqzmMIMJsmKEuME9v3KUS-xgby51vcInqLTeo7hL8qqo688dfVKHsHk5PWFQdpMUXTB8EPVrV7V7dGXydYSe-7uipyRA==	500.00	1500.00	San Diego	2026-10-13 22:27:44.339413+05:30	\N	\N
66	AMG815	gAAAAABqzmMIjM4zGl7J1ugxOYjqKb1oPkdw7ClRz2wFIGN0AaGYsv4PIgmTFYGz7Fv7HuxnmFbobgc5WFhNFVeqIKdk9zYe9g==	1000.00	1500.00	San Diego	2026-10-13 22:27:44.354967+05:30	\N	\N
67	RONPAT9457	gAAAAABqzmMIp__H98RpmOtNvOnpg0YAEifLGEQOAJtElBZkcs8rXA5KxBNGt61HaJAOWsHL4hmat-X4dvyDZJz0aTqpu_O12g==	500.00	1500.00	San Diego	2026-10-13 22:27:44.369109+05:30	\N	\N
68	Ca133	gAAAAABqzmMIV6Vt79NBn8mFpG9u_8k2bGSmSityGEwBe_hsdPrQbh1QXG9iPffyDzB1j1jB3ZOVH-g3T3DJctz0pjVepdjXsQ==	3000.00	3000.00	San Diego	2026-10-13 22:27:44.385019+05:30	\N	\N
69	Ccm166	gAAAAABqzmVn09loJzSB-ROMkQrmR5sYqtnIlHI4OZzIxwS-JZS5gvoIHq5kCp6B-gFqvREJvRhzRv43R89GqOSi_P50o5uXKA==	1000.00	1500.00	Leawood	2026-10-13 22:37:51.100548+05:30	\N	\N
70	Jsheplak11	gAAAAABqzmVnMZqPhJYV3VmiQp3Udc5qbgoduphWiBK0-Id3mUb0L18mEJl4ndBFqXI31-HT5R620MTszIxGCPR8dkOYp_v0yg==	1000.00	2000.00	Leawood	2026-10-13 22:37:51.127516+05:30	\N	\N
71	Jw515	gAAAAABqzmVngeQFJNNzu4grqVj1I_fU8AsEKqvyewL72CobdUJjpdEuybetAFJuCM2T8ezJHGUlaB8GqTk6D6ZOOtXbPUs2Bg==	2000.00	5000.00	Leawood	2026-10-13 22:37:51.147864+05:30	\N	\N
72	Jsheplak14	gAAAAABqzmVntQqYcFwbLKtFkL4ml2ZhzWKEkJguPUZxNUeXFq2zavNDV4IWoaldmfUJHPuCR3M_jluGJCHyex2ha7fWWOmLew==	1000.00	2000.00	Leawood	2026-10-13 22:37:51.172139+05:30	\N	\N
73	Yng102	gAAAAABqzmYmASdL1nUb3sHI5qciAdE8Qpea9JLQA4FwdTRPi_nwngPG-mTlzID5HybsamtIohkrPaK1PxAE2Do0eg63FJgdcg==	5000.00	\N	Dallas	2026-10-13 22:41:02.271121+05:30	\N	\N
74	book5004	gAAAAABqzmbgrTaiJ4uiuFdbf4riYnMJ9_5sviXONvOmAefWxSXx-4bAGKFJeg6cQ7-n7LqBzI7mg8XLzoLaWpaxL-ZtDcPVTg==	10000.00	\N	Dallas	2026-10-13 22:44:08.467819+05:30	\N	\N
75	Ua678	gAAAAABqzmbgXergtNj3a0Er4ny4awpAXnsfGHvNz8P7JOxeQXSPzKbCRKPMqvk_JuOp6Cjs3Scce62WCEBdsnGvwNLcRFqtpQ==	5000.00	\N	Dallas	2026-10-13 22:44:08.495192+05:30	\N	\N
76	Pw20	gAAAAABqzmc_qMCB1PfdqQDHgnVxEP-D4mCCl94H8dE-IGdpFbrZo8zuYCie-PIYOo2j39zUvHcyl7NIvDK8_DWpluEzFRGshg==	20000.00	\N	Dallas	2026-10-13 22:45:43.314579+05:30	\N	\N
77	Pw21	gAAAAABqzmc_ggrMimRFLNDAZZxlYs06sDwUasCgv8GRKFu5gIqGkE3LyYamUjbIjrkAUSlW-NqEwZgvslMGkeMn2cxlYXXrYg==	20000.00	\N	Dallas	2026-10-13 22:45:43.341354+05:30	\N	\N
78	Pw22	gAAAAABqzmc_BsIZ2S_FWWrGLNNDnY-ck-IIH3zytSI17LIzbpRujiDVsPyEqvCMsqyPNGS_ZghEf861qxmPAuSUoqmTS_dxDg==	20000.00	\N	Dallas	2026-10-13 22:45:43.358179+05:30	\N	\N
79	Pw23	gAAAAABqzmc_a7rZanTlGPeM7yKrQnXXcSHHBwW-3BOzVbDr77Reh-e-VVYGwtJJeMXYaE3x1X6E0VDUZkGqfn1rsShSj5Xi3Q==	20000.00	\N	Dallas	2026-10-13 22:45:43.373637+05:30	\N	\N
80	Pw24	gAAAAABqzmc_CfMQ8ov06fLCrAz-6J3cERHm7g7gcob6B_XU_kwaq-0zHMarExgFqV6WKcZVtSU4-JBPMSbKgmMP6s2S3UY8Iw==	20000.00	\N	Dallas	2026-10-13 22:45:43.392369+05:30	\N	\N
81	68301	gAAAAABqzyEBdTM2gOd22YKqUmPEplyKAVuvlLlS2Jq7FwmqZnq1D-D9HXJ1LbmQISrxShL-UhxJ-cfUF34Zg_r4MnAC1qG2HQ==	500.00	1000.00	Dallas	2026-10-14 11:58:17.7894+05:30	\N	\N
48	Db6211	gAAAAABqzlln2D8RgCgEJShprD2ZYT9_5lkg8wh7fj3RZCOJs5tP7xWM01gOTdpDbn88RPVPeK4VYO8NUihr9IjEPu8jo8o5zA==	30000.00	\N	Dallas	2026-10-13 21:46:39.400865+05:30	\N	Unlimited
82	b2229	gAAAAABqzySFt9YVCuYS0VvghumwyEmle74uKwFFh3wNdGo_d1tMf6WZugmH3WQ1xLxtlXli6d95QaoIHlvfFDbv2m9LmpHPhw==	50000.00	\N	Houston	2026-10-14 12:13:17.638332+05:30	\N	No max
83	Db6219	gAAAAABqzySFgTJUqq81t5OjhRin7kBd2bGRHfjjeiC6uyfmzxr7Ie4_cgn4XK0AE7MNgmWJXOlYT38RDrUwcv2SXf5VF2VQJw==	\N	\N	Houston	2026-10-14 12:13:17.673103+05:30	Infinite	No max
84	Bas613	gAAAAABqzzDA4-0t2Zrqhx5XApnfJYFUp1DpdQ8pqoRUom5fwJ8OQenqt-zE5fEu-fuoWEGGRkD2AoPmc3Loj5wGVm7W_qPO5A==	10000.00	\N	NYC	2026-10-14 13:05:28.469219+05:30	\N	\N
85	Jb710	gAAAAABqzzDAGb32oBfRBHtbV9hdyauU8-AlxCsz5oxDGkGsO6tKU_WWqFT9UODSD17GbDlMCsGTOBvYJtLmSh16LC9Z14Nglg==	2000.00	\N	LA	2026-10-14 13:05:28.490113+05:30	\N	\N
86	Blk201	gAAAAABqzzDA4TcZ6lA4plQegV0uFRCLufcggQxap9e_y0Gk1ThiGLqAsv25my5hVBH9Z-8lx2dDULhsJS-hfI6BKBTO-V0hUw==	15000.00	\N	Dallas	2026-10-14 13:05:28.512528+05:30	\N	\N
87	Xkm987	gAAAAABqzzDAxhVMpUKNut9EzMl-10-8ezObEze0XGlKywapGkL-1_hTplXA1VM7fmCEBJYx7UtfpX2pMb7gsujRvrupkHtaxw==	5000.00	\N	Dallas	2026-10-14 13:05:28.531851+05:30	\N	\N
88	Julianx2	gAAAAABqzzDAE-34vetsF4GJkPVfN2L6eQ9Byc1oIwbGX48xIjAjhEnPe8H6M9_CEgniPTvJzRTmBDSacERVPcSmabpDqRQ0Og==	700.00	\N	Dallas	2026-10-14 13:05:28.547871+05:30	\N	\N
89	Pro1018	gAAAAABqzzDASmip2MM4vM15gHmsH-DGRB4wsGnyU5sCByiQcUlwDfk_I6HWOIQ_GdGvIw7EKM0LypodvhnErtMiBo4o4Jp6IQ==	5000.00	\N	Dallas	2026-10-14 13:05:28.563811+05:30	\N	\N
90	dd0027	gAAAAABqzzDA8Oc8FDNjpxB202UHQuO8lKp7A_rUQShdBiD40NHIV0m0Hbp5TJGg2cykepbRYKckV-cpZsAT_T5LcZNSAMHdEg==	15000.00	\N	Boulder	2026-10-14 13:05:28.581116+05:30	\N	\N
91	Apo109	gAAAAABqzzMbT1ZrCpP8MKRj4RcTHFpBfZjDuKpfSaQ1TTRop-PQKQBVEv6gTbI1Gg6NSNWNB93Hh5S0fC_oyi4QDi5Cd3UOMw==	500.00	\N	North Carlina	2026-10-14 13:15:31.281299+05:30	\N	\N
92	P7	gAAAAABqzzMbylnTePqRW1VcJYP8bKyK2tpYNvTit1WjaQItaCbY9B6gSc7hkM6ok3pZfm1oshsjrEBpx0CHoC0oJmCimy4Aow==	3000.00	2000.00	North Carlina	2026-10-14 13:15:31.309537+05:30	\N	\N
93	Pr2729925	gAAAAABqz0g6UGe_HbieDUBRUtqmPAb4U9Vz0WJk-3dOWdUBPvMDpT6M7HaieE3An2naPMEjophNjQeaRwt38zx_zVfSkm5Gmw==	10000.00	10000.00	LA	2026-10-14 14:45:38.751637+05:30	\N	\N
94	30300	gAAAAABqz0g6H0UNK0KnDl3iFxz3p01jwZ-6x-KMejjiu5tZxwTAd9cPejLHGfCma7u-KeZRzoziKlx8RqFcZzUTbBdxg3C83Q==	20000.00	20000.00	LA	2026-10-14 14:45:38.791863+05:30	\N	\N
95	30301	gAAAAABqz0g6Hxm9h_jITiEZAaZpJJDKGs7xGCGFeXufiIkzYpwPGORWGb90060i4nLg2hPa4GfKLZV5pHhVXI4fzu1UmPuBSw==	20000.00	20000.00	LA	2026-10-14 14:45:38.831563+05:30	\N	\N
96	30302	gAAAAABqz0g6sQJMCTUAxg35ayNQ_0eBBloewuErasTAwI5ieYc3pSeupWfzlTgRca87K2zlGP56yd4muF4-_obG1RcUiTTkiw==	20000.00	20000.00	LA	2026-10-14 14:45:38.859742+05:30	\N	\N
97	Bg904	gAAAAABqz0g6B7pd0HEkfCzTEy3QuUl7BUNFL2vyUs2aAA1RNNpPEDLSirymCcMgc3IDPNRot4WagdmVboyFFBs7J4GUzLIdjA==	30000.00	10000.00	LA	2026-10-14 14:45:38.885074+05:30	\N	\N
98	M8002	gAAAAABqz0g6t08uxWgitobT61kgy9cn7FXSntUkI7E7oJelXEFBHwqbSjJO09DCeR9WkCXA1fpsUC8RxngwgD99VqAaZ_9QcA==	10000.00	8000.00	LA	2026-10-14 14:45:38.91288+05:30	\N	\N
103	Gem001	gAAAAABqz0g7cNImdOr-koIorjZ8OStvTtHiajb25O-sRrJ9a3buxuLr6EO9rITjOPRYwctB5LcsmNSweT5ki7F8M9IKOFEjCQ==	20000.00	20000.00	LA	2026-10-14 14:45:39.028079+05:30	\N	\N
108	Top101	gAAAAABqz0g7iEOvyT7TFyPFggsgKqIvyvw5BP4Ao4j8Ch7Oltaf5Fw9nKn4S9yr0RZEanc9_Lp24tb6SYY09hcK0d-4e5w1xg==	20000.00	20000.00	LA	2026-10-14 14:45:39.12127+05:30	\N	\N
113	Agt900	gAAAAABqz0g7oIXpJQwsAemgpF6eERkxyyp5VlVGKvSOCc_P2PAhdCv81nhuqtWMgraaRqeJXYk13LUbUIA5WruhWf_Mc7MzXA==	25000.00	40000.00	LA	2026-10-14 14:45:39.27751+05:30	\N	\N
118	Tt823	gAAAAABqz0g7dNJZZztPDX-xX_fnEt0fjAyxWCkcB17QTm9P2mNfo8NS-57moKXDcBZqyIVpJ3u8YM7iEl80Qc5TD7h3FZ2Qfw==	5000.00	10000.00	LA	2026-10-14 14:45:39.41441+05:30	\N	\N
123	Dt753	gAAAAABqz0g7bTgRqalBCSV_DaAT3OvQcMRdkjjwFCFyHHpAiIxt9dp5Yyl-LUPwQnqSoMk66VeshrcegoPeZtncLsbCD_rDAw==	10000.00	10000.00	LA	2026-10-14 14:45:39.528004+05:30	\N	\N
128	Dt229	gAAAAABqz0g7pjghpoLuajcvSNZL1GXovP-aD0m3q7WbzFRlRF2vozrmLPbCAL9Vmy9qeYanfwF6tNOM8r2-ubaVdfNco8ZjWA==	10000.00	10000.00	LA	2026-10-14 14:45:39.652562+05:30	\N	\N
133	Bh014	gAAAAABqz0g7XzCuo3VmYIs6BloGR5Xxl7U4qmM5A_Vfo3mm2eBHRFiOFwEYVm3ADcuPa0PGwp4qfL267rSdBiTbgnYR1ezoOg==	30000.00	10000.00	LA	2026-10-14 14:45:39.789429+05:30	\N	\N
138	Le022	gAAAAABqz0g7MxbLdZbnPTuLLr-AXVfac7s-P_akuGQoJBrQ_77ECRBxT3Qcvrfs3ri2FthQvvfXu-whXPEB61UoeMoVP1-RiQ==	4000.00	10000.00	LA	2026-10-14 14:45:39.922278+05:30	\N	\N
143	tdd60	gAAAAABqz0g81JZO_sRo6ynViVcbyphq_6Zd7KkoASfVgzalz0_0EQzFqvc7eb9DnZURtld7uK3YyV_0BjizQ0R5vMUnmXeeZA==	20000.00	10000.00	LA	2026-10-14 14:45:40.043181+05:30	\N	\N
148	Ac802	gAAAAABqz0g89gClHjxuGYLvV5SJREEOh5ZNMdhinJYqgY6fh70YnTLMf-wxk4hkucCCTbA2gKVA_w_17LU6QIZeQrLRnwfjiA==	10000.00	10000.00	LA	2026-10-14 14:45:40.173632+05:30	\N	\N
153	Ftt27	gAAAAABqz0g8LfkErfdlcBJAgELLMENb4qw9_-mbJuhXJS-l5abfK9UhJpMnBWiZ0NtrtBdi7zhVy4-1cFgJsp90wyLlbAzJlQ==	10000.00	10000.00	LA	2026-10-14 14:45:40.28396+05:30	\N	\N
158	Pn479	gAAAAABqz0g8HpWBtRWV-AYVyjpm7ekbJ_Gz8dKcssmGq-WBAQ4MphbhcF4sacYM5OYDCJkcQRDG5eI6izNKLCg2Ai-axO649g==	10000.00	10000.00	LA	2026-10-14 14:45:40.396142+05:30	\N	\N
163	Tnt23	gAAAAABqz0g8wKbH2WQ4O4RUB80mdVMY9S9gQNMuzZN6cQlH9bxTCw7yL7Ie7Ibx5zBGA2S2ewqRWbB3ERX4K2x30IDrUSC7hw==	10000.00	10000.00	LA	2026-10-14 14:45:40.48727+05:30	\N	\N
168	Jrsdb1829	gAAAAABqz0g8p34x4ZpgpEImIzt9gHgmdwfh2rmH8D34GBGS3hk-7QCqP_eGVL_UoF-hoIsYBMt8_6A7Qiv9DzStJ8sPegVLDQ==	2000.00	5000.00	LA	2026-10-14 14:45:40.575597+05:30	\N	\N
99	Mv6647	gAAAAABqz0g6nxQfPBxC9v7_KTHv_LqQPAXzVviNe19mdlCyP6E90sVKVCsmTFFmQaws0EeoPKF3es-om0Vbc3JWkd0pyfCFmA==	20000.00	20000.00	LA	2026-10-14 14:45:38.93504+05:30	\N	\N
104	Ds100	gAAAAABqz0g7gDOtXXG7U0l3z3InnHtoPWdORZj_NvbgWpPTVGwqF8Y1s_dKx3eMDURzDQWokJY3kfm3zhksnDgwLnjkspaohg==	20000.00	50000.00	LA	2026-10-14 14:45:39.048068+05:30	\N	\N
109	Top102	gAAAAABqz0g78g-u9aSt-G3a_xtHeIdD6hIhuKeopC3AO9Tim0vldE8kdI1yFaos-1RXWxGSTXrUIveiyVlEy4ppGTYLs3xvSw==	20000.00	20000.00	LA	2026-10-14 14:45:39.151668+05:30	\N	\N
114	Jz515	gAAAAABqz0g7Qlxr3iJIYgq1lgo33lBNtoD2FdhDRc_TayvEe9ATYRSHdYDEw9437HZaM29idDfNvgBypenx5zFZ1VKsFs9Chg==	20000.00	30000.00	LA	2026-10-14 14:45:39.301164+05:30	\N	\N
119	Tt801	gAAAAABqz0g7ewv8tjpKnNAhpYUtJWKxstdgkbrkYE2FUsmX6pUmEI3iwzAsGfQ9Qsb1Nn5_AsBCXoeYJ4_X1yT4o4R5Pn0cAQ==	10000.00	10000.00	LA	2026-10-14 14:45:39.434715+05:30	\N	\N
124	Kn928	gAAAAABqz0g7ykLXGGmilqIKMJqQfFJZ15wMFHSU194TPpcpa9FLEVRK1e0TcJxIAjsbjzU3su-5iwNq5XIX01ZIegI1gOLFdw==	10000.00	10000.00	LA	2026-10-14 14:45:39.546215+05:30	\N	\N
129	Dt001	gAAAAABqz0g7r3llAtk5KvVZK3J1MmShW5nIUJlg4iC5qPjshML0aKBh-pHI2T0ypNvt-Wt5s-NDDgG6rXhqAnwCXs4LurdQRw==	10000.00	10000.00	LA	2026-10-14 14:45:39.679475+05:30	\N	\N
134	Todd105	gAAAAABqz0g7d4N8GakcujVOYWvXU6Ucv0foEMy5gXFS6dwwwsNnHMbJZmtAEyvM-KaquYOcx5a0LMcBvZYnWmLW_QLWkFscsQ==	4000.00	10000.00	LA	2026-10-14 14:45:39.812845+05:30	\N	\N
139	G0037	gAAAAABqz0g7s4edB1UiNaiVa1nNVYuv0zvfu90ZBV3h0YQWdxtB7NBt9MrXPc1tQUdsBYHIX_-XQpZktCZICGB1wVHUzkTqIg==	5000.00	10000.00	LA	2026-10-14 14:45:39.941488+05:30	\N	\N
144	bj1042	gAAAAABqz0g8NXIng2CTGxiz8z3Re4m9-ZHahjghU2rT4cS7xf0MpB3IcgvPUS78oJFBGcyTXSW0pzcJManA14298TFEzCXWMA==	20000.00	20000.00	LA	2026-10-14 14:45:40.074805+05:30	\N	\N
149	Ac1106	gAAAAABqz0g8KSgsvWAqm96t7E5DlWOgHCNk4FTyP57sEI55YgXlzYnQfxEbtMEPHqv5OxqrHUVUqjwKTC9BAPla3KExyk6Vzg==	20000.00	20000.00	LA	2026-10-14 14:45:40.195492+05:30	\N	\N
154	Ftt36	gAAAAABqz0g8QsVl1hkn2cib0avSTHIAq4cFAR-p6AOcb89rIjaPUnKQHbSfMbfWXLsIvSMaXRe9JrcUAkQe2rG4ssWQQqWsxQ==	10000.00	10000.00	LA	2026-10-14 14:45:40.308894+05:30	\N	\N
159	Pn5009	gAAAAABqz0g8PzBAT95qIzdtl54mSL_DKb5BSH8zfA3a669O9f8s2MuI7xOwHUD9N2hQYiK6_htjHYSbiKgiFccj_5Emd8Kq7g==	10000.00	10000.00	LA	2026-10-14 14:45:40.417697+05:30	\N	\N
164	Pn446	gAAAAABqz0g8nEtJtMHanXfmIba4u1RqdMHlZe9QV-xCCwgZh0lSegJqyF_G6WMGBx3PVfWLKFKwQQORAshpmtS63_zp4w6xiQ==	10000.00	10000.00	LA	2026-10-14 14:45:40.504764+05:30	\N	\N
169	Jrsdb1830	gAAAAABqz0g8egJ2HONafvyJ_Afa0tGcHuz71BhJ1gqjqtIi0dYeS8m0okrDrjBulHxbPAfBqx00ttM3pIdWNXFaNVWC1gWkVg==	2000.00	5000.00	LA	2026-10-14 14:45:40.592982+05:30	\N	\N
100	Zz603	gAAAAABqz0g6500fHJArlxEGBD3ZmZ44y6ssXIdgaJZu4Guw_6A3QnRMhY2p5uwWgx2PfK5cfhRhtOSfv0H-wCN3kQI85upPwg==	30000.00	50000.00	LA	2026-10-14 14:45:38.963221+05:30	\N	\N
105	Ds101	gAAAAABqz0g7JlErGh88Ujz1eQ9JK2Zr5AkaYxqBczk6oBbvn-AqSKEHDdorM-5Z3xcAcasFJ3QpsAjSFmi2roBtRutuVvQHxw==	20000.00	50000.00	LA	2026-10-14 14:45:39.070424+05:30	\N	\N
110	Hbo208	gAAAAABqz0g7v9grybo9bagh14u392rmmkQj2dCL0Uuy6HFIatMfesSnVYziGthi1rvELgKBBTFkOCZ_v3y3lfZ3ugTS00FSfQ==	20000.00	20000.00	LA	2026-10-14 14:45:39.186663+05:30	\N	\N
115	Qt511	gAAAAABqz0g7FknsMtu8fF7_40cMQYgU8CRi5S1QXFBhRiDuK8Sj4Gxm1XwzguCDRJSNrZqbsLN1pSH8rud2SdpnbcVjkp29aQ==	20000.00	30000.00	LA	2026-10-14 14:45:39.330079+05:30	\N	\N
120	901	gAAAAABqz0g7FMGJU5HqMCvlyZAaTgjaWvR6q2MmYs13AdMzqEhPupGByt834cqiZCzPfeOajzJ9E-1WxEuH0ZaxcUmolqyyQQ==	20000.00	20000.00	LA	2026-10-14 14:45:39.452675+05:30	\N	\N
125	Sf133	gAAAAABqz0g7bY904HTXhgePEKzwky0D2BSCf_273M7yPp-z7EcRiUj0CSue8rRzPVm4T7f6jZc7XCFR9q1hMDh8_6ueW4OLuQ==	30000.00	30000.00	LA	2026-10-14 14:45:39.571852+05:30	\N	\N
130	Tu282	gAAAAABqz0g7RoA2_M5aMANT6UWFad8rdParVkx_nVumDQIdpbsFkr_bt9KFpsTmh_5L0yi3PFG-IBwE_fYZENYJDR9xobs1mg==	10000.00	10000.00	LA	2026-10-14 14:45:39.703134+05:30	\N	\N
135	Todd109	gAAAAABqz0g7xw25QerYlJHE6CUklTqkYgql_hs7vEstmC9cyBPFmN6RsFglucm70YrObv7W5x5nni5ngNKndX8n3J-Me8AQ8Q==	4000.00	10000.00	LA	2026-10-14 14:45:39.835414+05:30	\N	\N
140	g0032	gAAAAABqz0g7vo4Q04_mMzdw2c4dafkxfdtpViAdczhRSzrqe0Yk2sNkFHVDnhGEaZp7qE1FDXLgusp0VL-DuDvS1ZFbLpNnLg==	10000.00	10000.00	LA	2026-10-14 14:45:39.968252+05:30	\N	\N
145	T124	gAAAAABqz0g8nPCTaWe6PHjeevGjeGtHvrXkIjRBwL2P9dVfVE6OSYw4pzoY8rKO2tVuNlRCB5Ci30x600WtUwdF7sPEGj61JA==	10000.00	10000.00	LA	2026-10-14 14:45:40.098692+05:30	\N	\N
150	Akg102	gAAAAABqz0g8Wqp3TbCwlLM0WVm30CWyQNBEZoAOTvOAQFYr-y_ndBanlkyM8HsV-GIEPfOfxJOLqyE6lAhRNxIPG_4_sSbvIw==	2000.00	20000.00	LA	2026-10-14 14:45:40.223829+05:30	\N	\N
155	Ftt35	gAAAAABqz0g8HIpBpzfKSp3_7l6aE3griZNUZNncKW2ke-E6qsRsepgXb028JjkWFJqFUIUPHZfYKauNspS1vmSte3suWG7Hwg==	10000.00	10000.00	LA	2026-10-14 14:45:40.336228+05:30	\N	\N
160	Mu302	gAAAAABqz0g89ejRUfvQg3NOOOkmaauvfkMhgeWZ0stI-LbXtQKnOGhDG00Bx8R8BzrW_JQACPYM6kjjWbbQ-3_fbr75RpTymw==	20000.00	20000.00	LA	2026-10-14 14:45:40.433139+05:30	\N	\N
165	Pn5004	gAAAAABqz0g88_4WyQ7WCW6g39g-2P7r5nyrqY12TTio1-p9dRSekdTVjVjnlLq6gSfC02FIqSCg0aV2vDXiILIzyJuddpwTgA==	10000.00	10000.00	LA	2026-10-14 14:45:40.522215+05:30	\N	\N
170	Jrsdb1831	gAAAAABqz0g8I84pBOZmYIou8A1bh233tQkvCyZkZgPGrV9lAYSNYbUTZWpOlON-wnAoLD20tmQHc2GnxzBxxgNuCXHKfADKBw==	2000.00	5000.00	LA	2026-10-14 14:45:40.612111+05:30	\N	\N
101	Sa503	gAAAAABqz0g60lEc6xOgpvd-PIzj4EEiON0R5150y5aDVT2laVRxqlHq9RqJEGJXSVojcaV42NBW5Erqs7DFkKZ3W-Ub73p30Q==	30000.00	50000.00	LA	2026-10-14 14:45:38.98392+05:30	\N	\N
106	Ds102	gAAAAABqz0g7bUux7UXlOxSgpV4V_7umChLMq7eaPM8uvTUOrjK4Bj0SCD-uAykdtlaASQrG3kE5jieOWrMNPVD2DFqh8u_SVw==	20000.00	50000.00	LA	2026-10-14 14:45:39.087258+05:30	\N	\N
111	Ny5051	gAAAAABqz0g7OFqJxzu4rpjfbDYyki10-6dyjECCtpPg2ba6jvpPAA1PZBmYHLnLwVGPMW87cMyVhUGVwzYK1mS9peiUpWgosA==	5000.00	10000.00	LA	2026-10-14 14:45:39.218164+05:30	\N	\N
116	Tt822	gAAAAABqz0g72foTejyq2_AGUNcnDRZOLvUQRHKWsEpelN16qW8EU4PdI0cN5cQ3f5Pl2RDOQv427E85cz3W-W8B2PLZgrDmQA==	10000.00	10000.00	LA	2026-10-14 14:45:39.368195+05:30	\N	\N
121	Khn126	gAAAAABqz0g76kqdvN9jPGt3MTLckHkoMVrGhM7ETXJIbYx-6_NErXWvh6gQzewqd8RIU1JXrezfPexP0JYil78kS2_DwpD1ew==	20000.00	20000.00	LA	2026-10-14 14:45:39.475102+05:30	\N	\N
126	Gdt17	gAAAAABqz0g7I7wtN4tv1bo_cvXQyqqHdLjNeLAv5BiYpYV0W0Jhu0w_JSOYjlSAo6Dbmnvcopxw4XduUluIoAiOCBcRwR10YA==	10000.00	10000.00	LA	2026-10-14 14:45:39.596517+05:30	\N	\N
131	TL3001	gAAAAABqz0g7WnILSiaEH-cg7nKeXUpYtHhFjxWhVo9p1vVDztdSTi5q3xbdMNt9kmIOjJA5UH39ESU01TQLmmD6zbp5LdV82g==	10000.00	20000.00	LA	2026-10-14 14:45:39.734141+05:30	\N	\N
136	Tdd11	gAAAAABqz0g7Vj69lWwLar0SyzQnmSDpC_hKazV4R0Y54rE4Yt3nT2Zv_nuSVB0eycf9jjAMQ3oXxfup1uG2SurveG4PnlhSyw==	5000.00	10000.00	LA	2026-10-14 14:45:39.871244+05:30	\N	\N
141	Boc113	gAAAAABqz0g73dGPZn5hX5th9hbiVZjlen8vTpGyV6GPKZ1lE9iAMFsFWYHIbPxi3AB07ZxvrEpuErQiz5b4JZbZChHmlZCTJg==	20000.00	10000.00	LA	2026-10-14 14:45:39.987819+05:30	\N	\N
146	Ren409	gAAAAABqz0g8MDMh7uoA3rRNmIxClB5UqlgQPbfB-vIidqwzJW774yYP_uvFaga9N-nLFX37Ibcd35R2l03xhGPWZ7LNG6yb4A==	10000.00	10000.00	LA	2026-10-14 14:45:40.125665+05:30	\N	\N
151	Ren302	gAAAAABqz0g8SNVWLF-djAifDS1kPd9MDif6XK9VXuVZ6oo1uw9JHacCoTU017gO95KDCzV-F3uM4-e28fJ01mAo3Bx8-a2Gsw==	10000.00	10000.00	LA	2026-10-14 14:45:40.242297+05:30	\N	\N
156	Xq376	gAAAAABqz0g8Xea5vs4DslfRv1SZ4RvWzGkgzT2Yv_pkSZK-1ZgCK2rXE0E8DjMl21Pdk16txeyKDQMkKcpXC7M_Y5XFPQ5swA==	30000.00	20000.00	LA	2026-10-14 14:45:40.354747+05:30	\N	\N
161	Fr23	gAAAAABqz0g8Ah9jaif7Fh1plxa3q2f4aut7m0dar1ftgL29wZik-iVFFlaGlCLj-9nQLf1kVSs3RWcIFkpWbTAX1-1rfo0xzg==	10000.00	10000.00	LA	2026-10-14 14:45:40.455912+05:30	\N	\N
166	Sg233	gAAAAABqz0g8k8KZvmfVC9eNKtGqC0NbjMsrJ_BSTdj96zZnsm4YVUyORyJwYA25XrtaiOYhzCDcH6IoHL0mz-niZxEebjSyIg==	10000.00	10000.00	LA	2026-10-14 14:45:40.537606+05:30	\N	\N
171	Tn717	gAAAAABqz0g8bgJP2thUyRMyAfyoJnsvgm6C9i_mGIgVLsTnSLVoWRehPt7JpUWhET2CBRMDt1_kM3Ud_j3PQj7NKMsiFeQg9A==	10000.00	10000.00	LA	2026-10-14 14:45:40.628808+05:30	\N	\N
102	Hco111	gAAAAABqz0g7vGeznpuYSjhcygM7tA0lQJuZme7kOtvNoCJaAf8SasPXLdzpy6vj1XA8mG_N5GW7uOeePYOG6ShcwqKT2cZ6ew==	20000.00	20000.00	LA	2026-10-14 14:45:39.004409+05:30	\N	\N
107	p73008	gAAAAABqz0g7XWFHfq7yXGu4NMMOB1j65WCLZtawTr8Jltw95l7-nj0pZFu1QURw6j3kQsnHvmDcxn2aPjvB7Ke2Z67JhPKbFQ==	20000.00	30000.00	LA	2026-10-14 14:45:39.103962+05:30	\N	\N
112	Agt711	gAAAAABqz0g7Ks5LhECLntxJNnd0jnfbmMx4PQRf3gcM2L47Et7IGHzm3Do4N01OKaeUL6W5UKW61V8DH4MsAHnyvIxFtzvh6w==	20000.00	20000.00	LA	2026-10-14 14:45:39.247446+05:30	\N	\N
117	Tt830	gAAAAABqz0g7aSXQs4IbwsLhyxwnstz-fPJblyMzD2HlMhnnmS7MMLmAEPkBweWR-XOq6WMxhzbEBDyRgtz4lreaPDWcv-BK6g==	5000.00	10000.00	LA	2026-10-14 14:45:39.388118+05:30	\N	\N
122	Kn929	gAAAAABqz0g7uNCHalre5M9vi5s9q6SLKVtFIsL9D6t-0jq_GYxUdN6XO7eWCo3nVh9hjWsw1NnQLHCt-VFD0ITFEMggTdaOMA==	10000.00	10000.00	LA	2026-10-14 14:45:39.500102+05:30	\N	\N
127	Dt228	gAAAAABqz0g7yrVfnfzYUJSYaz6CgH5NctVzSTIgiAYQsHJSUkw5n4A7NMZr44s4YTjRRT6x7WhFPxsEEm9QvLzJT94DkHQoNg==	10000.00	10000.00	LA	2026-10-14 14:45:39.630145+05:30	\N	\N
132	Bh004	gAAAAABqz0g7gILOe1SYIRwbKHbYjZbzmGgeYjmXKq1KWQqP7ye6xpqU6kr_j_mtYW5S9LxEsyVSohinhwa2nmljPl5auCwWKg==	30000.00	10000.00	LA	2026-10-14 14:45:39.760757+05:30	\N	\N
137	Tdd12	gAAAAABqz0g7glQZUuU75mbC2MO_DAmMGGW5fwB7uQWGpz8z5kbmlFzFHgrtwm8un9m87lyBMhk7HKufrt5XQRQ11tX2ImTcCA==	5000.00	10000.00	LA	2026-10-14 14:45:39.897408+05:30	\N	\N
142	tdd67	gAAAAABqz0g8Cpthml4WQXu6MSSarCj39roRGBTSpT9G1J0NaDM_QAWv7gsYTVVrL43-UcT8KY_ZYwM-mRAVdXdwdgqHsOb9Nw==	20000.00	10000.00	LA	2026-10-14 14:45:40.016861+05:30	\N	\N
147	Ren408	gAAAAABqz0g8PBbDnWg42Hk5E8ZxaNKYOTLvK-tymoN-bDY8s9a7If_TK8V2lLVfERjOJEoX9IAwHrSs5n3_X-qAImQTfonAcA==	10000.00	10000.00	LA	2026-10-14 14:45:40.147374+05:30	\N	\N
152	E2005	gAAAAABqz0g8PlgbLR3kAQo_swG08e2I7yEJQKRaVnNo-l3mWi0P9m-AmUQN_9DMIo4mc45ELHuhG23CV9V4onYBjQ435ieqIg==	10000.00	10000.00	LA	2026-10-14 14:45:40.262436+05:30	\N	\N
157	Ren402	gAAAAABqz0g8wPKWuvKlh3HOUhz4RYpy0lRJOXtr5VheiNvQotamyJetGc0nyltCMi1s8wdyzOHjQ3A-f02NOpW6u4VIp0_2WA==	10000.00	10000.00	LA	2026-10-14 14:45:40.374156+05:30	\N	\N
162	Ot7013	gAAAAABqz0g8lb3VFKwEN2haojJ-XFMAFKeUmzIfvUPsUMK2MVARA93SRNVVBW_oEfNGkX-nkff0HzRtmOvKl3lXI4rcb5mljQ==	10000.00	10000.00	LA	2026-10-14 14:45:40.471607+05:30	\N	\N
167	Jrsdb1828	gAAAAABqz0g8RMetPRMUSKvzQRA9RnhfWHy5PkaFw7vKlzIDBji72xwnMrd-p18-N34FIv6394zsV6dYKXEzDbLHvEWycVlBkQ==	2000.00	5000.00	LA	2026-10-14 14:45:40.556327+05:30	\N	\N
172	Adamc4488	gAAAAABqz1G_oJprscu8miAX0PqSBQBqCBZLgM5EyQtuQ7bUrgAnoKvgDIu35-1qYYwXQDY-shrqItIEDf0PIDnsp9ZU76zwjA==	\N	100000.00	\N	2026-10-14 15:26:15.238839+05:30	\N	\N
173	Affm4488	gAAAAABqz1G_L260NLUxN7DAxbSSYXyaUqFRJ6UkBHnocfyYBIekgiUXHcOwtKr8kmVqCfD1XfbYMiTb6QKuDqhKGNEXagvzFw==	\N	100000.00	\N	2026-10-14 15:26:15.282246+05:30	\N	\N
174	Brea4488	gAAAAABqz1G_6F2p8yqXx6xbDy1-5V2A9IPhmzFtIKWE6OXhFDYsdmbFUG-m5F-wi9LL-slplOx8cTnqfpN6ndgNT89897PTnQ==	\N	100000.00	\N	2026-10-14 15:26:15.298659+05:30	\N	\N
175	Kb386	gAAAAABqz1G_dwUS76kWr69yYWWUyabuZ38Bqz8I1RAGmg2vKEbcIZHtw6rUnnubNxOvVO3vUq-VNRhVlg6dc_AB92h5zQM7oA==	\N	5000.00	\N	2026-10-14 15:26:15.313437+05:30	\N	\N
176	LNK566046	gAAAAABqz1G_tS4Y4Y7qQq2wvYNkCiBpss5AhvOSXP7UHFZal1MaZqcldd3aN8eqKNFwtooDDl_G199rZm3RA4yI8XcTLy1Jiw==	\N	1500.00	\N	2026-10-14 15:26:15.331102+05:30	\N	\N
177	Alecshurd	gAAAAABqz1G_EGT8mAPnMXsSClToNGem41_XUv8fcp54bf1G5LMRjwRRY52PGgRn2ud-RjFpAA4Yl_dfeMv2kRpafCn4ugfyxQ==	\N	1500.00	\N	2026-10-14 15:26:15.346805+05:30	\N	\N
178	Ccb564	gAAAAABqz1G_24VdVqoz2hC-NvYHK53Ft9u0FqSi0XXIxkAIws6ygAmDRYIBw0qp1LuikHwLZp5gAdeRfIERwq-ZhbQIU13y4w==	\N	2000.00	\N	2026-10-14 15:26:15.362772+05:30	\N	\N
179	Sk307	gAAAAABqz1G_5v0AAvjcBEPzc25g0aW8Ns3eh5efmSRx9vBKqkL3XKp0sY3cubrVMpmdlqnJYV6HnwHQPpgmOodWzB7kdblhcg==	40000.00	15000.00	Montreal	2026-10-14 15:26:15.380623+05:30	\N	\N
180	Snir4488	gAAAAABqz1G_borg_StTw_FDukGdYkOpC8o7uzXinNSp1pSLpZs6YrGbWn0rPkev2NPjqCCuicIlynkUCEQJwfap-yoTfYLvvA==	200000.00	\N	LA	2026-10-14 15:26:15.398128+05:30	\N	\N
181	Wc523	gAAAAABqz1G_Uv0BU79C67e13ykxg9hfuvsBdlQatoqnDdisbr0to_yEZn8viEa9v6qmJYMgaCJuKulA7iNznyjMMD58aiakKw==	10000.00	\N	LA	2026-10-14 15:26:15.412466+05:30	\N	Infinite
182	Mma602	gAAAAABqz1G_CWt4kCHk1x5ZTOcKG4wn76Wkcn-_Dt10xlexwWfVLLHw0ziVkCnGH3hvvTMEtkc1815VSaPMwOYitnUdaG5Q0g==	10000.00	\N	LA	2026-10-14 15:26:15.427352+05:30	\N	Infinite
183	Heo209	gAAAAABqz1G_Jb5I3qnFEWOrHVqGbhx8qm-G-q17xoOeykG0r9_1rjF2uTDPe_PxNXvGynjX1wKiuf1MqZTGmmF5Z9ZHgDisPA==	20000.00	\N	LA	2026-10-14 15:26:15.441801+05:30	\N	Infinite
184	heq104	gAAAAABqz1G_O_AG4zK7ry-lIeelnlMpoNaT2cahqcOcbJeFPFjRgagjzscDMyV-U8hP64s-PNehP3f9TY8624IxdqOyAglHmQ==	10000.00	\N	LA	2026-10-14 15:26:15.457779+05:30	\N	Infinite
185	Al101	gAAAAABqz1G_CzL1n4t2n2p6t_0HzzUeGxjpDwBboolcHvuevA56ak-gzR4gaukcXJ0EmlOrQKwWj2YzKJLVubcnWcNDWqWMYA==	20000.00	\N	LA	2026-10-14 15:26:15.471454+05:30	\N	Infinite
186	Pn485	gAAAAABqz1G_4JoWR9ZmzbNH3pEYmWhKA4OVLmQyDSbC9BaXQeAtXfWolJVLpvkiICEh3FSuYFz2na0rj1lC16f6rGIEs78tKg==	10000.00	\N	LA	2026-10-14 15:26:15.48782+05:30	\N	Infinite
187	Prt115	gAAAAABqz1kfDnEwQ5gKjUDbIBzHIT0-im7Dtcb7vyR2zBht7AD0QOBwm4FxhqtuSQF6Ue7kZL7jXizzwk1cZv3uFg1Dx17yQQ==	\N	\N	Dallas	2026-10-14 15:57:43.147932+05:30	\N	Infinite
188	B3361	gAAAAABqz1kfvkcz7uaiPJnbKOzym91m5gBw9s9d71sGwEJcqmDgenGy61CfI6lPa4iPzDNVZDTWUr3M55g0AjGULiU6K-aHHA==	\N	\N	Dallas	2026-10-14 15:57:43.17987+05:30	\N	Infinite
189	B3357	gAAAAABqz1kf18K32PmvH5DPpr8Ed3OPgfOHy_f0emGC7re_Xvcjlp-DSTvLefcnz88McKTJt3_x2RdW-ebER9yuy2zPP5G3Ow==	\N	\N	Dallas	2026-10-14 15:57:43.209565+05:30	\N	Infinite
190	C2026	gAAAAABqz1kfVsB_68H_f5bY0EclXm3qfJnTkBeR3dcVTYgPLOQVT6GwrHZXRDKgX9RobzHRSJmoCug9m9-DNmu_p--LmC5F1Q==	5000.00	4000.00	Austin	2026-10-14 15:57:43.28465+05:30	\N	\N
191	Vs19105	gAAAAABqz1kfUbZM6A014Fv9aCNkYakC6U0H1wz9UayNq3DNFKdxtn9IMx--sTB5zd4D9C_OB8DkyiBKAQKgWMIfTPCyvuwsCg==	500.00	1000.00	Austin	2026-10-14 15:57:43.313281+05:30	\N	\N
192	Za037	gAAAAABqz1kf3Lo7KXbYQNgFKWd7aB8C-Ijws8-ilKii8lsJhLTr4EWRPWBQNUoDS_jCZueehRtVUihdcO-C0bkwa1Nlggz1jQ==	1000.00	2000.00	Austin	2026-10-14 15:57:43.337577+05:30	\N	\N
193	Hom198	gAAAAABqz1kfyT0Oj9Uw6becw7e8261HK2e_UmCk1jrYpCc3uiieenKo5rbRiQq-fA4_j2AFw7X43n8zlwE6-kqDnqC0fE0K9A==	750000.00	250000.00	LA	2026-10-14 15:57:43.359671+05:30	\N	\N
194	Arr5	gAAAAABqz1kfNZsJKxSfQ6mmjpYHNo7Hq2xgmi3gUGF6gxWgwFavfZGg1TETibzeUQXJPor-8Wj3k0U_gtAU16d7x8zvPKWzFg==	2000.00	1000.00	SF	2026-10-14 15:57:43.382213+05:30	\N	\N
195	Mm500	gAAAAABqz1kfbiB4iJsBLFODiFacb7LVh6M3ai7jjc7x7gKlTJY2KSLkgh4oS6SWCV2aYtK_myr7VCa-oY-3xjywYeI3YB7iIg==	2000.00	1000.00	SF	2026-10-14 15:57:43.402731+05:30	\N	\N
196	Z428	gAAAAABqz1kfed3oV1ybe042A00TZzPp7R13cTG27_612XREFsLCp086jvVHmCwkvzajkWeLlQ410OizssEFkiEjw2KBLfaUlQ==	20000.00	10000.00	NYC	2026-10-14 15:57:43.425248+05:30	\N	\N
197	Xc300	gAAAAABqz2RRufTaAwSbzO6P7exhECAiiPKLCIaLjU5APAecGtqU6DXYnpHNvvPgrae6yWOQRpxyxouQdTmup3sEJGatLyRvDw==	5000.00	10000.00	NYC	2026-10-14 16:45:29.824258+05:30	\N	\N
198	Milk991	gAAAAABqz2RRVlnPT0MfSHxfW_4K5-DaQYgNObcWEQicYvk8UFmnJE2OTgB0V6-kMxpXaCbCkf5RZgESk_HnnUGSA04Glns9iQ==	3500.00	2000.00	NYC	2026-10-14 16:45:29.853261+05:30	\N	\N
199	Boc115	gAAAAABqz2RRmemnI-WBLPXFT9KT5BtyxNUlsIqTIEQkZ2RjMHKoBpLXolzMXvCLjl4FMnX5399pz-267tbIofJYOKw0wMDIQQ==	5000.00	15000.00	NYC	2026-10-14 16:45:29.869383+05:30	\N	\N
200	Ag701	gAAAAABqz2RRIefih2_Pl2S2mlMWldc0n4d-1ESird0m-BiTtVq2RCYSlN9idKI7HkuvJCMabbIe6HVw36_sY0N_gY_H0ZkcKQ==	5000.00	4000.00	NYC	2026-10-14 16:45:29.885173+05:30	\N	\N
201	jack18	gAAAAABqz2RRVRIPBzOYASSEE5MqdnRsBCFitGGL92IXBNrb2E3RgyQAoerq9Yh-jsXAl6XYDy4dAqEpbpnzhM46Q3oSEIV6qw==	1000.00	2000.00	NYC	2026-10-14 16:45:29.902469+05:30	\N	\N
202	Xk352	gAAAAABqz2RRVpY3X5uisu_LQORabLNKj6pIXO3vD8oRheVqVN7WTD_4AS1DB10w3DRBTaherYo22yFZQjJFgmID8vphgu-vPA==	5000.00	10000.00	NYC	2026-10-14 16:45:29.921006+05:30	\N	\N
203	Kog4004	gAAAAABqz2RRSmEti67Hp1aYE1g-tIwOo9fFi3ywsgpc3ECIHcJlESTjyvShin7DhjzIDODCy6xxMUYBo_p4MIJ9aCLPCc7R_g==	2500.00	5000.00	NYC	2026-10-14 16:45:29.937548+05:30	\N	\N
204	31001	gAAAAABqz2RRW2M398pERjNozuTe1J2AXmPVIrgc_vXfnP9fXrb-udaSKrZ6jKWCEslNXT94YJVileWbMPhwAN-mZvxnMEo36Q==	10000.00	10000.00	NYC	2026-10-14 16:45:29.954887+05:30	\N	\N
205	Ford101	gAAAAABqz2RRjQxrtDYxrAcE_lfWNXkEi31COCQuQPi71Ozw8qXYMx9tXeFcKTl2of6F5fpajgXBcX9nSbjC6dUceWwFQ-7gUA==	10000.00	20000.00	Brooklyn	2026-10-14 16:45:29.974242+05:30	\N	\N
210	Jr1057	gAAAAABqz2RStg-QSmfZrtyAFjNtxrT9OIxRfMCqX65KOYw7N_nr58hE8Gdc9xg_ZjEjXkmGvyXVzu9QhtpoNfC-mbGvCXAVtg==	2000.00	1500.00	Dallas	2026-10-14 16:45:30.07407+05:30	\N	\N
215	Dd6	gAAAAABqz2RSZTMJc7d9oUj1EmW-Z6MLhzZkdgWz5V1bCPQNCYHBItppFAv9CKhrdj-lc0f9umn9FLlBDjRxCuf32MP3izXs_g==	1000.00	1000.00	Dallas	2026-10-14 16:45:30.218936+05:30	\N	\N
220	Douglas58	gAAAAABqz2RSjl3fjauIsNVqFBH8coxK68w0Pxv4bJim5LRUW4Hyra2LQuirWplg0Q9MW_7mHPkYRnOcIVzyPvi0Eha0NCmcDQ==	3000.00	10000.00	Baltimore	2026-10-14 16:45:30.317252+05:30	\N	\N
225	Lv172	gAAAAABqz2RSRBQ6fFBqzBrK8JhwVFHvwN3Xs1jmiZdpNVm2cuL0dMYJ5fKmgciPBfiluCpDLhJn3Rf5uzTHI09MUMSdqtOX_w==	100000.00	\N	Dallas	2026-10-14 16:45:30.412246+05:30	\N	\N
230	Bgg428	gAAAAABqz2RSE0ZaC2LfZLT7fvEgpRhrV8lpWHMm-rH1NPBV1awfxiUAvCYJ1UdnU2KTiw1hIDxgsUSo6reEQW9VksoL2T_D1Q==	100000.00	\N	Dallas	2026-10-14 16:45:30.513833+05:30	\N	\N
235	Ord1014	gAAAAABqz2iMHzpa2DefFjDcdWieTo9oGS-o3awd2glcsm_5lkW_F4GtRuuwz1vzL8FOKBT4q67eN1zJUVMcmGyHNykcattsWg==	\N	\N	\N	2026-10-14 17:03:32.974849+05:30	\N	\N
240	Fc5000	gAAAAABqz2iNTqqKKvlj-NOBzv-pGnkskBFvVyAOxRSiZ9vA2bHi015SR2ZMoX13L2Q6kAnvlWcSVLZ_RX77nfXxnSIE-m4J5A==	5000.00	3000.00	Houston	2026-10-14 17:03:33.063825+05:30	\N	\N
245	West25	gAAAAABqz2iNsVRo_NxAlmlxuPso8WcmMgtUIwV75bMCTEN9yvsaMlm0AMtRvHgPLY25QRgRoiB3sWBBDseenJYiIMkgRZNGsQ==	1000.00	1000.00	Houston	2026-10-14 17:03:33.159304+05:30	\N	\N
250	Htwn17	gAAAAABqz2iNr9vDVIdyuivVsyG0SXn7tllVa4qGzwugDcMkfIpAoQ8uzi_cjLAjmsbtYJTYogg6Vt1hFiW47IqTPS439IcFWg==	5000.00	10000.00	Houston	2026-10-14 17:03:33.344151+05:30	\N	\N
255	Mg43	gAAAAABqz2iNrVec3ihWRSGV8H59tFEFcdNJbB1mpWDEuAfe3NYcNP0Rg5LHgs2zgkOp7y3c72cxeZtKlcw3f3B-q54069gTRQ==	\N	\N	\N	2026-10-14 17:03:33.452108+05:30	\N	\N
260	Nw10076	gAAAAABqz2iNOra-r1Z6z1gywndxoCgC3Q2rTNCTpNiYhxYjpBXyanD1BI4teAwncfZAF8j6JAaPPI7WgPYMw97-WdB-BQMKhA==	\N	\N	Atlanta	2026-10-14 17:03:33.546345+05:30	\N	\N
265	Walfin1739	gAAAAABqz2iNx-7lYHZMCadxdJRBUX6GHo1Qnq9_GhkiMPqjEaS24DFZ8hYHHmbXjavUG1YYP-K4MgjRMUNc4hRhSNLET9KgrQ==	\N	\N	Miami	2026-10-14 17:03:33.642765+05:30	\N	\N
270	Qxcrd131	gAAAAABqz2iNrsNi87lyaxkyRZA1Wx6y5ueLWUupbqGaFq-aKfr2riYfNiwEl_A_amdTv1MvvCq6u36i2q6Ovn14DzF6XMN5YA==	\N	\N	North Carolina	2026-10-14 17:03:33.735131+05:30	\N	\N
275	Bltz10078	gAAAAABqz2iNAyOr0-Lv5VRK2G9LK5Nm0Zv_Wwa0bkKjwrSswH60hzn7Y6DkE7ggLOCtG-syqt3L5B2PWRP9RkG0Kp_TbPBI_Q==	\N	\N	Dallas	2026-10-14 17:03:33.83344+05:30	\N	\N
280	Jb2152	gAAAAABqz2iN2Tb3mlt4iJbUtiVvKhtFFvDuuNuH5LYSOutA8Q7kWZafXuArLVNk3xEPMt6TqIj-ALlIDsqA2hhV2C1ec8dhUA==	\N	\N	Miami	2026-10-14 17:03:33.931105+05:30	\N	\N
285	Dae513	gAAAAABqz2iO1P-yfPXmKMwaSNUUlYEv4PVp_w7AQSLSXzc4dKw00Nh-hgOkXLh3qm7H1EU1GVJ-vmD_a3ql48jmMnbe5mAoNg==	\N	\N	\N	2026-10-14 17:03:34.02727+05:30	\N	\N
290	Tn320	gAAAAABqz2iOUazWA2XbwmHebDtLXSFK-S158IiArxTjt9_juqdSDHlScUZttqyJxlK4g5WBciLUThJAG6zr4eHgiLYwuhaHWA==	\N	\N	Miami	2026-10-14 17:03:34.124219+05:30	\N	\N
295	Tb356	gAAAAABqz2iONaMbFYRQMOnLDW0q5UwV8c9j35wH9MxldPUe0195_qkPN3Z58TdHWl5-N9DW79Fgi339dDoh2AW5idDMzFdBfA==	\N	\N	Miami	2026-10-14 17:03:34.224376+05:30	\N	\N
300	Kcc1	gAAAAABqz2iOveXUyMXs5eZ9Bbrf62y0UQ096yQgoHtQNsxVIiTuRcmHDfegpV0oNKG2zTIcDJR8BT8Og9D2p9MsOO8u3IlFRQ==	\N	\N	Alabama	2026-10-14 17:03:34.320567+05:30	\N	\N
305	Apo102	gAAAAABqz2iOgAY5eWzSD9Hrx0PK9tL3ePPEy4KCjbH1bUMZEhLM34V5HKLZ3BPlX8PZcDxqRTWqLfkj4fOGfgfJcNkq6gGxKw==	\N	\N	\N	2026-10-14 17:03:34.420129+05:30	\N	\N
310	9465	gAAAAABqz2iOYzmi3_XaEE08IdYy4YVExv5WFTw0MMnHHuPhK8mxEwOWi2KLZWXD-qLGQN767_n0Y0o8BzHcnZNn7s787_C0gg==	\N	\N	\N	2026-10-14 17:03:34.517599+05:30	\N	\N
315	Trbl378	gAAAAABqz2iOWDug-eHJGjShMVoSrbqAMPjbn6FLJeKkc4-H-XRMGdKCs1_IhXUPYCnwud_2rANGa_ssel7kuZ6JSLxlE5fn3g==	\N	\N	Miami	2026-10-14 17:03:34.611987+05:30	\N	\N
320	Trbl372	gAAAAABqz2iOYS84ZlhfARcNDBgI3HR5ydujpOk78FwCkA3lNB3wJ6InJoJyJf2IWtNCFXUEu3-T7jqTovrr8o5K5L0GIJugZw==	\N	\N	North Carolina	2026-10-14 17:03:34.706484+05:30	\N	\N
325	13-729	gAAAAABqz2iOq56h5uGGJcF6uIY_W2-YUwl3Q-u8zfygB3l2NP0UpcCekFYwjJd6U_j-mbRtrBRBWHakiBa0dEhklyCk-F7_nA==	\N	\N	Atlanta	2026-10-14 17:03:34.800174+05:30	\N	\N
330	Gryp078	gAAAAABqz2iOpTppB1t_cR3U2-0EsinLBki4PYRyfoCLo16mcM2emT6sFKGClfjh68lzIQoAxunHnHsdmOCpvW-NMvNmJ-bLFQ==	\N	2000.00	South Carolina	2026-10-14 17:03:34.896703+05:30	\N	\N
335	Kaf265	gAAAAABqz2iOlptVH3RrCZ0e85GfNHKwj7VEa3YOOG6mzxq6lfBVIXWZAejQcrlIpcmfLb9wSlDnGZJjK7zQfJquLDHIVROPmg==	\N	\N	North Carolina	2026-10-14 17:03:34.996868+05:30	\N	\N
340	Zpt843	gAAAAABqz2iPBc0qEEV9CBawuHkW5OeGVsdeJv0XmuAVTMGjviI_nIybPU1JSavvt4lzpWSykbZVqTwhqXdrggp8IH85FjRNvg==	\N	5000.00	Miami	2026-10-14 17:03:35.101879+05:30	\N	\N
345	Bnt107	gAAAAABqz2iPm6JD5cw4aPMNlZ7HXcA8a_LWU-LJ9m0_TNeud8bmjsPIhNC7-h_ZY0lkCArWy9xVJg_BUiQqgsvgOGcNsROOJw==	\N	2000.00	North Carolina	2026-10-14 17:03:35.203664+05:30	\N	\N
350	Bnt109	gAAAAABqz2iPJ46LI13ePASpU1RPnTCHpWykmjGVIF9km-ZqQemvFefALe25MJFVOoKrT9ETwD5KFBXBfm0-VgIM7q_tuE47ag==	\N	\N	North Carolina	2026-10-14 17:03:35.311183+05:30	\N	\N
355	Gp44	gAAAAABqz2iPaqJdqcY_LhuIN2QHUBTLTb3VIugwa3FWrmJB5tyAvT8QklTP8edZeB5ZBfpfcyswxYvZr-Fcm9My-HJDALPCsA==	\N	3000.00	Miami	2026-10-14 17:03:35.414554+05:30	\N	\N
360	Tig101	gAAAAABqz2iP4T8dfPvOb3zfB-aaUSqxUrbRL9QMLAs4gKu3XJSCgtyhIvwRyZe9TrLBh1DCq-olk_gxdxu5ocWDYSJ-KPvYZg==	\N	\N	North Carolina	2026-10-14 17:03:35.518259+05:30	\N	No max win
365	Jh183	gAAAAABqz2iPwG6pFCcN5AzVWE-nu50RVejq--t2UBm85hdgOXUOmdZNqD-Ba0P0LkMRcQ8zl1HhWfouowsQDpWxzGtfVaRVRQ==	\N	\N	Miami	2026-10-14 17:03:35.620229+05:30	\N	\N
370	Jh216	gAAAAABqz2iPIpbqEfYvd7Wlllqdk_S4JY0Gyiwi7lYBL2srBYLkZ-4TSSvlUkFyel8hrMNOXfYV5MLaAKfLO59DiclOEc8w9w==	\N	2000.00	Miami	2026-10-14 17:03:35.715779+05:30	\N	\N
375	Jh207	gAAAAABqz2iP1UsOm0m4_Zt1XT-zemnoNmd_eU3G7_9U8-sY4hzClOaA4abhWG8Zn_1R6w5aBt7dS_9yUgnseC8Pkq0hIHImSg==	\N	5000.00	Pennsylvania	2026-10-14 17:03:35.809568+05:30	\N	\N
380	Trbl371	gAAAAABqz2iPdNLq26eT8aHuvLW5hOOnly7DmCuCWEexJCE4lJQ_CbsurpALI8uG_e6x--TQv3c5F3RM_q42Hm7uyhvgyjbvxQ==	\N	2000.00	North Carolina	2026-10-14 17:03:35.907405+05:30	\N	\N
385	Willh610	gAAAAABqz2iQ-pEsppMXB1M8NjvgHFhiGNrukQkJCGVRbuNB0GhbWRT2Vo86Bgy06ZowCPEQ_LuhVU3hs08FFIV11PWkJHs2NA==	\N	\N	North Carolina	2026-10-14 17:03:36.005925+05:30	\N	\N
390	Wc22115	gAAAAABqz2iQyCGPnAv42YbjxgmJm8MZX8WcTthNbfDl7khoOEKJ_vj5qfZ8wvb4sEBKXETn-hwkepCnn9DmZg8SCUy22YPfAQ==	\N	10000.00	Miami	2026-10-14 17:03:36.104899+05:30	\N	\N
395	Xjg4546	gAAAAABqz2iQCZnVf-h4i9brxegwkVDLH8nTxIowOv-1s2UgJU2Mn6wm30Oadaae7d15m75xT_49PZfH7c0ADRWt38tTY8SRkw==	\N	\N	Miami	2026-10-14 17:03:36.20217+05:30	\N	\N
400	Cat6712	gAAAAABqz2iQcBcraj_u6VKgDWnSSRbxK1ZkjHryAebd5VGM8we9JH0J1ScNzeopHT0BAnt9P-a5_fMeL_thMGO_2B7MCzp8QA==	\N	2000.00	Miami	2026-10-14 17:03:36.299115+05:30	\N	\N
405	Trav130	gAAAAABqz2iQxHdMjxodSDM9p9-XPwQ8kp7yxdhohUZPKzWfKxNzjlzkiq2q5bUL_E9FLhDPDJ5WVHizTcefWdenmLSkSYW06Q==	\N	2000.00	North Carolina	2026-10-14 17:03:36.391944+05:30	\N	\N
410	Jb2166	gAAAAABqz2iQWu1eiP8O3UzfyDqkXoxzk0GBVDFSouwByiDNvPec2EZpeEfoBldw7ai7D-kJcpe7E8M35CjwqDhMLY1e7-pzDQ==	\N	3000.00	North Carolina	2026-10-14 17:03:36.487512+05:30	\N	\N
415	321	gAAAAABqz2iQDw7crjqVvQFUPHxswIjWBKgVM2L9gPAJb8NXPc802xUzF3igOpv3fbQW07ZwBgflGF6qhrSIXZDI0cZd7re5YQ==	\N	\N	Massachusetts	2026-10-14 17:03:36.586771+05:30	\N	\N
420	Gcl206	gAAAAABqz2iQ08ycdCB6lBhrWj18-pDx1-yphhAaHQ8DlpMypX-E-lsgobm-Rb7CjfoWKctVbWZxKQXOdLfFeE8rjtiObS9_4Q==	\N	\N	Washington Dc	2026-10-14 17:03:36.68373+05:30	\N	\N
425	sn133	gAAAAABqz2iQqv7G3PFOP_4zQjoKeQTc5gjQdBCFYKDP0_NvdErdIaL7K3bcxxmR6o3oUZts_zJtWgLnvdGMj_dWt0jDJgfL7g==	\N	\N	NYC	2026-10-14 17:03:36.779498+05:30	\N	\N
430	Dj1040	gAAAAABqz2iQjoeO_nHuX7v0aDTdTI7Wc5AtFBMC_g2LqbEuguYItH1sOLQQZJ2lBAD_u_QjXjFSNNjChNBRx--hvyVgfYa7yA==	\N	\N	Alabama	2026-10-14 17:03:36.873476+05:30	\N	\N
435	Willh609	gAAAAABqz2iQ3ol07EhToLl-CRYvcUVZX3ks-LCiSC91ZUoLwyAOEFhjUP8_NPnkg92bHf69IxCRXH37ryrG2Zl-E1zwQUWgng==	\N	\N	North Carolina	2026-10-14 17:03:36.967429+05:30	\N	\N
206	FD12	gAAAAABqz2RRQ3EZ6GagnzcAL_clc9PDR7mokvLmz2zt6WPDMdAO538gZXuYR406lf-0bG6QGexAz_U9xxsZRVd6bjjvK2DDDg==	10000.00	15000.00	NYC	2026-10-14 16:45:29.999394+05:30	\N	\N
211	Dmo5	gAAAAABqz2RSZmJJYv3nhZTP3d84ta66CXO8v0TWJbUAK_bDKd4i35LC1UcbetHShv5YO6yZ9iU2T8OQnSyMY8oFtBCANoi-GQ==	2000.00	2000.00	Dallas	2026-10-14 16:45:30.125881+05:30	\N	\N
216	Ao326	gAAAAABqz2RSwvQ3zjzgzvMOyTtm_hW9eIlz3IVfLjs6QZAyk_t6ShGu1fDyzE6_IANtBHQJlFU-dAqtYsyebR3hCUvR7p2xcw==	1000.00	500.00	Dallas	2026-10-14 16:45:30.237113+05:30	\N	\N
221	BC156	gAAAAABqz2RSkEEFCL9IR9QLU8awEQbu5t0sHF6upPSGq7SDffsTPUllMuWsiqpf1ws_9RhaKDJ3jkBZfMa0ZCF1aJD-VGlhDw==	25000.00	\N	\N	2026-10-14 16:45:30.337168+05:30	\N	\N
226	Lv173	gAAAAABqz2RSzXYmNa9AXztWll2jlm9YXeiHY-7THaJdfSLx3rGFY5k9qfhlcSIi5IoTufFdev3rzXs1uQrgxoByRJkPfRA-TQ==	100000.00	\N	Dallas	2026-10-14 16:45:30.432898+05:30	\N	\N
231	Bgg429	gAAAAABqz2RSlUq3FqLDp_Y2pWGNP704Yrqi1IZ-oeJEdHw_p7Zddzm16mArwCX6aV6m5jsEmBQEjscSAGwihS2edF56ylPPGw==	100000.00	\N	Dallas	2026-10-14 16:45:30.531654+05:30	\N	\N
233	Ry120	gAAAAABqz2iM0WTk-nWr13kIjuxEb-Zpl2lgBtQL58-5fCnjmyGakGQMS7_L7POtwjqKWBSVGi1sNmcXTNcbkD8y4g3IbDpShg==	5000.00	\N	NYC	2026-10-14 17:03:32.930371+05:30	\N	\N
238	Gtr1001	gAAAAABqz2iNvB0mcywYtxnu0R9SnD4R72EYz1vRX84jCfauLZ1iuBXQsgBEA_3D8XC019Qf-1O4NP3MU9ioMN5f6JaJo93E5g==	5000.00	\N	Houston	2026-10-14 17:03:33.024959+05:30	\N	\N
243	Tex2506	gAAAAABqz2iNXq7sXREQKuj-5DBTJIvq_bgKCE93rJeOE-vyFnd5yR-IX0P-ubdAN4KFUVhNb-zJXlBPNug_7n9RYK_XUMgvnw==	2000.00	3000.00	Houston	2026-10-14 17:03:33.119647+05:30	\N	\N
248	Htwn26	gAAAAABqz2iNp5btH8Wsn3IbzaykdhfAkHFXKvJEk2eh06j1K60XJ-PLsHQ52dWOuOGIf4BDz_uO9rlBDqa_fews4rGdj1KLMg==	5000.00	5000.00	Houston	2026-10-14 17:03:33.284608+05:30	\N	\N
253	Her27	gAAAAABqz2iNrbAWMYOO2NEUu3UxEUGr6OxK8cbiguIQ9r8wdi9E9EV6x36N8mvR3oaKxHXx2ZZgIpzeOsLqGqJ2xpLE0P9HnQ==	5000.00	\N	NYC	2026-10-14 17:03:33.41296+05:30	\N	\N
258	Teab04	gAAAAABqz2iNlQmeLSazwd0k3bsNpC_wOgEfEUV5ewlFoGBfI3EStTjBnSPlFMAiJgr7EsZ8OmnY05y4vR8L5tZCP4J5OutfJw==	4000.00	\N	Aiea	2026-10-14 17:03:33.50754+05:30	\N	\N
263	80883	gAAAAABqz2iNVt0iJsJUj4-F-Tv6Tg9jWufgO47KwRS5fIk1UUQHqEfL5Wp-99VjcChBVIWsmdIkg7-U_swCegZJAJ8ZpoL19A==	\N	\N	Miami	2026-10-14 17:03:33.603382+05:30	\N	\N
268	Gf101	gAAAAABqz2iN-yVCeuz4P9yaxIlU3bVFb187Ai79uamTZav0daX1NgRsSi2vyUO9W7s6XldjCxgFS_W0dOV4kZA5QD1SeAFZkQ==	\N	\N	Miami	2026-10-14 17:03:33.698103+05:30	\N	\N
273	Roa7	gAAAAABqz2iNJ-i3K0XLTF-3RWygn2YaJNBjB1Agter9LmL8rS1NC6TaqA-kKunw-O3GnWgnVrEHBdCYoz6qHCHQNK6EnSSaug==	\N	\N	Dallas	2026-10-14 17:03:33.79512+05:30	\N	\N
278	Cf220	gAAAAABqz2iN30qJL1yytwdXyh-SAABHlzEi0oRwAmr6TdB9AnY3WQPcYEBiKir0tRPEjdtUQcPViojhbLvqAVhZxjP9dKkGWA==	\N	\N	Miami	2026-10-14 17:03:33.892275+05:30	\N	\N
283	Sgold5	gAAAAABqz2iNb2__Acpdo0VGLNbQ-GAFvMCVOhfrozqeeMtV40oUwLg12i-hvJKxc_BjPmfWQrJlyrlfsqgyAgjp6K_573TY1g==	\N	\N	North Carolina	2026-10-14 17:03:33.988213+05:30	\N	\N
288	Lars262	gAAAAABqz2iO95k1ineXP4MHGLJRf10NoICUJ_l9JArD6N_bAbA8-5KFXxQJ42ud9yHVrJ0g0F6nEPKYQvOoNq0LjkOa_s8b7g==	\N	\N	North Carolina	2026-10-14 17:03:34.084839+05:30	\N	\N
293	Tb382	gAAAAABqz2iOknZS-T_61jXH5wZ0DtiAoOgrz5194X1Y_HpzXqT5Ccvw2TK9UNaWldBN3O9sDuxlwA5q74et0MjJau_FSZ4VDw==	\N	\N	Michigan	2026-10-14 17:03:34.185906+05:30	\N	\N
298	Zpt855	gAAAAABqz2iOkp5S7JFMkBreMyCWzH93NaxlgAmFssngBPSrTlNxeOGM8SBwglcZWfZdlO_2bUAR8W2cLUVQtm2YFaSIzs_aFw==	\N	\N	North Carolina	2026-10-14 17:03:34.28282+05:30	\N	\N
303	Apo100	gAAAAABqz2iOkxWil4EjDoVDCm1mSGSwEw2OOY7MpcdslcyTXtMrGZkxCMLNNBOaKQdoTraK-kWvhc-Tv-TY3ZQaQyEkiJwazA==	\N	\N	Miami	2026-10-14 17:03:34.382806+05:30	\N	\N
308	9901	gAAAAABqz2iOFRyXF_sg_VpT169MfyZW_Oqm-fJjEaqsSwHeS5xyyUgANxMtws9SV-oUMAm2RtwUtWHMbtSQvZ-9gG4nnrclvA==	\N	\N	Massachusetts	2026-10-14 17:03:34.479324+05:30	\N	\N
313	Mia191	gAAAAABqz2iOovLXuIXolavv0W-4WuWQeH4OhmQqxOB9Wu6yYXqkyDwWF3SbPywZpoxzXbzpIs3y-uwuJVLCUCBXvq5a1YiVGg==	\N	\N	North Carolina	2026-10-14 17:03:34.574278+05:30	\N	\N
318	Trbl380	gAAAAABqz2iOPNY7gjmnEtIUvIBUf0LozPelvaKWTEBKldSt3PCzshrECYpeKRiQpOxdCpXz-aBeuLUJq6IQ-2EIGVbkr_lUyA==	\N	\N	Miami	2026-10-14 17:03:34.667949+05:30	\N	\N
323	Whale252	gAAAAABqz2iOhx3HFYuddW1VALC2IGgetqKxrOR1xwRnBBiNYTv2gkDpejrnS9YAikgLlkffGJEWix_t2eCnYKp9yuFnKUp5xQ==	\N	\N	Miami	2026-10-14 17:03:34.761801+05:30	\N	\N
328	Bk141	gAAAAABqz2iOp1wftgUIRbZY8iUFqApuz7c9A1qzhDf8-4NM2pI80Cll8rexZ_l7_tfClRD0RFd3imoH54wfwKSruG99rqTTbQ==	\N	10000.00	Alabama	2026-10-14 17:03:34.858492+05:30	\N	\N
333	FL778	gAAAAABqz2iOZWoo9d3U-N8fiq-_LLOmZYsHqEyiNXhAmm01GIVKSNuAIWKqVR8Q2Rrdg_Wp-EPtEmEo1Rl5UWiTCscZrwM6hA==	\N	3000.00	Miami	2026-10-14 17:03:34.957187+05:30	\N	\N
338	dd0098	gAAAAABqz2iPqein_wIiwb2xFxHy5lOQqhnRtaWEXCOOoSKL2KrRuc9eb8YYm87Bd53UozC3kjHGDx6sGIv4StbI2uDZzCmhrg==	\N	\N	Miami	2026-10-14 17:03:35.059702+05:30	\N	\N
343	Zpt845	gAAAAABqz2iPrS0RX9s9hCJnC6O9NkKNYEZFgUF9YQLg3jMBulEPg-XRDa65SY-wsNsF_cWcDcVet-NOJ55ImRk_-_a2jKevFw==	\N	\N	Miami	2026-10-14 17:03:35.161115+05:30	\N	\N
348	Bnt501	gAAAAABqz2iP0wG3u76aQ388zgZhtgedOKwpz_T8taZ5PPQeBN4lwhqrhSMSDWoH2-gNn53-I0jEihdvVTm0vuJgl4UTgAFQCA==	\N	2000.00	Miami	2026-10-14 17:03:35.268057+05:30	\N	\N
353	Giov227	gAAAAABqz2iPNWmY20pIVWrnagLp0_LYFgAU6ueX9kDYZa6mJntyZ5tLIIuqZOMqUefWo8ytPZfyi3NamMVWCeFO899YdC-KQQ==	\N	2000.00	LA	2026-10-14 17:03:35.373354+05:30	\N	\N
358	Tig111	gAAAAABqz2iPYDRbVD6JK65yJlVo5OU4XnSeTo6M02bCs635H--w7riI4DHSVunpuGSf-TByApmtjse7PVPcMQOSx0Ky4W8MWA==	\N	\N	Miami	2026-10-14 17:03:35.477009+05:30	\N	No max win
363	Xjg4531	gAAAAABqz2iPLxBhJdYkCAtl2_Za1evJkOQT0fo4YQjDsKyEYLO1MNPDKX3sj8qHmWkYOFTFU1ou8UfhkIhwGs8TxHfx0CXGpA==	\N	\N	Miami	2026-10-14 17:03:35.580139+05:30	\N	\N
368	JH172	gAAAAABqz2iPV5oTP1lsGqK4z9NsWg3Wg-AIuhmS1iir5VsNAj1uSSWXLHHpYb7lvoBy4aK8z057le-OJCTsNjtAwm6yYmMQ5w==	\N	2000.00	Virginia	2026-10-14 17:03:35.677514+05:30	\N	\N
373	Jh211	gAAAAABqz2iP6KnaGpgIOnranUf30Aoz7P6Hdc8iUg-bugJP5JC73cCX9bl_7tarsJmZPgVQfyZ2pKRDLRy6tF2nPQqfH61pSA==	\N	5000.00	Miami	2026-10-14 17:03:35.770562+05:30	\N	\N
378	Mia171	gAAAAABqz2iPufvQaLaPtMDFPCl8w4yViqNKBpRwNYRQ_T9doP5Hu0cvuTQldzgwv1Ud215iYJcDtghztIpyfyREYg0PL48j8A==	\N	\N	Miami	2026-10-14 17:03:35.869313+05:30	\N	\N
383	Dak21	gAAAAABqz2iPug7LjJlWfBx5mdQANScqKssNKQWzR-lYBoe9tpMMlxum3fwr9XeN7jiBC10sR8WnMN3brEzxsfVIA4k4kzGVZw==	\N	\N	Miami	2026-10-14 17:03:35.967659+05:30	\N	\N
388	Ss16	gAAAAABqz2iQ_TFpv60o5TCxvWompMOoggzfJBObibU0YjS6n0xqiLTsJfSbDA6l1nwrhQv6ZEWmoAJLRYaLa-4DKPK6B9wXjw==	\N	\N	Iowa	2026-10-14 17:03:36.066735+05:30	\N	\N
393	Pan940	gAAAAABqz2iQb7cOoABc0AZECScdkV0TY67lNHc7EshAXei9fQrznAaBUr4JmUmCiXsr2p0fyI1yEEAsSYGXrR-0kDalG57qrw==	\N	1000.00	Miami	2026-10-14 17:03:36.164275+05:30	\N	\N
398	Xjg4550	gAAAAABqz2iQvi9IJ8JugStpQkpLQNAUNMQW0ORjSt1oIGMtfYm4vJkgNTJe2112plz9M-elkcmBPibtDjpKa8idAkL9DxhfBg==	\N	\N	Miami	2026-10-14 17:03:36.259666+05:30	\N	\N
403	Cat6708	gAAAAABqz2iQmDtTtmUWxWq5lSe9xCo4t-K36JfIvEr03IB9aiBF_3HOcwax1CHJRrxNdhVX4aeOko9zAAaSsr_8E5-eZGMpyw==	\N	3000.00	North Carolina	2026-10-14 17:03:36.355167+05:30	\N	\N
408	Vin123	gAAAAABqz2iQn3WAhZ01nartkIUsWGn3yYwcG2wwbv-yljMWno4upsfDcL2UqpXRFGjdWf93zRfb-Ud8RbFCBwG0jnlU9KdGYg==	\N	3000.00	Miami	2026-10-14 17:03:36.449412+05:30	\N	\N
413	Ath148	gAAAAABqz2iQU1h1sM1VD5y6VLpQXZ-wLuEiBBFkOF5WripQFXH6ybWLvqABPUUAZxztBAs_XW-XoOIzLoBEJk0Y78ZLldyAmg==	\N	3000.00	Miami	2026-10-14 17:03:36.548358+05:30	\N	\N
418	Apo107	gAAAAABqz2iQatwSslOITeTqCZCvG57tPfaqQWdWHnXF7bbGiB3qroX-GuRaXBNyhYucW1onpnThVFEpjvWjbWj0a-wPr19SBg==	\N	3000.00	NYC	2026-10-14 17:03:36.645257+05:30	\N	\N
423	Ceo1283	gAAAAABqz2iQkzEeO9RDsFG1e-bahh61iDsKWKFoG22Hb2CAPDo7ynXJbz-sKGRd7ouoAC_0lfEq44uTpzChzSYZ0MN6udk42Q==	\N	\N	\N	2026-10-14 17:03:36.740814+05:30	\N	\N
428	Bal90	gAAAAABqz2iQXuuLLCztaOufpVxqSFEcwhBlUen-Bq88h98Pxz1PsQMh4dtBHbwVg5Q11OffbCmdHohKjxrFNVXh27tK2bsfgQ==	\N	\N	Dallas	2026-10-14 17:03:36.834362+05:30	\N	\N
433	Justal	gAAAAABqz2iQDgzPtWX-c83FiJrbPsYgB5dPiWmWsaPO0R0bN3c1kTo9Kgi3hkj2CMIOu0ggYAHFOgKCw3JEadUo34M-JoJv7w==	\N	\N	NYC	2026-10-14 17:03:36.930262+05:30	\N	\N
438	Jh195	gAAAAABqz2iR4VUsXB0iSXFXdDrWUxcuMsi_mCbi9WzeLyTT2XpT3vaNeqxjNmIbXc2-y1wp3KOquK2UIyTc0E4mYwxyqhZkyQ==	\N	\N	Washington Dc	2026-10-14 17:03:37.026028+05:30	\N	\N
207	7262	gAAAAABqz2RSq0_H97DvHDl2ocUhneu-OvNiEjvcE1yV4dC5SbAKuMaBrIJALFMI5Nr99i62IZD8NESl5cn7BaF2Urf1kKlzlg==	\N	\N	LA	2026-10-14 16:45:30.018791+05:30	\N	\N
212	Dmo13	gAAAAABqz2RSiA0ZfFBv81m02mBLJaIcBm35qMzPNkSWHjKHhmnv0MO_Mul-04eVviW90euvFQn_3ElFcg0rYD_wcNq-PmUXWg==	2000.00	1000.00	Dallas	2026-10-14 16:45:30.153332+05:30	\N	\N
217	Ao283	gAAAAABqz2RSpy_02whAJtOofjt6u-WNoMAeA2Gf6OTWDBIDQcYBwRsVyM2JqFB-WxufiofINJNZSlwC7439QnPuS0xACSgGPw==	1000.00	1000.00	Omaha	2026-10-14 16:45:30.26118+05:30	\N	\N
222	Ppe102	gAAAAABqz2RStLUidAZ7MRd83axdnstAox6xCOK475tcRnACVP4o60Ldfg4AkNAw0AHXADk6QFl3naaK_kfETHbiBRJ3bQOUPA==	10000.00	\N	Dallas	2026-10-14 16:45:30.35417+05:30	\N	\N
227	Lv174	gAAAAABqz2RSBbS9hoRqsg_XiEeOsdl41APFRVZNMvoo_CtXq7p0gxSGF52z0x5mENMFGcvWcGlNN73SUxGnLxwjyINN-yB3fg==	100000.00	\N	Dallas	2026-10-14 16:45:30.453776+05:30	\N	\N
232	Bgg430	gAAAAABqz2RSkOtMCjuMGnt7KMAIwwtdkU0hpVukDXajGagv3eqwwDNHrapVZ3IqgmLoJnUgwxjiK6U91yXdo1x7muG1pq8QOw==	100000.00	\N	Dalas	2026-10-14 16:45:30.550442+05:30	\N	\N
234	Jul304	gAAAAABqz2iMFuDUAAgyrvdBD_tMqJODVZjovCdPyiMXjdbUiSHmk-ZE15Dh2MwJ8p8IPuASA5QwOXswlJpXJ-7XqTXIrlvlKQ==	20000.00	\N	NYC	2026-10-14 17:03:32.95452+05:30	\N	\N
239	Eyg57	gAAAAABqz2iNLJLAWyMHV98LriBaYS6y9PbEtYk2nz0rhV2MNGe6SJNfrZSAp7wIUKayEJVrKaW_MkN1Od7yVS6Qi9Hpo5yN5Q==	5000.00	5000.00	Houston	2026-10-14 17:03:33.044004+05:30	\N	\N
244	Oc15978	gAAAAABqz2iNdcUOUak9fRIiGBuZABNCxPmqSONEEz42cMzj1Er-JT0lJ7CZ1v3ELOOtPlnczEbhStcD3LtSpaMAlWCmilzj8Q==	1000.00	2000.00	Houston	2026-10-14 17:03:33.138434+05:30	\N	\N
249	Htwn18	gAAAAABqz2iNYTgbP_KIIPg-vlObCFSopoIio-_JnkVX5TiRFrLqHJAvkAkUV__VFffEo9Ou_5F_vME7-aUH9feJTCawuSIf2A==	5000.00	10000.00	Houston	2026-10-14 17:03:33.32031+05:30	\N	\N
254	Dime89922	gAAAAABqz2iNUviwXpwwBH9K7YiDVi0SFGKbYdGydorwoaxWSOKmUuDakuECJC9L_KizizyW7rUhZivH2cUnkBzvwxE_g6lpfw==	3000.00	3000.00	Dallas	2026-10-14 17:03:33.432544+05:30	\N	\N
259	m8610	gAAAAABqz2iNa_rU8XsFVr7pN8D-CnspduDTzdVl-q-ARU39XS5cXF92l1A_iUSxiJuNrtrbstnw9uYWZ5Ry6kVU_1Bcm5-Eaw==	\N	\N	North Carolina	2026-10-14 17:03:33.526406+05:30	\N	\N
264	Camswi1720	gAAAAABqz2iNtAC1Hb5LEWdN8ghktwAmi4U7X3N-F_YTF7olnGje4MeztddgGcmSCKnIOiD3fDKbaXl34UYcw92a6VPK5AVMaQ==	\N	\N	Miami	2026-10-14 17:03:33.624516+05:30	\N	\N
269	Qxcrd136	gAAAAABqz2iNQnpBSGJ63iNlHhRMKZGsjkhy0cIhW31fNj3PotsfGTnHQlTYdxLndsobggSpS_ySobmatRq4SN6aeydogPqnWA==	\N	\N	Dallas	2026-10-14 17:03:33.716225+05:30	\N	\N
274	Mm303	gAAAAABqz2iNh-Faj--DiIyr8gWyYfmNS2PiyzpfXsn9gQrSuaQ11TQfVF8VTEMuPZUZe2FGnrukvm4s3haqqWCCgApq-Onqkw==	\N	\N	NYC	2026-10-14 17:03:33.813571+05:30	\N	\N
279	Bbs023	gAAAAABqz2iNcG4IsMIZl0oAICeAcZq5UGq9ESqoXm-ugfYxOu0-M8txcgdrUY7jI3RSy_RXvOOmi-NB-5INYJ2jJ15c8WUtBg==	\N	\N	North Carolina	2026-10-14 17:03:33.912881+05:30	\N	\N
284	Va115	gAAAAABqz2iOa95O3BAeWpE8Hu6OeQl9Y9dOx9-uPyu_tr9Vmgpo3pVXABn9RJD2ZUHEDhpmrOagbruRbwyTxACA4x4Gx0fP4g==	\N	\N	Miami	2026-10-14 17:03:34.008709+05:30	\N	\N
289	Tnt1896	gAAAAABqz2iOWjQlCcI7lK5HhOfb5I7jxANyXj0uVTlKKSJ1cy_Bo_7plgzW3Zid9nY9d_RsSMXuxi3KSS_w_EZKcNVZUVkWJw==	\N	\N	NYC	2026-10-14 17:03:34.104259+05:30	\N	\N
294	Tb334	gAAAAABqz2iO9v6TjFNbkvt5MyaIGuCVuwRSfsKL40xqfn06NEkFPDidX0x8WF03Xz5SShOzl8fEuz4iVUL-CS2DTyZ4V5n3eg==	\N	\N	North Carolina	2026-10-14 17:03:34.2054+05:30	\N	\N
299	Gsu2119	gAAAAABqz2iO9QRswfSZAEFSbZ0YGN-hdqskwCMnn2XNr4B8x2_XsvQsjUjH_Zhl-xAYCwQkQq7fAx3wO69mYBEQSXrHkiwGvw==	\N	\N	North Carolina	2026-10-14 17:03:34.302431+05:30	\N	\N
304	315	gAAAAABqz2iOc8o4v1VLefYxbZ5dGfBvhzcCUYW7EakW-D6xFUeSPhfB8aAnfS-PUo2yNGvKUaEfORHt-QhJLavsck3rH6lTFw==	\N	\N	Boston	2026-10-14 17:03:34.40092+05:30	\N	\N
309	9487	gAAAAABqz2iOBrAo4CFu4_FKgbw9lyexa_-3FPr9JEoNjfr2i33ZzVgMeFN_V_kxLfe9Ap3BxXCXWzvdkKLVR251twUkZUQKlg==	\N	\N	North Carolina	2026-10-14 17:03:34.497878+05:30	\N	\N
314	Mia190	gAAAAABqz2iOSz7RvBRSQETF2dwZZ0VLqlc6_Nz3YXOP-6IJzF0_lyvAx4rpCLvt3-dnqhKG0u8UB3Pj62-h_pwfZNVN9X_4Uw==	\N	\N	North Carolina	2026-10-14 17:03:34.593852+05:30	\N	\N
319	Trbl376	gAAAAABqz2iOKnKCY019JpSMqxhuyul2uRXdSZo-ysS6dd1eCuMXRy70CQdrEPWKYMJHi74XAvjU1IQFOjTVMXads1x3EFpU6g==	\N	\N	Miami	2026-10-14 17:03:34.685701+05:30	\N	\N
324	Whale208	gAAAAABqz2iO_u_7wpQxJ7V8QOPaYEK1aWAyk9HX2YndDGE1pff3pNeW9kkvgs--jagjWcQKXVfRMVpEiIKKm7rvBX6hd_-Fgg==	\N	\N	North Carolina	2026-10-14 17:03:34.779902+05:30	\N	\N
329	Ld2	gAAAAABqz2iOIWQ42jEP9jmupqEGU-qUJqg48azbyiHS5LadskC1M_4Ikln7nEuC_UDS00M-PCFRZwnitDL0DYZBYlE0XJArGg==	\N	\N	Miami	2026-10-14 17:03:34.878398+05:30	\N	\N
334	Kaf190	gAAAAABqz2iOSqW7kROZX1xyog-hgmby9XrDrsyVmziPw15y6Zl_lPTTxW-Q3wu5JAVxExF8wqoUwFRyETZSBVP-Mt_5BGzTsg==	\N	\N	North Carolina	2026-10-14 17:03:34.977077+05:30	\N	\N
339	Zpt844	gAAAAABqz2iPUumPnWCQ9NoN3CrHwWnNUjm6IpzB5UY9hnOMLXjs3Klo-cHuPaquHEpk-T0J5UUM0d7x6rmqKHjktvIWiiEo7g==	\N	2000.00	Pennsylvania	2026-10-14 17:03:35.08108+05:30	\N	\N
344	Bnt406	gAAAAABqz2iPuI1LUj866vCQLJFykR_UnLSGqCAEDUMwYsVWhEqQahkaMmU8bYUWz-GulTAdIJ60vww_f6Da8HrnS54M0u5uUg==	\N	\N	NYC	2026-10-14 17:03:35.183637+05:30	\N	\N
349	Bnt110	gAAAAABqz2iPnTE6epdXeecq45h2d6l_FSau8LjOTcrMVoF1TRF7H59KL2jFQ3cYK6pWEiEg8OKMCZH5sGfy2NCsnkzOlby2HQ==	\N	2000.00	Massachusetts	2026-10-14 17:03:35.289391+05:30	\N	\N
354	Rpr44	gAAAAABqz2iPRSeebpEukZanwDPI8qNis5nnSMI3m9_vfF4zRw2KZXAFeqg5NSIjlrq3kvC698Zj_XrbJajTsvhT39vzqbK6xA==	\N	2000.00	North Carolina	2026-10-14 17:03:35.394323+05:30	\N	\N
359	Tig107	gAAAAABqz2iPPC_HZ1Td0k-98OYVjK0j2Yl2bguC6zUPYeLb4z89jpy9GyRmxktsJFq4XZCmtQvNTafnCNzP-OkrIaXG6d-yrA==	\N	10000.00	Tampa	2026-10-14 17:03:35.498271+05:30	\N	\N
364	Jh206	gAAAAABqz2iPMjLa0MO73eUu2ae0IHbKdmVasJmDT38LCu1-IchWF9LqKd9j8vowuzcx1hbngxgCVB2c9E4XgMymHDdOiTULdw==	\N	\N	Miami	2026-10-14 17:03:35.598226+05:30	\N	\N
369	JH159	gAAAAABqz2iPBtEfktgNequTgdgBHtJ5sV9FVjA1kMu4EADm9wZwYvhyczU6moEjaf2QUCIRNZJWVX9C0JLQ_EoNc1mAoyI8OQ==	\N	2000.00	Minnesota	2026-10-14 17:03:35.696695+05:30	\N	\N
374	Jh201	gAAAAABqz2iPR10-RX2tHZjZ6VV1JVric-37AgliWexWRbYb_a0iQp04yms2PNm4MSKW29mbbxg5rrCpwmSP6MjjgUvqzJUl2g==	\N	2000.00	North Carolina	2026-10-14 17:03:35.791078+05:30	\N	\N
379	Mia161	gAAAAABqz2iPd-KOGeCWYaewSNmuHvQ20uHHkRgWlQNJEfvEU6AuDpdTyPyffmE8CLASLQNnsbks0m1dTKbyA0xHFt_dGfPxXQ==	\N	5000.00	Minnesota	2026-10-14 17:03:35.888053+05:30	\N	\N
384	Ea756	gAAAAABqz2iP3CpgqI0bbBg3A4Z1e0onVYUEy3p5InbQkDnDkSpl7x7DakMOoCgrJ8RUpTy17PI6F8IE68SkfArlzo6SOE14Tg==	\N	3000.00	Miami	2026-10-14 17:03:35.985932+05:30	\N	\N
389	Tn313	gAAAAABqz2iQ4FfEsM5TFtw649TslNgG6s1LwuEIREsz1R4vou3STFR-2JjkC4G3sUbtFQp_u66snkZoQIUVjizLtI5Iy4Bx3g==	\N	10000.00	Miami	2026-10-14 17:03:36.086687+05:30	\N	\N
394	Xjg4547	gAAAAABqz2iQ2efkbTKlZSQFvEavZC_pUjLKm5aoM4GBzcL9vOrKb43ut-OJGoduZJXTucCE3T-5qp44neJJ35_71OTaw-H9_g==	\N	3000.00	North Carolina	2026-10-14 17:03:36.18302+05:30	\N	\N
399	Cho232	gAAAAABqz2iQrTYRLnPwOasF6qDIHk4K1mafUeyABuasLfcVH7nLOH27-w5t3c_qId_bllAnLFatV-JKuucONsUj9v5kSlmVSA==	\N	3000.00	Atlanta	2026-10-14 17:03:36.279565+05:30	\N	\N
404	Simon125	gAAAAABqz2iQBArhfJdOUZ0vxeaJALOJoUboYrtgFasWiGETH0Saoz9vXjFO2GlbEYTPnEBRdG4qI0eg3PfEJg6B0iRJ1vO7Jw==	\N	2000.00	Miami	2026-10-14 17:03:36.374751+05:30	\N	\N
409	Ethan125	gAAAAABqz2iQ01Sno19owZz5cSYyNbHCs4S8rRZHIjwPIl_isd5W0l5R8FOPnmiZL6IMJ0XRsLY9clL0WWGZaW0tSBnNPOqyXw==	\N	\N	Pennysylanvia	2026-10-14 17:03:36.469181+05:30	\N	\N
414	Apo110	gAAAAABqz2iQ9XF30cLqBZGwwayZQSYh2zuXudooeQgAk2ngGgBIsp-Ock0U3wDTusH1QqyIwF4kjH4FlbgLqJSec2ZuEhfgNg==	\N	\N	Virginia	2026-10-14 17:03:36.567062+05:30	\N	\N
419	Apo106	gAAAAABqz2iQx3B40BNvQjUhNWhpJA61-jhE2jc7_Yqdj8ITtjjD_8sJb4r3owIoiYrqfLRUaMv-cVQ1-Uv3Oa56S9deMvz4Iw==	\N	\N	Miami	2026-10-14 17:03:36.665457+05:30	\N	\N
424	E655	gAAAAABqz2iQaIt08inPKgf1_RhjCJv-lfrdBYpVriZ12RnxNj15OWf3a-Xp8YbO5R-CAoK1m9-2dTFRyQceiPVgOMxHX-jlpA==	\N	\N	Mississippi	2026-10-14 17:03:36.760286+05:30	\N	\N
429	Gh1237	gAAAAABqz2iQ4geTYal2lF2R3WCxQHx-9R99GhfLPjlRmaselWv0t6wu_2iuN11PMSlS2dr7gLCExj5kNy9UqhuHqbRNy0C0tQ==	\N	\N	Alabama	2026-10-14 17:03:36.853403+05:30	\N	\N
434	Sna102	gAAAAABqz2iQEcnWvqacXIrBRN3cagF22gp3zas69DvJiDCmGFFLJqmrpAHjlq5cHHMXKNEgBYWxpBoO4BbRQ8g7Y-UEVEnBHg==	\N	\N	Miami	2026-10-14 17:03:36.949543+05:30	\N	\N
208	7261	gAAAAABqz2RSbakZleXWvvKCg__ylUQg0NHOPXCbYj5UumVxiTQG8X3x_OY-7z1gaFbca9QffYstMWyszUe-xbURSP-0R7oa1w==	\N	\N	LA	2026-10-14 16:45:30.037823+05:30	\N	\N
213	Dmo20	gAAAAABqz2RSyOasm97H0dmGYt-vfeRPqQw0lnsJEKC-0fw9lfrWREjThftq91AVO0LiDvWIEkKAdXkIR45rpm4KphJD2dX1fQ==	2000.00	3000.00	Houston	2026-10-14 16:45:30.176193+05:30	\N	\N
218	Flt006	gAAAAABqz2RSW2Z_2DAWpADXuK89erX8-6C68bRmlU8JUsV1Chw45pxqKr6HQ1UNLfQivNioabWAXpt0SExIGpyAx3kcvBKMZQ==	50000.00	\N	west Palm	2026-10-14 16:45:30.27955+05:30	\N	\N
223	Ppe130	gAAAAABqz2RScYjfVs1Z_Xwy-NLyWFZbGatqFVayMmKQZ7nZ7xg5UiV1JCbdB2HQYX3gqQFJik4c3g6YxrUWGoLRPXtYlUVVHA==	10000.00	\N	Dallas	2026-10-14 16:45:30.375048+05:30	\N	\N
228	Bgg426	gAAAAABqz2RSTZv9rLS7yaMC_TcznjSDg_k39JetSNrnx4Fzb8f3k-iOjhltsMV-hHNgAYQz4ItHKypX9NgQODQJIV4LKCZnqQ==	100000.00	\N	Houston	2026-10-14 16:45:30.474476+05:30	\N	\N
236	Mg28	gAAAAABqz2iMdTjTrExiD1Nj-YRHlfgFBklPxGspCdubIz-PXKvJ88p88arX-9X8LTUbz_7H3swumTtuoVkeFxk8ESvjAVRXzQ==	\N	\N	\N	2026-10-14 17:03:32.990012+05:30	\N	\N
241	Tex2509	gAAAAABqz2iNi9DAsu2oMrqZwVBQwJslKpCwnnnI30pmBanqU_f6Xsae0IOxsizIyBeTEqzFtuh5Y4OwQmVapDkt_sBqHM_uBw==	3000.00	\N	Houston	2026-10-14 17:03:33.082284+05:30	\N	\N
246	Ran26	gAAAAABqz2iNRPLMrX49SraraNWW4V5-f8qXCRkta0Ps2gdPHZCUvKXphi-d7KlF9Wu0L8g-QAl-Zb5sSN15E_JsshPtqz6POQ==	3000.00	5000.00	Houston	2026-10-14 17:03:33.178936+05:30	\N	\N
251	Htwn25	gAAAAABqz2iNk6l7zc_oPbW9dQ0MGAy9yZrfJO-s3_qqpdXRsgnK6pK3o9hoRpNCKdKxTbgqzq2UTo9JMzLyXgnH6vkxp2ORhw==	5000.00	10000.00	Houston	2026-10-14 17:03:33.369904+05:30	\N	\N
256	Shs447	gAAAAABqz2iNe9q4DSVjmSH9ZVrxLejws62U8jSyy8kAWeiWrT0sba3Rzv6id7LqgddPyg8J040SzphgwmNiPa6hJ2kp5QQRfw==	5000.00	\N	Aiea	2026-10-14 17:03:33.467978+05:30	\N	\N
261	Ariz12	gAAAAABqz2iNuhfAWKOqKrcpiPJ-dJvusLDDIXr9EZbfq-xvXkXKC7fuNDEx7MAcWAy0Z2jjcz3Kr203b7e67ApwtjIK6jm0pQ==	\N	1000.00	LA	2026-10-14 17:03:33.564937+05:30	\N	\N
266	Qq114	gAAAAABqz2iNSgxNHePhQc1OMPaPgjdzQKE_dlOgQojXcZ6k5vH6KlzO8JRQtQWxPki98QOv-3fy8rroXrIOg2xkHhDS3a89-A==	\N	\N	NYC	2026-10-14 17:03:33.661341+05:30	\N	\N
271	Hou1701	gAAAAABqz2iN4HHMIF-9Vnn-IyOd9PoSNtQIK2fDcaEdF0e-wRsB3LUQbYSmLuSq_lmRwXs8yqXqOVw-dxd0t842A-MBkUPhjA==	\N	\N	Houston	2026-10-14 17:03:33.75541+05:30	\N	\N
276	Sp6121	gAAAAABqz2iNS8TTqH_KfKuCh7LYMD39ZMlILhm3KVxEDcHnAIgvhUC-bkd6ySrl7_bE0lCgSNlYtdUi2wm1G8A2P3Qeoi-aHw==	\N	\N	Miami	2026-10-14 17:03:33.852512+05:30	\N	\N
281	Jb2047	gAAAAABqz2iNSVEcRgOWOted7cR4Tzupc4R7YAtM95LbWit5prcjL6tBdv9EfK3EDShsnrEnY6xs8XHhkaEZXwl5PGNYqIVLGg==	\N	\N	Miami	2026-10-14 17:03:33.94995+05:30	\N	\N
286	Ceo1284	gAAAAABqz2iOEiYI5gQMeMX4lwrYSLcxlpIUd7LW48vCagfsIrUS8Sb2d2HFYdytuvFbjY-MZrJHA0qzuAwnS8fCC72XzdduoQ==	\N	\N	North Carolina	2026-10-14 17:03:34.047335+05:30	\N	\N
291	W27255	gAAAAABqz2iObfnxmjNdJX_hKXA6rzrMHQbIMDNPCu7P1vM5D15Wjo8sW8FoNxw9WZcHKl_mltq3Sd4l1XaPWPHu3iEHJjiTQQ==	\N	\N	Boston	2026-10-14 17:03:34.145132+05:30	\N	\N
296	Tb381	gAAAAABqz2iO9Q52QHVBwVQFGX7-vX7Di8sS50adX_Ea4Zz0oQVykzb5RE3DJttJdwJ9kmwbMEOyUlBCXSYs0YvUxM7vgVGeLQ==	\N	\N	North Carolina	2026-10-14 17:03:34.243189+05:30	\N	\N
301	Ppe148	gAAAAABqz2iOhFSZxwpKw-_Rf6CgZoO0HSOME6h70pmyZPj1Sc7HpExRGprZbVEeFiP_22AchKAfEC38_LsV8hXTt7g9wB7Z2g==	\N	\N	North Carolina	2026-10-14 17:03:34.34201+05:30	\N	\N
306	Fk5555	gAAAAABqz2iOINYk8RsXks2QJpfpQPBbk4ovYXYEL41wKEb5pom6s0N6aKARW0Ok1KJGszEAOaUvI_C-8RbL_vonNdtaI7YTDg==	\N	\N	Miami	2026-10-14 17:03:34.438861+05:30	\N	\N
311	9484	gAAAAABqz2iOkXysg9lQrdxdwTuQeJZ8UGiUY3OfvokFyebO057g4cARbh0uWg6-NdhovpN-9L-yZxLdZKW1aSwH42_ltKcNZw==	\N	\N	\N	2026-10-14 17:03:34.535143+05:30	\N	\N
316	Mia188	gAAAAABqz2iOHFyLl326WQcvYgn2sV4jTaaOPvPkYZc5BL1PiZVxDZZtqpdefI1pIP_z8e5oZBz1S80WlqlphVPGxJBB7ETXMg==	\N	\N	Miami	2026-10-14 17:03:34.631007+05:30	\N	\N
321	Mia167	gAAAAABqz2iOJPImrYUcIWRXh86RFBKc63tZbykv5bWjPC_9n3P3V9H0Le4wv_Dq8NQsFoJHB1EC_gd1optd6AKw9apFJPsS3g==	\N	\N	Miami	2026-10-14 17:03:34.72465+05:30	\N	\N
326	Sle76411	gAAAAABqz2iOfcc7PxRt6EPGS8ezgD5qXQT3tPguvu5jYpuskQmaFRageBlXn-l6zK_m_n-ecCaJgbBLTdWjmjU61KAeA7uYdg==	\N	\N	Tampa	2026-10-14 17:03:34.818846+05:30	\N	\N
331	Gcl115	gAAAAABqz2iOXQp6Y4SRB_OXpqH7fsWLQ96yC4hyopaQgn7AM_ONO7duUi2yYE9smEPkKQJhLV4hpeAxyxS-6k5ZuBdZ77DYhw==	\N	\N	Michigan	2026-10-14 17:03:34.917546+05:30	\N	\N
336	Kaf155	gAAAAABqz2iPmAl1-wytHy2Tb3QvjJwYIpwjR-xUSSThJzKN1PDnhA1oWEvKVYPJrr5OMSvzAx0Too-ZUEEhaRdKTUJFRTVAVQ==	\N	\N	North Carolina	2026-10-14 17:03:35.018223+05:30	\N	\N
341	zpt850	gAAAAABqz2iP2wDp5Innf-2rpvL2_3YT1t7pEFVzUy5WJ91fmlHOyJ4aZxacxyE2V16-hx2GR4cX_3DnaasHpk3gnPK0uQjmHg==	\N	\N	North Carolina	2026-10-14 17:03:35.121349+05:30	\N	\N
346	C76590	gAAAAABqz2iPUkqFNC6cW8nJ-brLewQBGAt6UNCE_hTAKD6DT6HnHa5_L9exrEEsf2yAY5U6ItUIfWrnOSTYlYNNOT_zZDD1Gg==	\N	10000.00	LA	2026-10-14 17:03:35.225115+05:30	\N	\N
351	Bnt404	gAAAAABqz2iPlRux8FEXwzr6gdpjf0KErPleL9EVhByx84k-uPuYtoXK5jqWQPZ-NFcCQloDH0nM102NclhBozGfFJ3d05GB9g==	\N	\N	Michigan	2026-10-14 17:03:35.332437+05:30	\N	\N
356	Cof44	gAAAAABqz2iPMU2aDulyHe3KhggEJCtNnnsZBaeYhumYWWfNqUAieor7t_Anr1eCf4jj9UitCSEgsOwYJqTJFn4VIGOBhjduvA==	\N	3000.00	Miami	2026-10-14 17:03:35.435401+05:30	\N	\N
361	Bob1021	gAAAAABqz2iPA291z1SEFwGi48lAqfUaBq18PXVDeFTNOW9IpdF8JifTXqQ9-jalBZ-sxq4kPTkRqN4Sy4KkZvGdDV1ewttYqg==	\N	3000.00	North Carolina	2026-10-14 17:03:35.539889+05:30	\N	\N
366	Jh176	gAAAAABqz2iP9xeTtTekWBIzvDwdABCjpvJZfWX0xfvx_065-ShyZ0C0NQtLVpciAgqXmq8p_O0zFHRaz0CE0y1Yer96WXIXKQ==	\N	\N	Atlanta	2026-10-14 17:03:35.639187+05:30	\N	\N
371	Jh208	gAAAAABqz2iPkJILhgOZqmZyjfb7MqMVxEoZfMpcBjPcQN-pTxZPTzQnKDvB_6WyrzZBZ2aVL4tWcXw-SGbtDci2r8AblV5eEw==	\N	1000.00	North Carolina	2026-10-14 17:03:35.733851+05:30	\N	\N
376	Jas1876	gAAAAABqz2iPgb-_7cMtxe7huw1dTjW9gczoKSiSsOVN-FxmF5w3hLgQnQU7ftWUYvXnZY1bijkrKcCnOxScBqk-fwyCGGI5bg==	\N	20000.00	Miami	2026-10-14 17:03:35.831413+05:30	\N	\N
381	Mia194	gAAAAABqz2iPU5zgm0tauOsJ-JBT-GNgGzQsD_fcKIvOAA_xNTjYo8P-w71NGxV62qmXkIQ4g1h75ypYTVRK1rDSPfaBePuK_w==	\N	\N	Atlanta	2026-10-14 17:03:35.928427+05:30	\N	\N
386	Tb124	gAAAAABqz2iQ01G1njfwTn-UxYF5dWje4wxVaqD6fGOcy2JjqvSQH5nNqQHNf59GSkGVM7pYUbphE5C8ccmAyoBzM_Bc6GL0Rw==	\N	5000.00	Miami	2026-10-14 17:03:36.027015+05:30	\N	\N
391	Pb536	gAAAAABqz2iQkx-kFa8k6QLNkkENNjcVvQRLGLjIZSLKxKNCsfMEACII9reqNytctQ0x5DDXvEyoI6_oqws0hG_afX3pp_aWEQ==	\N	3000.00	Miami	2026-10-14 17:03:36.124681+05:30	\N	\N
396	Xjg4536	gAAAAABqz2iQj9_OsG0dRR5EBelNRBWWht_jZy04UK5oUSBwrDLi7xVS7wFnUwjgS_i6Wbnkr-eUFPLn76Gqey5EmB7kHzBGEw==	\N	1000.00	Pennsylvania	2026-10-14 17:03:36.220491+05:30	\N	\N
401	Cat6710	gAAAAABqz2iQ8VFbJKjoA-0R2bqLt3izL3U7mdxJHcQLsGFsG-T_dhyMoPHpN25JtPn_iIGxfZNRGl09qHc4Ac4KaKuM6t0rzg==	\N	3000.00	Miami	2026-10-14 17:03:36.317888+05:30	\N	\N
406	Fsu93	gAAAAABqz2iQZaBV6s3e4beLtUtj_J1rmGHNhYnsTkJI2aBB5OfWD33rvl5RPEmlChTGgPE1esoHK99MyRFSN3jMipSe3RtoHQ==	\N	20000.00	Miami	2026-10-14 17:03:36.411636+05:30	\N	\N
411	Bnt105	gAAAAABqz2iQaHT2Y6xkDeY8j016WqRdA5xhhRS3Z5hTyfafhSpjs0E54omybrvYC-egmIlde-NxADq3-rj0rvOVEAyH6OWtnQ==	\N	2000.00	Miami	2026-10-14 17:03:36.509349+05:30	\N	\N
421	Gryp162	gAAAAABqz2iQnrMRX4k9mrbvZsmBDtsFSnOxcfadeq3AYVMgJGKzGqv_BzV7NTg1AaDgRHl8zWZsSZq0YWf7VndSTmvVkUSp3Q==	\N	\N	Virginia	2026-10-14 17:03:36.702785+05:30	\N	\N
426	Sts5163	gAAAAABqz2iQWPy-sECvvZTuLd595CwlcVtB0FiVXZyN6qTlSdrAnDTsRZyb57T0MWVRh6fnwQSquxdH36m3yk_NW0WClkA5vQ==	\N	\N	LA	2026-10-14 17:03:36.79813+05:30	\N	\N
431	Tsa88	gAAAAABqz2iQz37QjtIV7_NO50rf_8CBpNnh5vIYP8B_FsOZMru47rUmrQaXn5yjmp9IYHypqVfXcF5E-WglIPqiyMQZHIvoIw==	\N	\N	New Jersey	2026-10-14 17:03:36.89115+05:30	\N	\N
436	Dp11	gAAAAABqz2iQl2_oLyz9zDQsC-scZsgaw1RsrFZvUI5LkVtQHOxq2vgmV3-AEfz6SVzWrOiqVmnwmjzlIzhTg3CGauSoCRd0fQ==	\N	2000.00	Virginia	2026-10-14 17:03:36.986605+05:30	\N	\N
441	9456	gAAAAABqz2iR5hrPm4FEMpgUbk5P57pIivkFge7jiL063GH_3GEs75imtAQQlx-MHseVL_J3DM9-RmKaWDXk4hZLKmT7FrJXaw==	\N	\N	North Carolina	2026-10-14 17:03:37.082158+05:30	\N	\N
446	Mia198	gAAAAABqz2iRv_xG8ol2mw_SqJah012pyHsA1Nt0z9qm09SUbJeFoOrB_X2O90KAQigdM9CNnuOzZUSKSZmprLrSkn9CvyES6g==	\N	\N	massachsetts	2026-10-14 17:03:37.174323+05:30	\N	\N
209	J5924	gAAAAABqz2RSE2iS5fAXfYijW5ny1_UzCRYrs8bWIWNR2zZXzpJ7gZTHlqTdks6KMHWMjTe6-_OJ1sa2nkw8cO4Bh3zFISFe-Q==	\N	6000.00	LA	2026-10-14 16:45:30.055345+05:30	\N	\N
214	Bdyp14	gAAAAABqz2RSkqwEw4uFDegUI0qgSVaaeHc1W8600HRWhnGujGbkgqyeU_L61DkFV5gKAk74ZQQWo5aDaAPQ41jw1W9djNxImg==	1000.00	1200.00	Dallas	2026-10-14 16:45:30.197832+05:30	\N	\N
219	F533	gAAAAABqz2RSNDSks98NZtiMo-Upq8DLlK20n3duvOfO769BVgbmM6k_hZviJlnDlWFc0cJcR1HGvWooRCOaPal_Sj3ICJryhg==	7500.00	5000.00	Baltimore	2026-10-14 16:45:30.298656+05:30	\N	\N
224	Lv171	gAAAAABqz2RSyMe9Ge6Nr49wK8zUubgwF5beL8iR5MhcarMnmYeeO7l7I4i0TTZ-yW27IXdq7yy_mFy-ckW1odjtOx_S8jo--w==	100000.00	\N	Dallas	2026-10-14 16:45:30.393358+05:30	\N	\N
229	Bgg427	gAAAAABqz2RSkRoCj_F5UXowwi0Uq9s9NCFhEyzpfN05qpaH4BPI6tDxMNA7jWrrse6OACDpvGsxGGH7mbaOPXftVONr_U1dDQ==	100000.00	\N	Houston	2026-10-14 16:45:30.494041+05:30	\N	\N
237	Mg31	gAAAAABqz2iNUcuonUlgm6Bv6mlc5Phv6lC0mdGEEJ2w2E55UdYcWalFInwflyuD7bsSAPun9LH0sqcbrmFSQ96FHbwm3Py8_A==	\N	\N	\N	2026-10-14 17:03:33.005813+05:30	\N	\N
242	Tex2494	gAAAAABqz2iNTIVRnjWXnZluS6HiA8DzZekFAjo_CYTkaDmqou_Q4oh3id1AnTAIu3nAwKCGGjX2QMEY3YW2wam9sw3l2Sgi_A==	2000.00	\N	Houston	2026-10-14 17:03:33.101013+05:30	\N	\N
247	pete26	gAAAAABqz2iNYs0cdBOcd_Ye7LEWJ-cN97Xwp5T_A7ITEv5Ea5MRNLIjvKc_yK2RyxOwYzKDsdVjuOrL5-mnseU7GVq6CTYbgA==	3000.00	5000.00	Houston	2026-10-14 17:03:33.255043+05:30	\N	\N
252	VOYAE13	gAAAAABqz2iNF6FtsIYKY9icwQWpVlNe50j9WIVHV4D6hLmA70XSd_vP6Hq1lb0Z4yykk58RtPpbctp9FRu1Dq1TJQaUYpSRwg==	5000.00	\N	Dallas	2026-10-14 17:03:33.390993+05:30	\N	\N
257	Teab14	gAAAAABqz2iNFlocUER04lqH4oz4L5dPXMV8Q8xOzhT7FAY_huUonRYeP5R5Xx1_wTn1GDBiD20br8yfP_Xq5XZv6M2-gPIJUg==	4000.00	2000.00	Aiea	2026-10-14 17:03:33.488147+05:30	\N	\N
262	Tnt107	gAAAAABqz2iNfcu5yNv1ya36YFEKYKPAmvdHuRbPMy5Jcs1QiW499x_7-8FoxNqwt9j0eOs-miz4JaRUDv163frh9PZC56HarA==	\N	\N	Houston	2026-10-14 17:03:33.584707+05:30	\N	\N
267	Barstool35	gAAAAABqz2iN06HFcPXhAdNwo306QiGD2pjzocNu3kWXioiaHwtt_tTzW586BQ4dYG28SKJGfr8vVo4P0Drc-HNsL90fZSymyQ==	\N	\N	Tampa	2026-10-14 17:03:33.679302+05:30	\N	\N
272	Ch3007	gAAAAABqz2iN44uEXvrzPZzoWbbD59ciUXKNpZWlT0LhUwske5Bd-QbUIhfW7ZL1Ui-3RmUZY1tlRS0j7uHRVAofFnLGtczPUA==	\N	\N	Houston	2026-10-14 17:03:33.774054+05:30	\N	\N
277	Cf218	gAAAAABqz2iNLZjw_3Q6pC_VcVpEY7p3v6qIctVA1h_15jyMd-M8cgmZWmTKrzz9Vs1IUvc1cwEtxAH1GXsw1hnIWQImKB9ItQ==	\N	\N	Miami	2026-10-14 17:03:33.873506+05:30	\N	\N
282	Sle76413	gAAAAABqz2iN-rf2wPnc3PcoD692lRRNmXNB2Gv3Ogj-ufGRBImkMZbleQJa6nBwleLz0Xg-rAybRe-iDbB67YcEGD06tf99SA==	\N	\N	Miami	2026-10-14 17:03:33.96852+05:30	\N	\N
287	Mo8865	gAAAAABqz2iOoH3StFAr0Gyemk923uRT8o_qaoATgngmrMjWA-9YBjoFHdIoNVQdyo7ElYq8KA387IMG9-PG-Slq2b8SWDpN2w==	\N	\N	North Carolina	2026-10-14 17:03:34.065905+05:30	\N	\N
292	W27258	gAAAAABqz2iOM2hXmPnhCPbXqKcoBrVwfQVf-LuuKKfxewXgA7i17r2hzSyuzY3IYdMANAB4J65ydIi0OThzQ57K8o5Js0qWrw==	\N	\N	Massachusetts	2026-10-14 17:03:34.167562+05:30	\N	\N
297	Zpt747	gAAAAABqz2iOgyLAk_IVMCuoH7bGO97FzFBRjc9VQ336XuDXzR_H5a34oIyozGePwYCppMPAqFDMYzNVnMuOum2l8puGbD2ZZQ==	\N	\N	Miami	2026-10-14 17:03:34.264234+05:30	\N	\N
302	Apo101	gAAAAABqz2iOB721SgMXA7r3ZGOtW3KTSvQTTF1sfjmBl2LQeHpMw3WquqwXzBzwEURTfHBFTMeDD-TiMQLp8MqacIwGWLO6SA==	\N	\N	Miami	2026-10-14 17:03:34.362084+05:30	\N	\N
307	9458	gAAAAABqz2iOhAsfG0bNW126FBi4zMx4P3YAxJDz877_1aeBZ2IJdVeWC_sx2WpnMnn1SY2fC5m7aLCIpmtb9KJAuZFHl91v4A==	\N	\N	Miami	2026-10-14 17:03:34.458958+05:30	\N	\N
312	Ct5567	gAAAAABqz2iOPMWe4ZsMl7w2MQj5kzCWbvv3tXMC_CkLnEGesvYZSun7bopT5x0Ala_d6jAlNdqyMNx3vam5cBaVgrNfkKSJ1w==	\N	\N	Miami	2026-10-14 17:03:34.554383+05:30	\N	\N
317	Qq5577	gAAAAABqz2iO2A8c-CHAu-9M-_c62B0EnkjPH-M3HGFUn-MF1m1Q37oLeO8OHMgMfu5lOez4B1-BbBetW5rlNIBKXb87GO8Hfw==	\N	\N	North Carolina	2026-10-14 17:03:34.649167+05:30	\N	\N
322	Mia172	gAAAAABqz2iOTIfuDyxQJD-e8op3TJWJoCvn60VwfAOU-BmB1ni4j_Jv9gAwXTKR_w4Ug_hnLUxv64wYMMy6bq9E4wv28Ro07w==	\N	\N	North Carolina	2026-10-14 17:03:34.74289+05:30	\N	\N
327	Cac1014	gAAAAABqz2iOSJiGPBGksQEWBEhyh9LrDCQ4z4qqwU6tZqH3ZX3oFRDwZqVQ-RMKKp93P3OVVAIX19mHAk6hYtMReVNF4VLDeQ==	\N	\N	Miami	2026-10-14 17:03:34.839859+05:30	\N	No max
332	Dz785	gAAAAABqz2iOZy0ly4V44gzeA8dCXRDYRgzI6NMuQNhGIgFodmUogtqylsiDX7ChAoZWw9gphK1fXARTRZuOysumkrY9k4xYDQ==	\N	\N	North Carolina	2026-10-14 17:03:34.937118+05:30	\N	\N
337	dd0082	gAAAAABqz2iPR3g7yt6LJuTGeKsMFkKUbaamf_9K66FmMJUlrbm_da_3z2OojPSSWBpSbzwlWum0UxBJeUK1yeS7si9hwdCwtg==	\N	\N	Miami	2026-10-14 17:03:35.039127+05:30	\N	\N
342	Zpt853	gAAAAABqz2iPwzYBq77E1uP5I2OtTf0QnCNaRcDY6rfTdDvfDKHxM04o3NXI3--Ser4Kn3tB9DT_twSuvjfXD5d9PXO-k2p1aQ==	\N	\N	Miami	2026-10-14 17:03:35.141617+05:30	\N	\N
347	Bnt510	gAAAAABqz2iPFd0kV9bfD_-ZPeHDP6WeXEIAvXOnl78r45j6d1vt0d1LPJLXnf3z80nd2zlg8RZu2oJNUpAvsRhWAUYq8PbJrg==	\N	\N	Miami	2026-10-14 17:03:35.246832+05:30	\N	\N
352	Bnt405	gAAAAABqz2iPPI4QW2JWlL_sHTA3nguiHcxgFA4LrL6EuHkIMwNdzLdP-a9iJMzt5vpGegrz_f56KWxCRuifSHm6s6IofIshQw==	\N	\N	North Carolina	2026-10-14 17:03:35.353573+05:30	\N	\N
357	Pop900	gAAAAABqz2iPMkCE8VQuTZUejmyn9zpjJxmDXXHvekq-i1BcMYL_BNfP9USbvodaz8KhylHg_nmR4z-dDA67up309U3-gAdUmw==	\N	\N	Miami	2026-10-14 17:03:35.456145+05:30	\N	\N
362	Cnwp308	gAAAAABqz2iPX5gq_4mTp-BK1n2v5JoP6-91MbXJhwWKBpA8uDpOD1idEWfAkY9IG74Fy3wKwVLATnMrvIUhr8EAzbZD4jBTxg==	\N	2000.00	Miami	2026-10-14 17:03:35.560243+05:30	\N	\N
367	JH214	gAAAAABqz2iPGKsk1zKIeSJavthI-ubaZkQNfg7gfDGiQfJ_mcZoThsdmwvsjXYYM-Q1rOO1zKgptpsGqtvKCUoT9b1_6NDq3w==	\N	\N	Miami	2026-10-14 17:03:35.659288+05:30	\N	\N
372	Jh215	gAAAAABqz2iPnPsztuV9U9UKCLrijzQ3nwF7aEBpdsHcu0CoENjeOQy9YwpvkqRnVSuGehgla7AvTHqr7sVCY6pfdoIyDRp_XA==	\N	3000.00	Miami	2026-10-14 17:03:35.752808+05:30	\N	\N
377	Tp500	gAAAAABqz2iPpgmj0_kh_F5J9JEV_NbmE0fFLBfBRM98W9chN-lh5VwIEs6jcxFQHENAULNeIFUYRewRrMNfl8YHy0hMdlAX5w==	\N	20000.00	Miami	2026-10-14 17:03:35.850067+05:30	\N	\N
382	Mia196	gAAAAABqz2iPEWRkDdipAUuqHVAWX0BbUj6ENdEVQUkfogHL_ESOkr-aebdaASqV7IpvwPAIrj1uJAyHu7EHAQ2l6g4ggxeO7w==	\N	\N	Michigan	2026-10-14 17:03:35.948741+05:30	\N	\N
387	Walk130	gAAAAABqz2iQwBMw3JTohEC5RkAtAz48o7fDeKZD9NWvthxaMVddT2MKQtapnsDoEbRm5THet7gWItabtAj-2ymM0eAVSvKcRw==	\N	5000.00	Miami	2026-10-14 17:03:36.048155+05:30	\N	\N
392	Jj1213	gAAAAABqz2iQMPTJepioSrYOGzMVbwxyw0bRW-RzxhK-SCRtL2L4BvKax5bZFGa9eXh_vOPLCRSWyCCdg4_MkCqiecxSAOoF3A==	\N	3000.00	Miami	2026-10-14 17:03:36.144139+05:30	\N	\N
397	Cnwp304	gAAAAABqz2iQ-AcYn66tb5mgLY-Juz3sXlbr3tlZNngcIoVR-PkiR6baI04GQWhw_cwe_h8tSKaYXpevmz-RzjoG1zdptK-d8g==	\N	3000.00	Miami	2026-10-14 17:03:36.239686+05:30	\N	\N
402	Cat6707	gAAAAABqz2iQlj51oHhu8AfVJ0oQsdem-Abl0t-8Vo-aWWjrjoEarEFzY7KNYzuEtQO6d8yjdjgH2tWxDETwYMZNT5ogcCFIBw==	\N	2000.00	North Carolina	2026-10-14 17:03:36.33717+05:30	\N	\N
407	Jhard115	gAAAAABqz2iQX435i3Wa2gOV3BzrS4bv_3zuc5VGI5p__5PurrUibEmbctze-tzP82lstHPNO10S8iVdIxnWKf-RavXGreFuXg==	\N	2000.00	Miami	2026-10-14 17:03:36.429615+05:30	\N	\N
412	Bnt108	gAAAAABqz2iQ68ieDbJ5Ni4zqPcct5y3n9waTv6ewQGj64O67BrdoETAgbNeiJ8DAyds7hkLMF6qtJeF9-qiTXJCKXi1fpxSPg==	\N	3000.00	Virgina	2026-10-14 17:03:36.528454+05:30	\N	\N
417	Apo104	gAAAAABqz2iQ-CLoKEl4aKOxAplQ5hwmMYc35vPseMiDjZezDp0pAZK4-rzE1PpP8VU-30V0k2z-e_s3_18McLIU1V3yWK3Ylw==	\N	\N	\N	2026-10-14 17:03:36.62572+05:30	\N	\N
422	Jkl024	gAAAAABqz2iQkUuAqR3j1cMRruMvBS_JbZp-dOlXjTaHuK9l0m-k8yRbdqIGpGudBEm_1cyLFnWQZEi-hxCPJVFIZfBAjFEQuA==	\N	\N	\N	2026-10-14 17:03:36.720734+05:30	\N	\N
427	Cam889	gAAAAABqz2iQY1FbAPeF6OsvKIf-zB3SITwvWlx9Cx76pWQCmQVnUekYb4GeLC3OuHLzDNWmsRI9VXCXAhbgMQSqnBZe1PmXPw==	\N	\N	North Carolina	2026-10-14 17:03:36.815739+05:30	\N	\N
432	St936	gAAAAABqz2iQqpJi3CVfAJNH4gDTPBm9QAk0tXI5zwlmr-No0gDoSvg5J2Hb_lOiV5meFRNEVFUMb9JKsPcRkshh00w6KcVzZQ==	\N	\N	Dallas	2026-10-14 17:03:36.910905+05:30	\N	\N
437	Jh155	gAAAAABqz2iRwfezOSrdmQBtFUcD9FeCgKmhhG5gAPB9W7WU46ZeVfoH4wSLVeqzpkpg6KtHGqeeBK6AkWYOfs-fhSLH-n-JlA==	\N	\N	Miami	2026-10-14 17:03:37.007574+05:30	\N	\N
442	L607	gAAAAABqz2iRTMG1mNPvcwfHAokrwBodwQZ0M880qZI-fS-pnQs6za5k7RA7NWOTrCzOW0O3YnDpfa-_XpsuDNQg_4F0p79Chw==	\N	\N	Miami	2026-10-14 17:03:37.100846+05:30	\N	\N
447	Mia184	gAAAAABqz2iRilPoB8DbXObD0q5UyvD8aK2xdSin6kXbYqg5wxL8KGd_DA7CFq_mQtJlCFs7ybt-_iAC4P38AamkxrnFVfa-5g==	\N	\N	Washington	2026-10-14 17:03:37.193027+05:30	\N	\N
439	Ag2025	gAAAAABqz2iRY61RPu4FKCD2taW6JAOBlPO1bkiVSG2p0ivAor6R-8iaeyf5VS3l9ns5yKMQroEStgNL_Sr5eeYzT7YhVuZeiA==	\N	\N	NYC	2026-10-14 17:03:37.044928+05:30	\N	\N
444	Ad9955	gAAAAABqz2iRVQsYF-tAnTtoeGCWvIouGupZzodVjhX10s19mGU04dH_QcvMSiJHGws8A0KI8Fzz_m3BkF3yioNA70FpIG6fHQ==	\N	\N	Chicago	2026-10-14 17:03:37.137236+05:30	\N	\N
449	Trbl374	gAAAAABqz2iRhZCrPGXL1BRWTyzvOcwVUatbxrUP5MP28O8YO8liPhryygffIAxOWX3VRsrLlqj6f9upZNJo8nSHvz92rUDdxw==	\N	2000.00	Tampa	2026-10-14 17:03:37.231875+05:30	\N	\N
454	Mia182	gAAAAABqz2iR9y3rLGK1Jk6FCQKgSyW6Aoo3c9AWEVvmHgURpBcPA_xbaYe12mH2t0kvImqC5T-DZSZH1eQQKnKSeZndFQel_A==	\N	\N	NYC	2026-10-14 17:03:37.325229+05:30	\N	\N
459	Vu5522	gAAAAABqz2iRF8oqz3FFT7GLNMkpBLjOU6FJ0BCNpdddO--RIlP13KVVGZaAm1mUNL1BgiH4WSELNQnqLzoa0CDIz8c253bTyw==	\N	\N	Washington	2026-10-14 17:03:37.422048+05:30	\N	\N
464	Tb352	gAAAAABqz2iReA7fGgIAin05bMZNi32meK_lRRcrgspQGRrFWP3E_mwuqES4vK3nrUnqjNr1A9KKiuESDPBBfYbS3htg4nZmbw==	\N	\N	Miami	2026-10-14 17:03:37.517093+05:30	\N	\N
469	Ppe120	gAAAAABqz2iRP2wXrsXnhChhL_XmHI5Hf9KxTyHveSfl7oVqPaKYtXAe8x_i0yHhTjl0fkZ--7674a6C-7hUP_DltzJ1hBmjhA==	\N	5000.00	Miami	2026-10-14 17:03:37.612913+05:30	\N	\N
474	Acctcc1	gAAAAABqz2iR-uYcQ_J4CdWEtlAQWdN4btlBERUq1ZWmeAzzeOuGQgV0ltCwnEvCS-yTY8_41mllfP3HKvDK4x6M6CwlHh7PEg==	\N	\N	LA	2026-10-14 17:03:37.706545+05:30	\N	\N
479	W27273	gAAAAABqz2iR19S8_pa7MCesGf867HarSLlvgGW41gQ9axyCT7BqCgdZ5t7Uahf8Dh4XgFhoeVZOQV8VX_gFvmW7pZPxpSMijQ==	\N	\N	\N	2026-10-14 17:03:37.804475+05:30	\N	\N
484	Bnt402	gAAAAABqz2iRcA5v0i80Sq3SxxKWLdMTDLQgAYm1XkaTQUPU2EsrHCmRsITtpS9tp573imAhS6HqYHZ-YmDevTPEzpCRgzD7oA==	\N	\N	Miami	2026-10-14 17:03:37.899588+05:30	\N	\N
489	W89348	gAAAAABqz2iS4-vlHBKaPj5lHNbLcmq3F4jr0qOK6iO47Y-Wmaume53Xx5PKU6qkluAr1FUQpxIRusVo_y8zpZa-vNrpiKnoLg==	\N	2000.00	Minnesota	2026-10-14 17:03:38.037994+05:30	\N	\N
494	Z10609	gAAAAABqz2iSpr0xTkD4yFNE7LjILANycCyPOyB0w4on0D8d8g2fRnPxesTMOJhXGCfoBJgyto28qSbI4Kyrb0ljXK1NRk9CKQ==	\N	\N	Costa Rica	2026-10-14 17:03:38.140999+05:30	\N	\N
499	Boc524	gAAAAABqz2iSiFOcjHY3hg9TnbWZxgu7MSvKJDe8uxE0dgqLnby07xRVcYG0eZVagcoZru0l6_QKB_-E9dcmLWcQzhDT0pGL9g==	\N	\N	North Carolina	2026-10-14 17:03:38.237771+05:30	\N	\N
504	VL13	gAAAAABqz2iSvPv_ElsBKwQIFvNqSnjD9SAUASmMKZMS6-GHSpNhOSkb6S3x1_BgdJ4cjkijMjfU1Y2pC5iPzEij5XajkEWeBw==	\N	\N	LA	2026-10-14 17:03:38.335822+05:30	\N	\N
509	Rod23	gAAAAABqz2iSthoTDxqchRoV4n0R3migyLDMBLz6WOlN4_zfi4mXeMH4bwt5H4dPA_g4wNbUXYZdgF-fl6QF3uRd3PPuU9kdnw==	\N	\N	Miami	2026-10-14 17:03:38.433444+05:30	\N	\N
514	Rc539	gAAAAABqz2iSoQUgquxLKAKYuzjZ4R5KEDhPEk4sh8FbeYD8NELdXr-FFy-QPtPl-Wv8ANVKWlUv5SGsb_EqpAkOMP4v7VUAhQ==	\N	\N	North Carolina	2026-10-14 17:03:38.531121+05:30	\N	\N
519	Fm1564	gAAAAABqz2iSP5mCieVlg2eYoI9pJL6ZaJS-_6CBINtreUp2-VC5SfjN2PcGVet23XSzwqtTWCTdEOfusNJUBiJmedwbrvHtcQ==	\N	\N	Miami	2026-10-14 17:03:38.657076+05:30	\N	\N
524	A7938	gAAAAABqz2iS7WPXXCk8wIamXDmY_AMHZIKWuobJLb-QwXJhvUMjzIC74YDSAnfFmOBNX8xJv8XbvLSincT8g90y65ExrbagWg==	\N	\N	Chicago	2026-10-14 17:03:38.753197+05:30	\N	\N
529	Elc1161	gAAAAABqz2iSpx40WhDinDSsaix9IQFlSzmmXlGo2luXk2z8qqrTdduyz5hcI3GMF4q398F2d1q8nE-0AiE3c26VwJIi0U7pXA==	\N	\N	GEORGIA	2026-10-14 17:03:38.854119+05:30	\N	\N
534	Meridith10	gAAAAABqz2iSTdbDGVWxlBYg1zDAMK1r07CX_9mdEerw-0JHWMtmhcNrsU_dHOJh_RUm23d3BGbyTQi0tLrwsiMOWLek22lO1A==	\N	\N	LA	2026-10-14 17:03:38.953207+05:30	\N	\N
539	W27256	gAAAAABqz2iTTeI6O8TautkZfOgiZGbl3eR1syzDnvJartuRZsFgCJhvmN4W0REAn9BjtOEZuQMHmIjaaUkzjZCP4gcwOL8UXA==	\N	\N	Miami	2026-10-14 17:03:39.049173+05:30	\N	\N
544	Alan224	gAAAAABqz2iTbf38G6JBiaxYtMFCyekt4Z1z4CaxSGi-MI_Z2lbvXoMk2wW9nBqbER_3XxiPQf1t8jyD9g5UWsXWEuJ2sK5r-A==	\N	\N	Dallas	2026-10-14 17:03:39.144702+05:30	\N	\N
549	Ais507	gAAAAABqz2iTU43L329sZHV4YoiYpcKNWfy4EADpAanQdPZ3ysKM1ow8VOOKoyi_Q2TL5jB-p-iA9TJlR97h2Jji1JZ04g9HzA==	\N	\N	MIAMI	2026-10-14 17:03:39.251573+05:30	\N	\N
554	Dawg44	gAAAAABqz2iTkXB4JnwL9IdOWT1lwvW0nmyZcfK71UTkQ0kjEy6Iv59dL4enP1m_hPpNn_6OCkXn3kt94Q-dm0ITthVIfJAhAA==	5000.00	\N	\N	2026-10-14 17:03:39.346219+05:30	\N	\N
559	Co18	gAAAAABqz2iTCrZ7czfKxh-yX_ZK48-y7ofzoIRIWVQ5JvzHERyQRnkofFtioNcrfAb8clYEZknbqvvIv_3XLagvKGSq7CwxIA==	\N	\N	\N	2026-10-14 17:03:39.443952+05:30	\N	\N
564	WG213	gAAAAABqz2iTbtQhttZ8Fkn6lCIDXzHi9BrVTZZBfIBY3lEkHA9EMCX0XTrX5rbepRXsr9xKefvSQhuHYl0oOL8IxestGnUv6w==	5000.00	\N	Omaha	2026-10-14 17:03:39.538693+05:30	\N	\N
440	Pm8888	gAAAAABqz2iRkjs3nKWQgje1fUyoQZKwQd6dTFNj_KMBv5WIKWHHe95UJjPpH3mHzVqAIPUht6O0BI8M4XxY1-Kf8QDOpJhx8w==	\N	\N	Virginia	2026-10-14 17:03:37.063487+05:30	\N	\N
445	Mia206	gAAAAABqz2iRfG3PzhbgLvmBM3sg-qEPMOwgVJMYL1DjRHKlX2Xe_rqefR2arA9pieYyBJbHyCF9iX1ksMr3NEd7lInQzUABTQ==	\N	\N	Dallas	2026-10-14 17:03:37.155974+05:30	\N	\N
450	Trbl379	gAAAAABqz2iRVBflbLS1KPeBLiRDUGA3nFRC3TqCUgqdZ6lZrGtIlblPxw74k7pgnOzMsWw4Wxka9yduyGBs5zF5PR1Er4JwkQ==	\N	\N	Virginia	2026-10-14 17:03:37.251089+05:30	\N	\N
455	Mia173	gAAAAABqz2iREQMcRTDI4q3sO5FWvXDhpirTB9X03eMoQGIImzMWbwOudPg75ZGAFqFWxR6TOYcUFvy3vaewHEsAoU0KDu6ryg==	\N	2000.00	Atlanta	2026-10-14 17:03:37.34396+05:30	\N	\N
460	Mia151	gAAAAABqz2iR_075C-iB6kpJARs6f-0z5c450M9ATIq3bp2SrbRTfaB1Zsose_ErYuch6ADQopda8Oc-Fns0MMUDXubSwGLd5w==	\N	\N	Alabama	2026-10-14 17:03:37.441329+05:30	\N	\N
465	Tb327	gAAAAABqz2iRPHevub9AK6a7R2EfdL4LEn22nt2AoMfllnWXiBJ6U1xhvTrespd9di3XbZIbimm2p-lfmx_MI2_qIJrGIfD05w==	\N	\N	North Carolina	2026-10-14 17:03:37.536011+05:30	\N	\N
470	Jh217	gAAAAABqz2iRZTvVBm7fZLHCLPAUy3DgszCAo0-lAfXNbOh1Polf4xV9Tlh78wLnoUvS5LBUD7hRJhN-Gm0oXkYS-r3QF9D_AQ==	\N	2000.00	Miami	2026-10-14 17:03:37.631442+05:30	\N	\N
475	Fsu136	gAAAAABqz2iRc3UOgxAIZMKgD78iB5Jiirk2I20p0BIxxQNYB0wEhXcoOky6gmlWXy3rIr36dYZJbjHUgvuFK-9GXYNL9D9T9A==	\N	\N	Miami	2026-10-14 17:03:37.726555+05:30	\N	\N
480	Zpt840	gAAAAABqz2iR_Ei4wp_pIf9r4Shk46nrEdcRVtdo8H7viCv6gcSC1GKHMomjC4H4t9XyHIAXBwozfz6KKmMsLOIDdU4wCrTmhw==	\N	\N	\N	2026-10-14 17:03:37.824407+05:30	\N	\N
485	Bnt504	gAAAAABqz2iRP549D6deY9qyM0_Cujf90hA61w5wTcr-N7eEgfJxoHEC6L6XKokoyiH7gd2ihdbqXH0HX9DJvku5rLZQhwj9jA==	\N	\N	Miami	2026-10-14 17:03:37.947872+05:30	\N	\N
490	W89358	gAAAAABqz2iSYMO74xwenHJbDp1bio1APGRxbLJV0BtmEOAKodGQYWkwOh-zrbpRJNCKtQ_8LWCOhUYjZUCCt9TOo5EQ7ZLHrQ==	\N	\N	Miami	2026-10-14 17:03:38.058314+05:30	\N	\N
495	Blue0114	gAAAAABqz2iS8P1tYtW1KQfc3YSqVwIvV5QF1svTyH0xQtB5bDX8T7lf51e_1D7Pwbe7xGoi0-fCIlrdy2opJvmBR3GuCluFfA==	\N	\N	Miami	2026-10-14 17:03:38.16118+05:30	\N	\N
500	Kyle224	gAAAAABqz2iSSyLsZoHpMpcSraQ5YFAvDWJOADTDS4R-0haHNyS5IusGdJOHrOw2e2Uz4ZhxRzf87hVcHvA73OQFMkaFKldhDA==	\N	\N	Dallas	2026-10-14 17:03:38.257183+05:30	\N	\N
505	Xjg4544	gAAAAABqz2iS24RWDOEnbjS756viEOaxfJtzUHZ9Jfr0_OFco2f5eO9lf0sxXv5d2ctw9cMxeUPXHLbEn3pA4pC8pJXvBLTMkg==	\N	\N	NYC	2026-10-14 17:03:38.355473+05:30	\N	\N
510	Lukee123	gAAAAABqz2iSz6-WaxkvJF3Sy7UmFwllrOELW6bnfEiMwdpoWGRguigmikDKytB3rHa09actB1JQZFNNJav3BWV1yB9t9VnNXQ==	\N	\N	\N	2026-10-14 17:03:38.452785+05:30	\N	\N
515	Tn331	gAAAAABqz2iSvRzCQD4W8_uI_-c-n976KCRQsCgDI-qv3Bp-J75IHyjxtXO5vNixRPO8ilVINXtdOB4id381hHzbfbZ_p3jKgw==	\N	\N	North Carolina	2026-10-14 17:03:38.550143+05:30	\N	\N
520	Qqq113	gAAAAABqz2iSxsw9vnJ1vz9OFrW5gxTnFq1oNyDHR3yYspurwW7UWL3ffTaBNjvOZUtLfuEjePPFZ7knUolcGxvP3ArLUuew2g==	\N	\N	Miami	2026-10-14 17:03:38.676883+05:30	\N	\N
525	Snak1	gAAAAABqz2iS-aa0Kg1TVvrqajrrR5zI93GQ6I5kPZuWOHCXROg46xzowCuPWHSedx2q_6zNYnTLrnUD1zKkIr2oLqJ385n6TA==	\N	\N	North Carolina	2026-10-14 17:03:38.775296+05:30	\N	\N
530	Nw10047	gAAAAABqz2iSDQhz3_M25GqTWKAVefIoYHo0QziXr6i36sTRqMUYbHsRcHtlPzHCK5cGL-1W4K06KIw7PnFA69SqUwngz9YDtA==	\N	\N	Atl	2026-10-14 17:03:38.874696+05:30	\N	\N
535	Mf437262	gAAAAABqz2iS__TG8kiaNCdNV1V0wYKtctUoTwUUqMmLG5LVgcveG6Afq2GQ0MtsG_pYOiZ9RH5ijjt77qVdzoKTtr3vLmdeTg==	\N	\N	\N	2026-10-14 17:03:38.971288+05:30	\N	\N
540	Apo105	gAAAAABqz2iT-rnZGACqEDYQgZBUe8Yj9LsRQLJhDFPrFTWfDQIxBkkObfgJ10qVrlvdtuZZQSzjenluvL73TV1BaLNWSozUpg==	\N	\N	North Carolina	2026-10-14 17:03:39.068025+05:30	\N	\N
545	dd0062	gAAAAABqz2iTRwyMqbTaNY5ASEsveQKfJFbJciPccHKjUszL8VR52oQLkxtaFjetbtrLBZNH3EMNs1HNxuGPmINvj5uFJ_MA2A==	\N	\N	Michigan	2026-10-14 17:03:39.165925+05:30	\N	\N
550	Kaf219	gAAAAABqz2iTDNENif1r9LG0d4rdgsmF1w5bm18ivEL0JEaBIa05hfQ0fU2wcaFBhGJIZzV2ni9oUP-l6CiGOut0nscTRGwauQ==	\N	\N	Virginia	2026-10-14 17:03:39.272186+05:30	\N	\N
555	W22885	gAAAAABqz2iTQLx4w_Kd1lppr-3Ftb4ak8uH83eXQEqpUYJd81L1SULFHFPfvN4k9S9jirGi7fOL01KlN6CJhqSu3WDG3C0KBA==	20000.00	25000.00	Boston	2026-10-14 17:03:39.364707+05:30	\N	\N
560	Kc2526	gAAAAABqz2iToLP7CdzZ-ky7Y1DgDK-N7QwsFrUstZahGMok5QNsJILu3CuBqHvOCk046WD9j5FhfA_usdh72pi_jwGPaoQ97w==	1000.00	1000.00	Omaha	2026-10-14 17:03:39.459415+05:30	\N	\N
443	ML5984	gAAAAABqz2iRfvh6RG7Jcux-TNCbg6Obx6A1c0hRFRyZ0i8mxx9NcxpgJx-cUMuRENvw4MWK_zKv6uTAuMDbv4MwbQ4pzd9jrg==	\N	\N	Virgina	2026-10-14 17:03:37.119457+05:30	\N	\N
448	Trbl375	gAAAAABqz2iRQu69rXaXf703BrKJVGM8MNHUmZq0-_BBAHSysziJrNVizFNeFD4jJFy-SPPdZUXdikKJH1GWYHTEIt9Vayop6w==	\N	\N	North Carolina	2026-10-14 17:03:37.211979+05:30	\N	\N
453	Mia197	gAAAAABqz2iRNp2U8gUKWMXVLSgEM-PkqCabYRD_2YzkkUuaUI1Ga9kkpM_cxacKkCx62yRDPrM6xLIfsxykEDotCEw8gof4zg==	\N	\N	Chicago	2026-10-14 17:03:37.306179+05:30	\N	\N
458	Yy115	gAAAAABqz2iRZ8F63JWR1w_v3A3VVvuxDB7cTWXg2pZ7R9MWMvEVmtwDrMpUVn64TxbK29NtHvYB-k8zD0mMMfQc143kL61gog==	\N	\N	North Carolina	2026-10-14 17:03:37.40414+05:30	\N	\N
463	Tb322	gAAAAABqz2iR_4gfXRKxh--OMmw6w_SHTGdsYel5fn64kPqOClGCIiXf6Bs5jz9P4OodbQLTlXsYHcTbwkQvLcOmcnpPfQ_0rw==	\N	5000.00	Tampa	2026-10-14 17:03:37.499175+05:30	\N	\N
468	Ga107	gAAAAABqz2iRSnSqSG9cmd6HBQTEP_o7bWuvdHH1WcsAH9CNsg8HG9OuqVrTvPSXc6Cl2fv7SQqNWn3-erlAAA9tNwFwV8XeSQ==	\N	5000.00	Tampa	2026-10-14 17:03:37.593432+05:30	\N	\N
473	Jr269	gAAAAABqz2iR3rGI_uRORf2s_t_qqbz1y5-zqXypia5BUURev9ajsrFs98ZevFQuM_nnrv4l_1PVpgJn1XbttEQdipkML-MqUw==	\N	2000.00	Miami	2026-10-14 17:03:37.686867+05:30	\N	\N
478	Willh600	gAAAAABqz2iRjBVcJ-VFpEIvIFYI8VZR5cp7IJL_TSN_erKR6URwGZNEceXiNRjSh9-i-bFjUJ4fhb7Wwid7BZUdqsEoSdpoFw==	\N	\N	\N	2026-10-14 17:03:37.78559+05:30	\N	\N
483	Bnt509	gAAAAABqz2iRATebJvawsCLV0QHOjwyQAaOPa30_9Pp9pwkhBBclzrOTux0vIXUXg7EaPslBXJ1dgXZgIUZNtnnjFFUrqnIG_w==	\N	\N	NYC	2026-10-14 17:03:37.880659+05:30	\N	\N
488	Bnt514	gAAAAABqz2iSceD_vDJ6jt6-RWC-KtI_ymt0-jZyOmNJxhd00Fd55xWhekNocv3HnzdeF6dDwfpG8sQenfmRNOlOKR9s9GoOFQ==	\N	\N	Georgia	2026-10-14 17:03:38.018666+05:30	\N	\N
493	Fm1564	gAAAAABqz2iSKEqeW5KO_iebo9CyQSbLctTQ9lz5T0p1a9YG-lvQ5I4GqECD-_QGbXspsxU-5mN7rHE7PtvxmICbRvIZchMijA==	\N	\N	\N	2026-10-14 17:03:38.121847+05:30	\N	\N
498	Roa3	gAAAAABqz2iSQwPtKbczHeIjeSgkvb4p8i-qbVCZtMARFBm1D_uWq4iGDXsCFbyK-_xaPs7AOqcmK0Guhiey9rrlU7Wav4Ld9w==	\N	\N	Dallas	2026-10-14 17:03:38.220985+05:30	\N	\N
503	Cd444	gAAAAABqz2iSf_oyNrWUP-u8zNYktg8FjiTL9KBreEkiO9zEzN1PlGMV88Sa4z3ovmg07gFN5I3D1OsCwGz2NH5ZpHLtn-EzWQ==	\N	\N	North Carolina	2026-10-14 17:03:38.316005+05:30	\N	\N
508	Xjg4542	gAAAAABqz2iSknvuP9OMgkTqIFQzeHrGAHR4lg6BBtnl8lGBVrGi4JFkTR3ERpqIxGp4pdrzechea-DBfrQlHYlzTxaltdw4TQ==	\N	\N	Miami	2026-10-14 17:03:38.412856+05:30	\N	\N
513	Giov244	gAAAAABqz2iSIaGM9AQq7MnpMAyovYYpkZSIu_AM3bcWj6GonSfr33efEjcX5Wb_vFaLo_Rua2E__x31SovGcPmTEG9gBl4uiA==	\N	\N	\N	2026-10-14 17:03:38.51208+05:30	\N	\N
518	Gx403	gAAAAABqz2iSaAIr_fhHF5h_08uQgXt2AUUWY5VXkPad2-kCYHXAYASOFgYB5lOCFjosfZ4hJFG_LbywsIv-raVqtsbFgYtIYA==	\N	\N	Virgina	2026-10-14 17:03:38.635071+05:30	\N	\N
523	Pan956	gAAAAABqz2iSFdq0Em1bj1kSALBsWLrOt09QMaSSXWDxV3xUGq51g4HoPOrbrCEP_f3252c8UN1hCf4XJc8JHcLIJuVPJ_et2Q==	\N	\N	Chicago	2026-10-14 17:03:38.734435+05:30	\N	\N
528	Rj5838	gAAAAABqz2iSWaZIdk49_Ibc-Cfr1YgCNKFBqKBo5Mm1jPweYWJqcGo-czJ8KQK2LUUAI5ggbYgInifYsH1jjFo-2p7v-33org==	\N	\N	Miami	2026-10-14 17:03:38.835353+05:30	\N	\N
533	Bbog25	gAAAAABqz2iSefpLcfzVvKM3hRAVnN0xLmCBEns4czvzXvPpUIZtFT6dlsZhXFTyCL9Mz7ONQAgjYD18Fv5EaMbhlU-q3TO-pw==	\N	\N	Chicago	2026-10-14 17:03:38.931913+05:30	\N	\N
538	W27259	gAAAAABqz2iTUCOvsMTZubQkKovq6fbhEg53Y27FEFewwW2oIhJ1Kq_aaYJ-uTNcrepHqPrfPBkNNoSQj9EjYBwvRfPCTOF_gg==	\N	\N	Boston	2026-10-14 17:03:39.029341+05:30	\N	\N
543	S2688	gAAAAABqz2iT_5Z4XKcAC3kufeFvltaynKR8m3aBGCh636dLPROq6HiQSBGY8tJFIcmgZbml1_mu0Z-rYjdjOxWtdxQCszVUUw==	\N	\N	LA	2026-10-14 17:03:39.124971+05:30	\N	\N
548	Jb133	gAAAAABqz2iT9BzbHQd8AzhKtAoag3bkkO8gQITtUdQXY833bZUk9_KdsQwMi5CtjavJ4fkIydjzSvx9CEZtmpVSmj1F6_1wEQ==	\N	\N	Athens	2026-10-14 17:03:39.23358+05:30	\N	\N
553	Dawg202	gAAAAABqz2iT3hCas-VTPnFmYUnJ9izksaLzGvKkxM03gwIyNu7i0ZPs5DdFAt9A1JmykSW2-4FJUOWrPRr-4Jhe774gLqjSXg==	\N	\N	\N	2026-10-14 17:03:39.326703+05:30	\N	\N
558	Ml7	gAAAAABqz2iTIgrKxDWejH1nTZpytgUlf85SV3fk8e2-Sz6_rpOVW402KVW0H3ffzNMMh5PsUQArOvkG87lfwZoMHq-GBNDY_Q==	2000.00	2000.00	Orlando	2026-10-14 17:03:39.426373+05:30	\N	\N
563	JB351	gAAAAABqz2iTpjZUVXCjDps7ayrhToA0yf5G6KjdfVjng7-XFV7Y1BRkcDZP7DPsuFJz_3mJBPHs2B0FJjRN1ozQyl6uO9juUQ==	15000.00	3000.00	Omaha	2026-10-14 17:03:39.519558+05:30	\N	\N
451	Trbl373	gAAAAABqz2iRN9xIsGwvgerqLi23YYvwaGWm2fVW2DrVGqK1225YVeLwNf204kWs8SO0hdudwY5GtEtpqWQd4LwXQF1EkC15Iw==	\N	\N	Miami	2026-10-14 17:03:37.268968+05:30	\N	\N
456	Jj000	gAAAAABqz2iRyCSPsNopymasnEINWNU1JecQzTavCvhtC2JEG3YJYwYnhjSqe5kQI-i9cR40_PwK3aJ_ApxLbMEHWU-CcNAbQg==	\N	\N	NYC	2026-10-14 17:03:37.365573+05:30	\N	\N
461	Sg6161	gAAAAABqz2iRlNn0isF5OLXhYgCoJLwimHQ_YWdG8MR7r13aCmUW3P-2JRLhwYpaBpjQBSHHYoipCsQI8bZqFgHummHGsLWeOA==	\N	\N	North Carolina	2026-10-14 17:03:37.461604+05:30	\N	\N
466	Tb358	gAAAAABqz2iRi93OfO4MTnXvtkkjeMarssVsjKRe679UFHlqwALh_zbmVXUG_ePKYcEGxdczh3uJJLUnS1Yd_Wpbaqnxcs8i4g==	\N	\N	North Carolina	2026-10-14 17:03:37.553781+05:30	\N	\N
471	Tc8304	gAAAAABqz2iRDpG-Bn0QWLO8yPloeFHXq-s-E3FQIUcOmm2fn4PnJu23G1TU136G0fK4rDlP9iyIyhjjRNdBFHDwn8LHOMcKuw==	\N	3000.00	Minnesota	2026-10-14 17:03:37.650134+05:30	\N	\N
476	Bobby125	gAAAAABqz2iRMv2PHTb0O8IS9oqxyWULSPTmER41IIdgWJtQpDeLBN1QSSZt01iQxj0HVRXjWOxlEZ2swHgcNBufh3ScyUE1WQ==	\N	2000.00	Miami	2026-10-14 17:03:37.745361+05:30	\N	\N
481	Zpt854	gAAAAABqz2iRCzNMPhD2yMBuI6Oe2UcaFBvwfmLLVrb7RIzLl7Mfc_kF9N_SpQ2_tODOx5Vtx_MIc6QyL_iMx0_f0YYlj1cTRA==	\N	\N	Minnesota	2026-10-14 17:03:37.843067+05:30	\N	\N
486	Bnt508	gAAAAABqz2iRfY15YxRAHgcalcoby4C0KNq2FvriewqoENsATAMBRrlIlAOBxVRzoptTeNmzlddJTBKZokrbmM3Kq4z2X0Tj9g==	\N	\N	Miami	2026-10-14 17:03:37.975627+05:30	\N	\N
491	W89347	gAAAAABqz2iS_uJwLyIjen0M771h6xzdNoMqE3q8RljaQVEIipVvj-QrdBLpc1pn4vS-aqYlyFp-IfL3vBUionwej7uUlQMMtQ==	\N	\N	Minnesota	2026-10-14 17:03:38.0817+05:30	\N	\N
496	13-730	gAAAAABqz2iSAGhtWCFI99UPDolJAw5Pl7a31M5qJpfUYGRSU9Xl4z91mwLxLAyPZq-bo0UcIgkufblhrEPU_qhbTxK4U3Pw2w==	\N	\N	Dalls	2026-10-14 17:03:38.182961+05:30	\N	\N
501	Karlc	gAAAAABqz2iSE6sO_y2Y70zvWo5pqKQ9HQPR3s_heUmi5fAVGWuraObPO6U7t-idkWO2XWcT8PzVNCPiQBp1Ao39oAgIvcZK2g==	\N	\N	Alabama	2026-10-14 17:03:38.275512+05:30	\N	\N
506	Xjg4540	gAAAAABqz2iSWBGB_xOTnZDRAc3GnTGxSkrJDuTelKvVbnZiea-LVHibkTC0WqEo-FUkWfh_sxA_TrD6bFSycOuvssaqN9Bz-Q==	\N	\N	Virginia	2026-10-14 17:03:38.374833+05:30	\N	\N
511	J742	gAAAAABqz2iSOtXvQQxexe5-jmf3w4mr2M5G-1GcZiiVpDcj6Qa6HfborE3tVHbJn-eXNurK_RM2mh4mTQQlv0nI5ZTNPmL-Qg==	\N	\N	Canada	2026-10-14 17:03:38.471279+05:30	\N	\N
516	Tn329	gAAAAABqz2iST4auEiT1DrPve8BeZGWipilPIafEfdnYMAVS0Jkdu_wMIVrS2Ww5ZqOsQuFkKUDTibKQZWue3kG_o79PComYfg==	\N	\N	\N	2026-10-14 17:03:38.568276+05:30	\N	\N
521	Jt1689	gAAAAABqz2iSPY8hZkLO74Gszs1AVfKLUWYMQnabuH5q7g0HZi6Cx-_dROpu-CF_ggc7a_x89ksDFPlkWdgIf07FcXytIVQf_g==	\N	\N	Miami	2026-10-14 17:03:38.696961+05:30	\N	\N
526	Az0106	gAAAAABqz2iSTOTgehl7eEokDtzdQ5dK9GsSzuZFgRtoJt08Ig2AGZYczXxrZFABSHdU_TJJ42EoxYMzJJuVB2l1pWyRDK-B0w==	\N	\N	LA	2026-10-14 17:03:38.795218+05:30	\N	\N
531	Elc1132	gAAAAABqz2iS_T07QWh1mRXGWRcomMoS1R3IVl5ojvbonf7Wdd37CbYJOfDMgQOarts0CD5WkTYIuP-lArp6POGvNBE0CcEoTg==	\N	\N	Georgia	2026-10-14 17:03:38.893956+05:30	\N	\N
536	Se324	gAAAAABqz2iSEe_OudAE6PGxfaCcJ3scgrRiPqkTR9q0rXzxRYJi9KJ8W3SoiOPhNXb-fYpn_6sKoG6J-sLJCGtGpnYnXhJskQ==	\N	\N	Dallas	2026-10-14 17:03:38.989385+05:30	\N	\N
541	320	gAAAAABqz2iTW-Jzd5UFQUZ6CWDnNNTK7ejwx8RaF28Kqa3XZMtgOE9lZDbeyfAce0CwrIgzRLoCecss5qoVIrqoqYQZxKkfNA==	\N	\N	Massachusetts	2026-10-14 17:03:39.086932+05:30	\N	\N
546	Lca2601	gAAAAABqz2iTFZC50WEIogCGTdPcjem8stG6xn7PIux4HAp2AwHVIPQRlh9qHtF6d7jn_GDqDM7-R-PqT3aClwdsVSGy4rY8fw==	\N	\N	Dallas	2026-10-14 17:03:39.195759+05:30	\N	\N
551	Snl59106	gAAAAABqz2iTiMR1NyZARnlZGSZJBOC2VqOWxsOdCQlM6DeaELJU4UgqTxevv0c8MScmKSeC6EqL1letufjlNQf0lMlsd5E0YA==	\N	\N	Georgia	2026-10-14 17:03:39.29139+05:30	\N	\N
556	W22662	gAAAAABqz2iT-tfaNYI749DwDK_bffQajVBciszkPR248WwJEGDFrdwdkgIC3jqQ1o8SxgrADwh7N5V-1Lwhg34Npdm7fGzayA==	20000.00	20000.00	Boston	2026-10-14 17:03:39.386199+05:30	\N	\N
561	Db613	gAAAAABqz2iTmNpvEMgFCxuL4Tqz-s2rQhV1Tuc-Tx_EnNGio7OG7uSTm3a_xVtuTgTUSgJcvV6BMvd6r2c3lY7axAkBd2La3A==	750.00	\N	Omaha	2026-10-14 17:03:39.479077+05:30	\N	\N
452	Mia175	gAAAAABqz2iR3QF4oGoTaUlyAg9LMjR58-CLmECvBqoOkR1Wplnt6pA2iErPmz5DsxOBOmMFq7tVrTXW-G1MmeAKtrnTn4fkdg==	\N	\N	Miami	2026-10-14 17:03:37.287966+05:30	\N	\N
457	Sj8888	gAAAAABqz2iRSEaREPuBSTZTrtRjhhzajiWdrEPNbGLPt0oJqjwMF9AffC4co1LeC7nHNF9MT6QEISDGULsEoVOe1b3OEpRRrA==	\N	\N	Atlanta	2026-10-14 17:03:37.383873+05:30	\N	\N
462	Tb362	gAAAAABqz2iRzuFQlTK4UQDH-PP8XCzO97O_8J7CmIqSpwv7PpS2TTS_qgcCAl8-_nLNa1l2UPYhG-GRyye2iqlHnzVZa_2lOQ==	\N	\N	Miami	2026-10-14 17:03:37.480491+05:30	\N	\N
467	Tb384	gAAAAABqz2iRfKdDvarB5yDYZz62Ut8dMis44Ik0XtbdCbdZQi_nT3bBRMnTCwSV4p-WXOCdyj9NKj16Pi8ZWlUd1-HZwYPmCQ==	\N	\N	Washington DC	2026-10-14 17:03:37.57347+05:30	\N	\N
472	Jh177	gAAAAABqz2iR35Z6Bej8mWoDUPGyVt7VdgPSeTz_8A_BJTpcfNvBN6Jqdv_ly8xeczcAGcTqHELDElakM-FWm07jkPdG-_OYsw==	\N	2000.00	Miami	2026-10-14 17:03:37.667967+05:30	\N	\N
477	Willh608	gAAAAABqz2iR0ymvadGxCZTMI-RzB6InoHRxH-_TmccA1ZAf0Oprjl_s1G1HYUbgiM5kosYcBg6nFvtsU2ZywG_hEcykxKrbKw==	\N	\N	Pennsylvania	2026-10-14 17:03:37.765148+05:30	\N	\N
482	BNT515	gAAAAABqz2iRpxPLYV-f7vNlYuuth4y-E7S5xL0difiZbk4RT3Xg_AuFZJub--hCEkJ8EFscmeW47G5gSz0n4GVgoHkNJ1_rsQ==	\N	\N	North Carolina	2026-10-14 17:03:37.86282+05:30	\N	\N
487	Bnt505	gAAAAABqz2iRrfZM3TooCUNyiYo-xHHBCv6tTbjlJuH1FJlTZlSMaV1uFeGcqDqfbrUAsTGhkxmSEMCybgEyR7wuUMeD9bF_JA==	\N	\N	\N	2026-10-14 17:03:37.996365+05:30	\N	\N
492	W89359	gAAAAABqz2iSwJlcgih3e2fOXla9ymQI1MA5pMCTQVFnIsr8ZKrMrb3XvqHNuiGPAGXX1La7W3bBE9FsdDx2HoBIjGr7vz8XTw==	\N	\N	NYC	2026-10-14 17:03:38.101027+05:30	\N	\N
497	Mj46	gAAAAABqz2iSCzFQUKWStmsFBqfFSO_bsqpPTohYVzwbSE8ZygiEZhsJJf6J5PYqeHgSNSkvOzqaJL2Xr3w1g28w_qlEZB48ow==	\N	\N	Dallas	2026-10-14 17:03:38.202976+05:30	\N	\N
502	Chris224	gAAAAABqz2iSiq4_lP3LHHj0A8rD77mWAGjjAY4-1YTZbPur7VcQH5dCr0wnMdcfoPUbdfs8PVPxbKbgsmvYBpDTYRyJiCKpmQ==	\N	\N	Dallas	2026-10-14 17:03:38.295983+05:30	\N	\N
507	Xjg4541	gAAAAABqz2iSJ36kQADJhbIWYxWR3fI2e6l8iSB8oaGCerOF-cOPBwPq9bGkafOcX_a4VaXteR172IvHaGrg-R5WVL2H4e__mA==	\N	\N	North Carolina	2026-10-14 17:03:38.39321+05:30	\N	\N
512	Cf221	gAAAAABqz2iS1PFAmtUPM5mmQvfyICyN8aAm09hKgT_Mf6e-57_8BOXx6-42vDPcBxP3l61EKLtWW7b1HoAgoG7cPVAAiwOryg==	\N	\N	Miami	2026-10-14 17:03:38.491167+05:30	\N	\N
517	Tn330	gAAAAABqz2iSLze0csF1WqeahFlipCMqQtuiKTWQCIq_9T6x05n3fvDNm1xr55EbN8GcYWlQtlC--hirdTvReeAC5AZ2GvkVOg==	\N	\N	\N	2026-10-14 17:03:38.607273+05:30	\N	\N
522	Pac1085	gAAAAABqz2iSBIXyDOaUitRr-0yHOQ7xWZ60CQBU5pXJz5ZyBOa-V8wte3JzoUiUjK0Dn_6XutP9_YieMMVKMT_UovCwazV-8w==	\N	\N	Washington	2026-10-14 17:03:38.715695+05:30	\N	\N
527	C12023	gAAAAABqz2iS8QY3BA2ntNOP4C0kznGzhBuANlB_n5jPRG5vwYMU8XzBUbhsIjoB4dSV6KGWE8cJHbGQ41yJrzySg_OumEqdgA==	\N	\N	Miami	2026-10-14 17:03:38.815696+05:30	\N	\N
532	Va114	gAAAAABqz2iSXCZvnJYPEHP82Pi9STs8znr8SLq3jFH09KTgaloK1drHxpFaI-h0Qo3OgTBGVdmX6xW-maeOlmriz-krmMkX5A==	\N	\N	North Carolina	2026-10-14 17:03:38.915466+05:30	\N	\N
537	Az109	gAAAAABqz2iT8Rurp5KAEJW50HuUawcjItVWV4VCjuFO6JJ0Qv2SLwfR4A0n8Cw0BwRN4rb0sxGwjhkuzVdjK-BMK9SwBfjBvA==	\N	\N	LA	2026-10-14 17:03:39.009027+05:30	\N	\N
542	Apo14	gAAAAABqz2iTIn4oSM2lYIJnKcK375esona8bMjOV8sdJyov7VJvFpYHv7pj5Wi4yf7RaLv5YKFlbDaVzYnS5ZZaYfxVEyHspg==	\N	\N	\N	2026-10-14 17:03:39.105132+05:30	\N	\N
547	XI1005	gAAAAABqz2iTRS53rbJyzwC1jSHs1aitinRVreIrFdscsO0f6KpfxYfVp_8wdl7UFI_tlshoPSgSYofZLTSII3c4EXwDyjs5bA==	\N	\N	LA	2026-10-14 17:03:39.214829+05:30	\N	\N
552	Kaf279	gAAAAABqz2iTaKsLW-Khos1QNT4sw17Z_z4dnVO8oYHp-DLF6VgTtFBk3F83pWnNHpNUucbZbaVFoVVZ2A0GSjFWtTLrNEN4hQ==	\N	\N	\N	2026-10-14 17:03:39.309566+05:30	\N	\N
557	Ml4	gAAAAABqz2iTQlkHmiTu3LhiQHnKkyO7LEtWMm4pdM7xTd4wjauXmz6_-cDk2sSk_95IZFxk6gHIYcyQGY-CFG3jDJ0RFUu5vQ==	1500.00	2000.00	Orlando	2026-10-14 17:03:39.406407+05:30	\N	\N
562	W59	gAAAAABqz2iTjmA2bOzrArARh957RAu7Vgaq3sdtjQGWq92Zw7LW-GZ83kjO4bCC-PeaZic2i57vB7Dw-wrTnCNp4fBnGLuMKQ==	1500.00	1000.00	Omaha	2026-10-14 17:03:39.499607+05:30	\N	\N
565	Litt01	gAAAAABq0Gnclx0toqfDDEyksqzdSelsBUZdnj6CglzvoCdyJn9_eNSjk0PhYpGk3SORcTH96zJeuIy8S-XDoEmtp0jke6wrvw==	5000.00	\N	Houston	2026-10-15 11:21:24.084071+05:30	\N	\N
566	Prt112	gAAAAABq0GncyKmsMpdMdR9QepK2sVWKyUqUojo7FeCnV0xn86D7KEFC6m2PskIzMCwLQ2cWw3GryjcUELbc1etyxKi0-5yDkw==	\N	\N	\N	2026-10-15 11:21:24.140538+05:30	\N	\N
567	Tig110	gAAAAABq0GncIhhNB3lLP_Bzz9xBqNcwxov79v1ysjZzS2cxt43CPJw6tV47AIRN0zmRsLUZRompf_pOrMAx0Zul9J7vkj2XsQ==	\N	\N	\N	2026-10-15 11:21:24.151961+05:30	\N	\N
568	Gf24	gAAAAABq0GncY55SkaC-lhHicmftnkpvFEJjG3KVX3Yy0mVF9XHGWmCpFwnjM3cNFWp2FKFdUh3bJWCzmUH_UUJ9J4O5eaAOzw==	\N	\N	\N	2026-10-15 11:21:24.163654+05:30	\N	\N
569	Gf21	gAAAAABq0GncthMVseGQsfNBYSEDyshmkLHw2lcffvd2Q9e0c_8qpUeKqP963M9gz5dA18U0zaTMeEfrkLQca4UKA3BbtxdSKw==	\N	\N	\N	2026-10-15 11:21:24.176278+05:30	\N	\N
570	Sle76406	gAAAAABq0GncmIP7aohMtRB4ezOdGnQdJyvs4i9ipt5n1ygypYFcCUhrmgL9hS9KvhduXDimGXcLVHhUXxxPSwE1OdsQLH6XtQ==	\N	\N	\N	2026-10-15 11:21:24.18782+05:30	\N	\N
571	J4977	gAAAAABq0Gnc6eHw6XBosNr6DD7IRdy7ks-zozNAPdjLKuELSLGf4ggz78ZltU-L6qzv2ouLgMQCY2a8aBLdHszk0gwBD1gicg==	\N	15000.00	Dallas	2026-10-15 11:21:24.200361+05:30	\N	\N
572	Hp708	gAAAAABq0GncyKvPZ2GtiQQWn4YMpqouE0QUKK2v88hY5j_mNaPLBuPEvf7lrPjCRYZD58o9DIadbSxu-chO_ARfYwK6BCY6IA==	\N	5000.00	Dallas	2026-10-15 11:21:24.214893+05:30	\N	\N
573	Kelly25	gAAAAABq0GncF7pqLCafvJYP4cka_DB0LqIOfcX8nyP_FIBB0GWpWe9yWFZkgWt9sh5Nv_VJ94rgb9XE-OTnG44jXshkBTx3Ow==	\N	3000.00	Dallas	2026-10-15 11:21:24.22889+05:30	\N	\N
574	A214e	gAAAAABq0GnceQO0Z79UJq_mGNW33hlB3jWkxMH-_h1W7oUIQDNgaueSmNMckbBFqok-7XVm1WrZ_2zs2R9ug-VP1XRZetgwXA==	\N	10000.00	Dallas	2026-10-15 11:21:24.244509+05:30	\N	\N
575	Jac1612	gAAAAABq0GncaYIvU2QlkVKvvGl-kUREuD05PYrlTZtt5oWXR6JDZ34zixIhNwVne6xHl7KS2Mz7EXMVGk3nUQ3ltibULxDPUA==	\N	5000.00	Dallas	2026-10-15 11:21:24.259048+05:30	\N	\N
576	304	gAAAAABq0GncE4QgMznZrH-caU3DOwJgrmATV-L7Dms62FKlKdsE6gi9_qJtK4bucR0xEkwl4lb0pAC9HQh03ZdamSAUktT2lQ==	\N	30000.00	Dallas	2026-10-15 11:21:24.277284+05:30	\N	\N
577	Dv1518x	gAAAAABq0GncY5tDKnv2a9z6YWAmOYNIo3e6gWhT5blX8h2OVjfvKDNCnubiMFDKKCQpFQFjQMTSLRuiG9K8jVfBnMd4vhJzsQ==	\N	10000.00	Dallas	2026-10-15 11:21:24.291822+05:30	\N	\N
578	Pr652	gAAAAABq0GncYBolFQiLkzG6hDpJ2uajgrNbQ4nU_SyuOa8w5vYInJVGkft4fT5eZThOknr8bKrBms1KULa91ZILt6JZwiE0UQ==	\N	\N	\N	2026-10-15 11:21:24.308041+05:30	\N	\N
579	Jfb2093	gAAAAABq0Gnczll5D4OZl2KgrG9XNrnZQPu3TS-RmunRPoe8boFlT_lMo2obFhbL6K-xBboga_6SW3YrCFsPfhXzcKvpj4RUAg==	\N	4000.00	Dallas	2026-10-15 11:21:24.322219+05:30	\N	\N
580	1cd203	gAAAAABq0Gnc-0_CRMQmzp-reWAomGMJTIe3I0mZYekmYAyAujfhc0C1BEXElF6j7UwMIzrPUs0nrhDLwbgNimXRgyJ0C8qwOg==	\N	5000.00	Dallas	2026-10-15 11:21:24.33769+05:30	\N	\N
581	Lh81805	gAAAAABq0Gnc4zmjsuVMC72B3jnYAOuReSktUKdqatkaWBmSPf17ZSCb9CLJFrzPGWHt_zZO65D5heqW_PdUR-YSyoYHIe6GMQ==	\N	\N	Dallas	2026-10-15 11:21:24.352086+05:30	\N	\N
582	T230	gAAAAABq0GnctRNgluioDpUTmliVEDW3Zwmt5DwYYq_TGyqZq6eznsWC2LfWNoYz3UiHUXQRMZ9kxm-qkMz1bZ6jLAi-NnBtrQ==	\N	\N	\N	2026-10-15 11:21:24.368161+05:30	\N	\N
583	Rk1003	gAAAAABq0GncknpehPWWRIC0qNCDu75HsB4FsKl0MQpC3758bBvorHqYrEqSKWBmAtYpTwqwQLihoGlzFb3xKyIfnqfPPKIKNw==	\N	25000.00	Dallas	2026-10-15 11:21:24.385345+05:30	\N	\N
584	M8228	gAAAAABq0Gnc3GRtr7vEf8JiW1PHmwMVbtgh7W0bB1inVfufvaPgPw3xO6CL42NxzH0rHxm992P8r8CEnKsF6g5MsisA2FBjEw==	\N	30000.00	Dallas	2026-10-15 11:21:24.401566+05:30	\N	\N
585	Co15	gAAAAABq0Gncxa5WsEl_9HiDQGAQa79GZ4qdybn-qKNNTZ6x5JgwY3Ri75mkPNsCZWOaXY3nM1vOOwi7cM4Z_i9q8wGS18g1VQ==	\N	\N	\N	2026-10-15 11:21:24.416129+05:30	\N	\N
586	Ord1053	gAAAAABq0GncfJq6l1vXt3wLLW_hc09hk2ktDqA-KxBH1dRNrvgHngoHZEyEAO5zfGfkyvIsW4Gd-8HTo-YbTys5-iFUwo86lA==	\N	\N	\N	2026-10-15 11:21:24.429764+05:30	\N	\N
587	Br263	gAAAAABq0GncYUMXpfKXYeYKXKrcaDGBn7o6nabz0pmwttBRLoUu6l7xamWTN3ytEuc1Y_IcRfEPd87NjKIguRtEAMegx2EDDA==	\N	\N	Houston	2026-10-15 11:21:24.442016+05:30	\N	\N
588	Pp1129	gAAAAABq0GncqGApsMFh_DPQND-I3tejy9tdvFxSAWuu6t3dkQfZZ2dqiVwkmPA4l_-Ng59G_4fX03205icxKupu5RWBV-vB5g==	\N	\N	Houston	2026-10-15 11:21:24.456772+05:30	\N	\N
589	Nit1055	gAAAAABq0GncwyDnBoAAOrGd5YjKtNS7of_OfxId9UAf-V98m5V7-yib7WJCxme40hg023HwQy9DzQYGPQ6ZOdwjtD02DahMhg==	\N	\N	Houston	2026-10-15 11:21:24.471709+05:30	\N	\N
590	Ltd635	gAAAAABq0GncU8ZgP8v2g8iMSqakROs7-IaRVofB0OzUDo8AttVwqwJm4X5v_meKU2jkFuKWgXz1a4nJMznF0q445Dd_uNuzoA==	\N	\N	Houston	2026-10-15 11:21:24.485964+05:30	\N	\N
591	Bd5023	gAAAAABq0GncdebEYgdB3xGWU0FBbB_wigJsSO8iI3-H787FMztMC_I7KktXV2E2SEk5pUpcpgm-qin_z6gexf5BYTpDjeoqHg==	\N	\N	Houston	2026-10-15 11:21:24.501163+05:30	\N	\N
592	Soy398	gAAAAABq0Gncng9LOnK1v5kIzcgTIXRyOZ1EXelcS4Yvt9ZExJSY4vtaRlRpmPy0Ir54zpFxiYjP2-q4k-hnA5zFS5OEgDZ8tg==	\N	\N	Houston	2026-10-15 11:21:24.518747+05:30	\N	\N
593	Mb1299	gAAAAABq0GncrU4HHCFU2vugx36TPPVjWiC5iDFWfUYY6isEY3NdJXDxpZ0oBu6hV6EH6v5ip5wdah-cVp9Gnp5n1vuEYWOh5g==	\N	\N	Houston	2026-10-15 11:21:24.534302+05:30	\N	\N
594	Jac3703	gAAAAABq0GncTNWfGGtSJFXWp-fQedxpnYPgCE71q-SBEk5qpXm1PEPJOZRROkQ8ZOGxP4NvFuQlPFjphNQ6dc_jF1_Kx7Ftxw==	\N	\N	Houston	2026-10-15 11:21:24.548902+05:30	\N	\N
595	Jac4704	gAAAAABq0GncONQvgMcMEGU_z8lDQdFS94vHrLIwmGm1pXlN2deN_KFJUV7IGG07Ny_5TIn_24LoWbSw6Dp-EUV2sMLPaQOXJQ==	\N	\N	Houston	2026-10-15 11:21:24.56412+05:30	\N	\N
596	Han2307	gAAAAABq0GnckvyQXa6qlhjfiLTG2FODQN7ev8aDFMX5O7t-pr3Ug4p_KA-Avnalf7kiR4kTEIXus96BUuxfJyBPepoggsdcEw==	\N	\N	Houston	2026-10-15 11:21:24.578414+05:30	\N	\N
597	Mr1058	gAAAAABq0Gnci6YVhCBu3YHNcTWzhbR_oltundDRTLha5TvYqB4o6xWGMl_HJUDYFX2_EVyZjdVgBbyp8McqjrzHrXMHYfOogw==	\N	\N	Houston	2026-10-15 11:21:24.593561+05:30	\N	\N
598	Ddd163	gAAAAABq0Gnce4jiie2BbR234XrbzBVYk3uHkyIgz_7swLWCimlLpWGS9MYWKHqEr8HgPrhEgQlcBiqM-KEuwGMEL5Z2HEI2JA==	\N	\N	Houston	2026-10-15 11:21:24.608056+05:30	\N	\N
599	Frn101	gAAAAABq0GncoG3SIk03Wdkbx6RhFvtQ0Tvxr8goS616kkdn_2llvswbr3xr53r2EZqU3zgYKGZvr19UbHQ93XYlGDxuxSAjKA==	\N	\N	\N	2026-10-15 11:21:24.621904+05:30	\N	\N
600	Co16	gAAAAABq0GncuNheY5VaVXNNOeJxwEspC0AN2AwymR6iL2vz0Ttt9PA3gThnFJ9EEYt3nnu5YkWFA9J9FBvtfJEVHxuFNkW0Bw==	\N	\N	\N	2026-10-15 11:21:24.637643+05:30	\N	\N
601	PWF2820089	gAAAAABq0Gncnck7_7o-RshwUgKXajiVgMvWNqznuL4X6eA-rzRdWAFPLOymafpHXMspVUNfG1lmixf6Zhfm5XKtSZWQEINK3g==	\N	\N	\N	2026-10-15 11:21:24.649665+05:30	\N	\N
602	Ryss229	gAAAAABq0Gnc0qSa5J0zFYBBluPBpIbThF4hhw1bFVKenpmJAEQZ4_KoCTuij8aj555-pGF7uoS22yBn_uiy89k2eWFb9Hr-UA==	1000.00	1000.00	Bloomington	2026-10-15 11:21:24.664472+05:30	\N	\N
603	Bks573	gAAAAABq0GncK2ie8kpl7G8g7W9sZi_yrktqFm0ZM-CSGgAiPerMZFfWR9h1ucnoqKK2w77Fs2d9yg-21Gmy204bsmYNA1vDHw==	\N	\N	Syracuse	2026-10-15 11:21:24.679675+05:30	\N	\N
604	Prt136	gAAAAABq0Gncdpoblw72Ex_05XCFlY83vwJ0Tl-z2TCPs619uVlapVZ0gQx3T9cg7apbYv2eAU5driNdNcVePT4J4jaYdjJF3g==	\N	\N	Syracuse	2026-10-15 11:21:24.694737+05:30	\N	\N
605	Nic996	gAAAAABq0Gnc0bn3OHDSlKFF1cPCHgYTh2Igf9NP6hHQyGVB69OOoSYYgmkJbqv4Iuhnlt60NEx6fooXIyoX6WqhsipTXH01wQ==	1000.00	2000.00	Boston	2026-10-15 11:21:24.714179+05:30	\N	\N
606	G1256	gAAAAABq0GncNT0xz7Q4Brad-1kF4R7OEvn-Snn35N5CP8b6ng-2KYvqMa8nx0kMZskg3uDcgycNkg8i_QLEVqjwt1dUkmuVxg==	1000.00	400.00	Boston	2026-10-15 11:21:24.729632+05:30	\N	\N
607	Cub73459	gAAAAABq0Gncycw23xhnrTyCWCjmADuHhtoNwwOnF7lWW7g-lyGFOtezQ-Gw8Uk5oCqhK5Q03_48iD0unguLtJV-QzYv4hVpTQ==	2500.00	5000.00	Boston	2026-10-15 11:21:24.748437+05:30	\N	\N
608	Jp5107	gAAAAABq0GncgJeVZIhZHj7ku_UpSGsCqZTB4SohJF6_-KL3EDRK_V_K3xPBogJ20__4-GvukC8a3QMBG-qUmjBW5RMVgDIdrA==	1000.00	1000.00	Boston	2026-10-15 11:21:24.766417+05:30	\N	\N
609	PP67	gAAAAABq0GncVMYdE3iG9Rqp5m7vgU8MNDwEmfCUWXuxxxXbYHhGPmSFj73RwoLl0PGRi-YVOMJK1y7f8XamRBs8W-WvGC7RSQ==	1000.00	1000.00	Boston	2026-10-15 11:21:24.784681+05:30	\N	\N
610	LNK55323	gAAAAABq0GncRuvN8rIFqcvTJcemCmLR2vSzqHvvOObyYzFsNo0-muSdL4w5nMFjNXbfOFPerrZynwjCvkvH0UaX2j82sd1Bng==	2000.00	\N	Boston	2026-10-15 11:21:24.799144+05:30	\N	\N
611	Rck1126	gAAAAABq0GncyoclnxHbpsuAomj6QJVZYs8PUmJLNtc_8YebuIy_vLSXTndTmm_fNVw8Fb7xAalStVXaCo0nvFsHp80Dru0U5g==	1000.00	\N	Boston	2026-10-15 11:21:24.816823+05:30	\N	\N
612	LP13	gAAAAABq0GncyMbi2TUNZnqDq6FI5F_sGaDB29wiQ0zQKI7UOHR9cgiG8FKLgQiH4j4evpXiQyL61oBogJb4-aPEeNNrAqTUAg==	3000.00	\N	San Francisco	2026-10-15 11:21:24.831462+05:30	\N	\N
613	Az110	gAAAAABq0GncMu7e67gxRHoE3a1pK8aUm9fA4jpj8rpT9JZWzYxr0o9G4qywT-A8y5m21qtEjdJxMaGsULTp2qvVDqG1dyEC2w==	3000.00	2000.00	San Francisco	2026-10-15 11:21:24.846748+05:30	\N	\N
614	Az0105	gAAAAABq0Gnc5hquNLWpXqsM8zT0d-oG5juvedH9ICxitnzDpU4Edk_8MY_Pt02GhdK11p8CR7TkYT0-Mq3htq66lusjY3RdpQ==	2000.00	3000.00	San Francisco	2026-10-15 11:21:24.864775+05:30	\N	\N
615	Mc007	gAAAAABq0GnclXuF8BVtB9IlUV7dAgtUKsg4VcFKHXhmA7Y5eRAt5sMnxD7HSmOXoQzTBeZjuJN9TIxrqq4sciGMTdeQmnaljA==	1500.00	2000.00	San Francisco	2026-10-15 11:21:24.879985+05:30	\N	\N
616	Jordanwill	gAAAAABq0GncYUvaBASnz8BcnSVS1Dw89Z68afyIEMJsureg3t3YcQPFuZ2QuSBtjstoCsNz7GzYx1MfHd1pYLnToaLBUwZlFA==	1000.00	2000.00	San Francisco	2026-10-15 11:21:24.895759+05:30	\N	\N
617	Wc447	gAAAAABq0GncQQpDAo551HXz4AlALTGpjnJISh0eD21oeDfKO0p1XjZA7AcweyuGmhY5ifRogGTH9RwUSWgZ8568reghEjBSyQ==	2000.00	\N	San Francisco	2026-10-15 11:21:24.91426+05:30	\N	San Francisco
618	Map214	gAAAAABq0GncUFx4rThflUeObKjVv8tMUhmZyfLjNR98mp2g4W3PcYz7Usz85V40j5ZWVKiAOgUGuMaA4xlRkep_KwrqhN3RmA==	1500.00	3000.00	San Francisco	2026-10-15 11:21:24.930345+05:30	\N	\N
619	Sf1007	gAAAAABq0Gnc9NSjtZfS08bjZQ0mp2PMVibIDSTeewIP6vM3vjYNZHPY37KW63yjT-drQ-Vqu2OopEMBzAdAPUIbFpa1dhJvTw==	4000.00	5000.00	San Francisco	2026-10-15 11:21:24.946663+05:30	\N	\N
620	NL307	gAAAAABq0GncbmLqHgU9KGSTvvMSXHBROlKvKlBJqEJI6KgxmKNF-it7Pv0VQtS9hw9veZYkBajU4Nr1F1ZbXtgHPhSscD3XRg==	\N	\N	Boston	2026-10-15 11:21:24.967039+05:30	\N	\N
621	Pfk112	gAAAAABq0GncCMz8ilhrxkmmmpjRQ90XdWoE1PTU9WYtW99Jl3roooPUrGdPo1rYjLwbXsIBSFmGDdMH9ei2zzjwfI1mvnLJYA==	\N	\N	Boston	2026-10-15 11:21:24.987225+05:30	\N	\N
622	N1349	gAAAAABq0GndjEz8woB59LglNUt2IXm01xehNPB2Spw0z4MiOfkGRC9YNpCbgBuRvkfZKz8HtXScX3LSoSVat2qQwv7uuc7Raw==	\N	\N	NYC	2026-10-15 11:21:25.009273+05:30	\N	\N
623	N1351	gAAAAABq0GndoOGDROZIIItF7W-uAfwJtfG7CodTadK9Zp5tbZuRFOpQ24sVnyXFMeDwmUQrGhuiYeb9m76S42vmn7ClLp8ewQ==	\N	\N	NYC	2026-10-15 11:21:25.026+05:30	\N	\N
624	N13022	gAAAAABq0GndA5Lhhz1x5qKEcFBzL4pZZthIb_WaXvC8c51k8uePZWeopQ6oPyF-aHEENmUeJtDNKGFnKtpGwgpC3BIo8BAviA==	\N	\N	Boston	2026-10-15 11:21:25.042141+05:30	\N	\N
625	Deckfi	gAAAAABq0GndH_Wc1hzo7xQCN3e6gnkFMU-T-olpS0BjFkg3UrOXcRWsgf6zCJsK6Wf3fYzKHkb-o20UF1EsG5mx4CnAltx6Yg==	\N	20000.00	NYC	2026-10-15 11:21:25.057717+05:30	\N	\N
626	Got214	gAAAAABq0GndAIsL8IGcZGtvlVHcu8Oglnwk7D-5sUDcABoPxp_Sa0KGDrNvHwGe9vr4DQFDDOemqTc76mqOH9v9B9DMsRIJXg==	\N	30000.00	NYC	2026-10-15 11:21:25.075368+05:30	\N	\N
627	Blk109	gAAAAABq0GndqNijy-C6RboduU-6L16P1Wv0Bh3JBwrIFXblGrQA8bPz7RyQRHk06mfrypUGmlKqj0g9s_dPJB5BUL6c0D3V1w==	25000.00	\N	NYC	2026-10-15 11:21:25.090397+05:30	\N	\N
628	Blk302	gAAAAABq0Gnd1qKBnZhRZzHgACeiwgERBEnl8V4HVM8NP71Z1nQAvy70BaSUCpnMpDmzzh-uZ1FMLP_6fPwmZ6yp4Rm0qosgxg==	50000.00	\N	NYC	2026-10-15 11:21:25.107051+05:30	\N	\N
629	Blk102	gAAAAABq0GndL4qIrF1mGoooE3_-re4h1Kpw85q31drlXk6dvm0KGxFqU4MqWUxtIpdDb0AUL0b5IukxVkbS625cZ-e0qRfFTw==	12000.00	15.00	NYC	2026-10-15 11:21:25.123979+05:30	\N	\N
630	MM401	gAAAAABq0GndMPMSiFSAdiVMouBETJz-VEZ8i3fZKB6Bcurf9Q9C0625pxNdXUmDwx8vJOzkhagRR0PRcY2W5P3lsqMP7Jm0sQ==	15000.00	10000.00	Boston	2026-10-15 11:21:25.140134+05:30	\N	\N
631	Dr111	gAAAAABq0G17WDKV7AOg1Zvia2J9eZPyWPMcGYMJfH7ORCiPfoRkG08Mb2H2szauxZhVMJS7hj_Lfg6zokJJov-x0pfcn9FL7g==	7500.00	\N	Dallas	2026-10-15 11:36:51.601264+05:30	\N	Infinite
632	Dr4001	gAAAAABq0G17DpKXQMDXAWPQQuUSEl7n2xCtD-FCQBv8KD1oDcdzegKzfA-2-DhrCh6NxT5_AfrGqo3XurMV7ajTGEa2ZwgntQ==	10000.00	\N	Dallas	2026-10-15 11:36:51.617079+05:30	\N	infinite
633	St700	gAAAAABq0G17k35RjooJ80vjhbSdFwHSZg1rfHdWF6Ly3MveqQIgrgcdBKN8R97BxdUBfMMAb4Vj4icHL62cNfcuuBigXOT0uQ==	20000.00	\N	\N	2026-10-15 11:36:51.632152+05:30	\N	\N
634	St701	gAAAAABq0G1758F7Holx-iNP67BHjSg87jpTgdV1HDnG3mICU5BMPP3NFOyeTMSAhnCq6f9dm-i06ZEMgjj84VgewZUPYSIJag==	20000.00	\N	\N	2026-10-15 11:36:51.646117+05:30	\N	\N
635	St702	gAAAAABq0G17BxK_kBaL_fwhD5uc_e28vSJEly7Jlwr5DXQwJuje6lX7DaBed2auX8F36ma5NMJyj0j-hEWTV8Ax3BMScypVuw==	20000.00	\N	\N	2026-10-15 11:36:51.6606+05:30	\N	\N
636	Mg37	gAAAAABq0G17-_Ui69LLl3kIMZkMoLI0Tc9e7ayN1aWIDT5XpkHtmiBxgHX09q3FVv97pzATSA7BPSqksIsyaEQcvNkUFiebvg==	\N	\N	\N	2026-10-15 11:36:51.67408+05:30	\N	\N
637	Erikp53	gAAAAABq0G17esz0mD0jDNQWx6kVW-V4pgyIffzUqxnqqywFJFqAlOXkkGBsd8PwkzmfukP8ugp-Y4Av-LjHxg9WMeo92HNmcg==	\N	2500.00	Hoboken	2026-10-15 11:36:51.686256+05:30	\N	\N
638	W3930	gAAAAABq0G175eWXXqI2E8-TBjVEfY2j8T4VG8PNkoyddNh3ADDhGHwyF2o4IxH0Ec3r1Q31gk1KGOlC7mbw2XDgtr_Or_fUuA==	\N	2000.00	Tampa	2026-10-15 11:36:51.70025+05:30	\N	\N
639	Bgg401	gAAAAABq0G17yNmf8tZcyDVlm-_NpPBRlCteRIGFzAfUf4j9Y3nNsoMhlzyzOy_0ZY8dEQ7kL33QDgL9qXd_E-V7QE0bgUND0Q==	\N	15000.00	Dallas	2026-10-15 11:36:51.714707+05:30	\N	\N
640	Rj5830	gAAAAABq0G17sKzeycu2LCQmMCe26HUuSLs-7gFkk6nDZjAaPcqcpDC5Im0Z8NAex3EAcmpIU6feBfbmXphh9v9UHMkkoqOP1g==	\N	3000.00	LA	2026-10-15 11:36:51.732848+05:30	\N	\N
641	Bc5361	gAAAAABq0G17ggFFSGTyLLOiBYZBJ5o3-_X3uX9Ktlg2couQ2FuE141w0xRRULbZIP0nC9XKfF_1gCVdOB4tIk42fmdSMKFlxQ==	\N	2000.00	NYC	2026-10-15 11:36:51.747343+05:30	\N	\N
642	Jac65187	gAAAAABq0G178tP3G8BCO4WvCUjz3HpTkQZOoE8QnfLaI56AdQZEjlX4RFqAfrq3UcXyHf_1NoUzNlyqmTOlHYPN_CrG5ghw_Q==	\N	3000.00	NJ	2026-10-15 11:36:51.76251+05:30	\N	\N
643	Lv106	gAAAAABq0G17J8xU8Voqc8m3JvK_uu82Kynh-P3egLNZwdrzsULCZUEYd27x-JCiWEq4ZRKweldk3BfoBy-pQYEDZDQRTwdIBg==	\N	10000.00	NJ	2026-10-15 11:36:51.77736+05:30	\N	\N
644	Qxcrd122	gAAAAABq0G17O6TFj-sx0I7Ck3eKS4Tgsg9oWhAXpO4Rm0XfZgbBOzQD73WHBUvWaHx9tMcpZ6yeFPwWkf0t6bw1C2mFknDonA==	\N	\N	\N	2026-10-15 11:36:51.792386+05:30	\N	\N
645	Qxcrd108	gAAAAABq0G17uLaJ94msmZujyn5hUNOMUIhxYRFWngZJWbz9Dr6Wh-vOIXD5cMN_vWdCsNyETyH6kAOlj6IQNxhFRXJhmcFaBA==	\N	2000.00	NJ	2026-10-15 11:36:51.812739+05:30	\N	\N
646	Thu117	gAAAAABq0G17sEZVPtc642UNEwgo6eJgq-9d4W6Qqp1iMgkB8JtWJcShnUEOjImQppxme91h5dnpo1OndaE6kS98NFAtEXStvg==	\N	5000.00	NJ	2026-10-15 11:36:51.827342+05:30	\N	\N
647	Mm121	gAAAAABq0G17ofHmNxJqDXgB82ioQ5GiLFoC82WEOQ0PZXNtjGC5Mb_dRQNLy8DheJcr_mtL6RHBjR5tMMNnEDXxpNgfM8_z8Q==	\N	3000.00	Hoboken	2026-10-15 11:36:51.841355+05:30	\N	\N
648	U508	gAAAAABq0G17RJFSnnne3P7rwIGhOHjTgtc7EMblDxb2vV0I505Q8_KIoQlSedOhGw3BEb3xIGnL1BXE37myKxJjuOgKJSesFw==	\N	2000.00	Sarastoa	2026-10-15 11:36:51.861372+05:30	\N	\N
649	Aa365067	gAAAAABq0G1732QpYz3s1N6vlnSPRPoJ3VpK5d9a5CUTrHHe4F3ZvTLtUE3tPzuWXkdvLBDzphC4zm3RVP3Opx1TrR7qDEXLPA==	\N	2500.00	NJ	2026-10-15 11:36:51.876148+05:30	\N	\N
650	Aa365061	gAAAAABq0G17wi2IQIKLLV2hxWYZ6cCNH9RpYrya4xQbm4KixFUJMt87TWihiZui1pFQ6Ojxo2qzsD525MNNr0krXhvth0zjaQ==	\N	2500.00	Pitt	2026-10-15 11:36:51.892198+05:30	\N	\N
651	Nhb132	gAAAAABq0G17rOtzcL9qSRZCct061LBzFbtu-57NSSmX7KpWOwX7na2aJh81F9b6HUJQVv0oTgxJjpTJ97jV8365pk9HP1J2Bg==	\N	7500.00	NYC	2026-10-15 11:36:51.907353+05:30	\N	\N
652	Og04	gAAAAABq0G173Jz9l_CtJzlRjFcxj_deKzHcvjDowumcE-GVxzOHBBPqAMtWynN3j0yE-DTaoXwiBUjNWFEhLzOGHfEMtoO5Pw==	\N	5000.00	LA	2026-10-15 11:36:51.921593+05:30	\N	\N
653	Ko005	gAAAAABq0G17n63Ts1fsPMkcwX4ddQD1XjCq7Aup9ZotljNj2V3KRC6YrM8r3RkzZtKlJU-_IRK4HoO3F1-WAj2vlpNgNVi_kA==	\N	7000.00	NYC	2026-10-15 11:36:51.93581+05:30	\N	\N
654	Zzz16	gAAAAABq0G17D4tDNoh-S4VBfGBHT_Wvy2dE9siQdXj6bSUmpB_kliU0B_kODfvty2RnfnvxKBQCp7VdF88cmKbmP0P6rLYplg==	\N	1500.00	Miami	2026-10-15 11:36:51.949715+05:30	\N	\N
655	Zzz30	gAAAAABq0G17gKwAhcReBhHg7aHaj8uLla0jfCpCUwN7S4DvEpZQaYRYtdwbfw7Z6FsGFEFo0PMd9hNsH2NweO-lDpc5w6_CIA==	\N	1500.00	MIami	2026-10-15 11:36:51.964335+05:30	\N	\N
656	Zzz20	gAAAAABq0G17_YfxfmypKs3vOxZ88jQSdl8e3GW1vELbgyTxRW235sxd4TL0su335RgNhq5zR8yHtp3ZQgaynNKw_uhq9XVdmw==	\N	2500.00	Tampa	2026-10-15 11:36:51.981926+05:30	\N	\N
657	Zzz28	gAAAAABq0G1794mYO3zdjlL4fqpbVg71Kv_Q_scy8JZz5PB7kap4n29bID90jeyBjmDOo5qgjr1ll38_73rOzOIKlm5nX0Xnrg==	\N	3000.00	NJ	2026-10-15 11:36:51.999135+05:30	\N	\N
658	Zzz05	gAAAAABq0G18j5LrdOiSCQGZkDYvOxLNz26RDqR175wWsqWxdjmkEeQlcgegX9u9fliSO4Ess3CQFOISHsK0RDJtrbbc3jyQiQ==	\N	3000.00	Miami	2026-10-15 11:36:52.014819+05:30	\N	\N
659	Xxx9	gAAAAABq0G18RSZsUpiweh3tqllxqCEITbPgMApPDpBYskIVtFVt8wwBZkbXST0Kt6XRyj9d4qn5iniR7S2WKF_D-OgVNLZPAQ==	\N	3000.00	Miami	2026-10-15 11:36:52.029548+05:30	\N	\N
660	Xxx7	gAAAAABq0G18p-MaO1vNF2Kk7I2BunaAuPyD1IoDxdx5O250H-8pz82hDfdjh14QpaOhsQZP6a2gC2iKjNoJnYQmxNniw86Bew==	\N	\N	\N	2026-10-15 11:36:52.043888+05:30	\N	\N
661	Xxx11	gAAAAABq0G18rtKPUZFazLfOnODlG9xCpLRZui7We2v_jJPOIw4kr1u7A7Mc7F8b0OLxbGSbEHyKus8ZYe4Kl5MsStOrIHCtvQ==	\N	2500.00	Rochester	2026-10-15 11:36:52.058344+05:30	\N	\N
662	Xxx5	gAAAAABq0G18Hj6oA6GuUU8W5WBk3u6VqTaL1W5uAvIm7IeyloUTwngNJ38SfQZW_HyMQTh9K2L2yn0XMxiqi95dPP5L6fdMIA==	\N	4000.00	Tampa	2026-10-15 11:36:52.072333+05:30	\N	\N
663	Tn315	gAAAAABq0G18JFvEFDco9k1kyk72q_q1HwaeTXRxKzkd66sLQJkOH9gTDzUiocSy_KJRqncgCH1ULbe7gUzlYgPUS48aWyBCBA==	\N	7000.00	NJ	2026-10-15 11:36:52.086095+05:30	\N	\N
664	Tn319	gAAAAABq0G18bevaxfU2YCtWjCbEXF0g5XvKJk_IhKTTv8up9XXLlfZdhtOocXScUsHVMSlDun7YR_6MXF7sv7JVymzTmRQmbw==	\N	10000.00	NJ	2026-10-15 11:36:52.104144+05:30	\N	\N
665	Fsu132	gAAAAABq0G18ll8ykfoMgxcFW2SGnO9L3sB0JY2GntJzr_IVrVaDU260kfbKHUVInqmbAhzHum4ThoAahOoc4RKi9QT-2SZFug==	\N	7000.00	NJ	2026-10-15 11:36:52.118383+05:30	\N	\N
666	Crt127	gAAAAABq0G18f40bJotiw1H6U-WQQ_1y-bU_mmQAvYv43kBtq-8WFtmQ4GnBJ8jd1vlpXheZUNh9kemL5p3MOIYE054euYFMEg==	\N	5000.00	NJ	2026-10-15 11:36:52.133602+05:30	\N	\N
667	Crt126	gAAAAABq0G18_O6uBCRlqRwRQ9eQIjvEx4GctG3LyK_KVxMx2v-gkxLqWRvGTu9Zc8x8DN_76rhAivPBEKGRADWx7wWKDNtokQ==	\N	5000.00	NYC	2026-10-15 11:36:52.147934+05:30	\N	\N
668	Cub73475	gAAAAABq0G18y2-C_bW4-fZOCNbD6HHQUl8VblDHI9Fl9fyAUL-oA9FZYriRTnZht33BIy6xlXSf_VZ91gl6qfd_LyrSWV8YBw==	\N	2500.00	NJ	2026-10-15 11:36:52.163045+05:30	\N	\N
669	Ws7001	gAAAAABq0G18m8kh0-v1RCLhBv4lR1Afr8gHaGvNgGS_629PKEaNdyYrTmp7NEwlQNp4ev1Xf8DeUnRVQtk7oPj1qQc7Kb_F4g==	\N	5000.00	NJ	2026-10-15 11:36:52.177057+05:30	\N	\N
670	Ws790	gAAAAABq0G188g02yaLE3jGKMwIR2p7ntaIvWiKVLkGQim5gT65jjQ0G-AwVRJ78pJhU2Dn6i0-cZY5BMw3q-LpbNk09VM5YaA==	\N	5000.00	NJ	2026-10-15 11:36:52.195255+05:30	\N	\N
416	317	gAAAAABqz2iQ9JkGC5kS0qYH07czOBM7RPs9ZeRHvdQRYrBBF0X9-2u3nbWbrvpm14I5H2lfvlv0RrjOkDlnEBqjzRoYkDmW_A==	\N	15000.00	NJ	2026-10-14 17:03:36.604976+05:30	\N	\N
671	318	gAAAAABq0G18gQuvO2AFS__k96nYNj1yzQAt4FJzYDcFUrMr-XBqpjJpnIUT15EM28cwtFBXj32fOLrMqABwb5yc8w7hOMZyNA==	\N	15000.00	NJ	2026-10-15 11:36:52.236756+05:30	\N	\N
672	Tommymastrodonato	gAAAAABq0G18FuAlE2erpyxDO95x_tb0gZra2-4hmmSpGj2auAEIY_YjOOlGs3rlXkwLbkQqoRg1pldH4J_kVg3EtySNEVy7_g==	\N	3000.00	Fort Lauderdale	2026-10-15 11:36:52.25201+05:30	\N	\N
673	Ox321	gAAAAABq0G18OGklBbaTLC_ATSqrRORWB0iuWXFZg6bAMQe9J3l52tzQ4mHPh1QtqwEBGI6QvEYQOoKSRIHvTFHNqKlI8QW4Yg==	\N	\N	Boston	2026-10-15 11:36:52.267424+05:30	\N	\N
674	Dce106	gAAAAABq0G18b10tzVyosQzovmCrrrkWc02HWKoDQXT2Vkhn3b2FVJHddJ6pnDY7dn6AO_ol_pruBBpYytuMY99rfADdrPma_A==	15000.00	10000.00	Dallas	2026-10-15 11:36:52.284871+05:30	\N	\N
675	Em0500	gAAAAABq0G18oYfq8WbUdaoo_WFX-gG5i_QMqh2LsE3q5JdT9bH7xVooQomJlAkOImUeo5KTe22Tadml3kHX2xMFyohzGpSOVg==	10000.00	10000.00	Dallas	2026-10-15 11:36:52.299813+05:30	\N	\N
676	Hi037	gAAAAABq0G18aXQTEzuW9mtjOJA9XQRgz4GUN-l5Y-NdisX1SH5R_llZpO3XQ-EHyN027aNeUwvd52ZwjId1LYz_J46uHcs2BQ==	3000.00	3000.00	Dallas	2026-10-15 11:36:52.367665+05:30	\N	\N
677	Cam208	gAAAAABq0G18OK4uR2kypXTy-SMwruoGDA9Vc7yQLmcRKdChHK5J4JNlJRoU50iEsdyLnYHNobAdeeeYbd8MAykeov8s3moQKA==	2000.00	2000.00	Dallas	2026-10-15 11:36:52.38602+05:30	\N	\N
678	Don189	gAAAAABq0G18I1ZIlEQjI3PFEcIxoae717HjdFBK8HR4kAlt1g64AZYc3svvd3ejfKcvTiqIBg1yRxPcqUp8gYC89exncZdBMw==	20000.00	20000.00	Dallas	2026-10-15 11:36:52.400517+05:30	\N	\N
679	Wtx126	gAAAAABq0G18aZwqDdUx47NwSEJpt7uhmqm1IZTaFm6hG-qZCYg958KioGehSHLSeakL6IGqLFIFquCPVpqNYbYM8Fscu37FJQ==	70000.00	\N	Odessa	2026-10-15 11:36:52.416501+05:30	\N	Infinite
680	lnk705	gAAAAABq0G185CufBl6VMfStZrBBthbsQLrcBi3mu258OSfIeps5HsE75G5CSSzOsAIONGOiMGQr9zzwbfccvttFL0aU_R4j4A==	2000.00	2000.00	Charlotte	2026-10-15 11:36:52.434973+05:30	\N	\N
681	Ppe158	gAAAAABq0G18M--ykeJsulmVsRBQBRx5WVg9n0NsaDikE9qItTZNVV9afw83XLJXQMrZnZVEHlYTsB-E3UCxu24hxwidT8E89Q==	10000.00	\N	Sacremento	2026-10-15 11:36:52.44982+05:30	\N	\N
682	Ppe128	gAAAAABq0G18BNHGZZo0do3-OWCnYjpq4nTOTEQnN__dEzHQ-racIl6Gz_K1gpn9Y14qBC_7Ybejc2Yd-0g3dnn9bR6kWuaF_A==	10000.00	\N	Sacramento	2026-10-15 11:36:52.468015+05:30	\N	\N
683	Blk412	gAAAAABq0G18h3OuTf_bvVdQoPlxRyHNtpozFGrxCU-YEYBaUHtYqs-v88P2yx6UiXyjzkFo6fUhkMmn54PjEXuHZlV28_aFCQ==	10000.00	\N	Sacramento	2026-10-15 11:36:52.486114+05:30	\N	\N
684	RT30001X	gAAAAABq0G18cOPyk4OCq4i2sbs5nsf2YIldxBz38FGj_yqawHD669No2lEu2FpAFPmMYjJdqppnnJVgYu_AIACaxcavj-Lhdw==	10000.00	\N	Sacramento	2026-10-15 11:36:52.501622+05:30	\N	\N
685	LV8978	gAAAAABq0G18jDUz3lgTQS9j-2HeRNnbduAb6KOHQLhpiPFZP-hkTwgt95YkVMogxQmFzLgRnZJA0lbYMcS9ZaUU-n_MLVaFtw==	10000.00	\N	Dallas	2026-10-15 11:36:52.516801+05:30	\N	\N
686	Live108	gAAAAABq0G18Z_ZKsPYdFKed8pZ1EyYdkn_ckk1N1x_oT51jFJEYAMOuzUoBTXpn20B-CdH7bHBxP8y_cPdHbjcMQLSNSVbanw==	10000.00	\N	Dallas	2026-10-15 11:36:52.534601+05:30	\N	\N
687	J740	gAAAAABq0G18iF_3WexhpfQtH9Kj4L-eW1gyCqg96sxTEtbwAQkM-u5Eay8cv4WgQQtnTcFFwW5S6Tw0-a5BIDkdrn_Q-Gs1yw==	10000.00	\N	\N	2026-10-15 11:36:52.549287+05:30	\N	\N
688	J753	gAAAAABq0G18ZZzXIrENw-D_s8uunfjUUJjnXSf1PNeBhel-2YbkR2y35_Eyc7Hx7S3zc5OGqREoRpDKEKVJexTvqGS-A9EtsA==	10000.00	\N	\N	2026-10-15 11:36:52.566515+05:30	\N	\N
689	Ch1002	gAAAAABq0G18-xfyal_XcCzlmNGvYZJczM-DsxIAlHQQSXH-D-83L-52ezIpEE7Mym16jAWZH5m1nyFS56BZF7nNdnWfv7NJ8A==	2000.00	3000.00	Dallas	2026-10-15 11:36:52.58659+05:30	\N	\N
690	Cr305	gAAAAABq0G18MJGiEBClNVEhAtbpuLPWEXkleaz27M1ezvt8jDZbOKY3QArF31JZIypQf9bAC4caq_OPiPvU4q7mGSbiQpv9nQ==	2000.00	3000.00	Dallas	2026-10-15 11:36:52.60461+05:30	\N	\N
691	Sna185	gAAAAABq0G18wF8zOyR9B3Q-Vxv9zxcOYYag_WGjOIC3N-UAcy0eI_Y-ODOI0Jybi6CzZIazRXZS5tsesqRMQQxkCRFp3TNwsw==	1000.00	2000.00	Dallas	2026-10-15 11:36:52.621875+05:30	\N	\N
692	Qxbcb304	gAAAAABq0G18BBEODHa-axQ1eG7nDPD-y3iIa_Z4GY1yxwIkIneX1ZGNl6ixy8p3Kwc5jV_x9Glkg0IZCNVoPpy76Uom6EI43w==	15000.00	\N	LA	2026-10-15 11:36:52.642025+05:30	\N	Infinite
693	St968	gAAAAABq0G18oL1G57xqJCsUeJh14v_iEu8CxZrmdtHl14AbzrHdyRD0uUlM4qArgolig3cCI59InfGpUMX2bJdgQrEWI6zekw==	25000.00	\N	Dallas	2026-10-15 11:36:52.657084+05:30	\N	\N
694	Blk105	gAAAAABq0G18oDHrKDo8qpqYGVLGCy6ytNWYdRO6B0Kxiy9EYPjnslRDIkDlgkPiv-ZBRR5VB4tNAe4RAOhYlJzqHR98joMVfw==	6000.00	3000.00	NYC	2026-10-15 11:36:52.672738+05:30	\N	\N
695	Ceo1275	gAAAAABq0HSQ_Y6F65Lu7Kal2TJpNnd9Vn0ZZvQey9PVRfvgHrv_uPWn3Hh3eKRlnl0I-15ITPdMAtHsbnOJkkHQXT8ZJ6rSPw==	1500.00	2000.00	NYC	2026-10-15 12:07:04.491111+05:30	\N	\N
696	Nai	gAAAAABq0HSQUSWgJQmqHCjzVrf1uSWMliQw3mKKSERyZzsH-MVRUXE2752JVA1ijyABr1v3PKKOWykRX5cZLNzlQwch4bKpGg==	1500.00	2000.00	NYC	2026-10-15 12:07:04.54504+05:30	\N	\N
697	Whale227	gAAAAABq0HSQZqjg7CZCLzApo1HG8usqlGdGoDvxaoc32e9ZdWZAkShK1Mksh5KXUVegrhyOM08nza94VaTfB1mofA2YrFY1kw==	2500.00	1000.00	NYC	2026-10-15 12:07:04.576248+05:30	\N	\N
698	Jb417	gAAAAABq0HSQzwxEX2foWGMa1VAZH8xFAJzyF2z7JInSMmDPaNFHqgXBGA0KnE7dtdWL5aVy0-3fw0s7FFgJERX_NP1IO085Xw==	2000.00	1000.00	NYC	2026-10-15 12:07:04.600207+05:30	\N	\N
699	Bb40708	gAAAAABq0HSQRjCq_lstG1QkYhbIeHRp0x_-V_AoonKTlryXhobKfZMUnCU9Bpce-9IWPDqac0Op4Tetfdk-utNt0GLeATavng==	3000.00	2000.00	NYC	2026-10-15 12:07:04.624789+05:30	\N	\N
700	JL4	gAAAAABq0HSQrZ7evjYFwCwhbcR1A4MN0Piew9-dXNG6hL4DoYWLejfAAh49P20qH3vy7IyiStHwGitCcFE32ZI88eUUcq_MrA==	\N	\N	STL	2026-10-15 12:07:04.652553+05:30	\N	\N
701	Tab110	gAAAAABq0HSQdFIB8LdVLnd4_O2AUvYkG7KyVOoxtXRJ7_G6cpQdzod8oaO0dgQbC3lEz9oP9kkMZBix-I37s5f3WgfcmQKvEg==	\N	\N	NYC	2026-10-15 12:07:04.681157+05:30	\N	\N
702	Guap68501	gAAAAABq0HSQgyldIYuO5CBXH0Kn2CBjhSFInJqvcJtPjGZJlnuyJTjVHqqTdEZMROxJfeq-pg_Aw-dRj5z-Uy3KaprYaVu0HA==	\N	\N	NYC	2026-10-15 12:07:04.70341+05:30	\N	\N
703	Xce719	gAAAAABq0HSQQCEOOkxBCmeHPDWwFfvwV1en_hJfZWDnX_Cw9yYDCGMXC-G_sZRuk3yal2ug-YIebrLoRL1DtimaSyB26qqn2A==	\N	5000.00	NYC	2026-10-15 12:07:04.72829+05:30	\N	\N
704	Mz21	gAAAAABq0HSQMZDWQ-MyO_p6owH2GKaZGMh_NRTdcNL_rJWek6oeIyzp5Ka_qDvnmy0c379lHfaPQ5jb42RndQ--581tTaUvfg==	\N	2000.00	Kansas City	2026-10-15 12:07:04.764159+05:30	\N	\N
705	Evan2549	gAAAAABq0HSQsKgtyndQqbTwJG4uZwW-PrIYhxGQck_QcmAs0NXFGTYm9fhPauplVNHjU23s1PL7nPkpX1ab1WCxhqQbDtKe5A==	\N	\N	North Dakota	2026-10-15 12:07:04.791791+05:30	\N	\N
706	Leov001	gAAAAABq0HSQ5KAK2Rks2yfK4SLlsgbXapOSilHqxfBOZf-9S-3zoV_LWATl08gnxblaVGnrn2J_KAglkt8i-unm48c9Q_xVaw==	\N	2000.00	NYC	2026-10-15 12:07:04.830372+05:30	\N	\N
707	Zooger6	gAAAAABq0HSQObiEtUQ759LHtGHtKoMybZo5uszFePTgzdFm7lqG-RwmXXh1hfQcO9WkYC7tS_F1717-QG_tUk6xGbp9U-coJA==	\N	2000.00	Kansas City	2026-10-15 12:07:04.862236+05:30	\N	\N
708	Stags123	gAAAAABq0HSQWgRC-NO3J40gIzc276U28wD1lxKTOhz9Rj9IXA-Q5bJSwkpCvuxJtgZx69qM7bpThOcftMWBTFB2ghGoklKBkQ==	\N	\N	NYC	2026-10-15 12:07:04.894709+05:30	\N	\N
709	Ct501	gAAAAABq0HSQsbXOZCPF_VZl6tVVg4xlROPv_w1yq5-VIodHpFlBdg3p4yHrIYXUh3CPS009csjoLilnfGCpEduYgif-dw71gw==	\N	5000.00	NYC	2026-10-15 12:07:04.916529+05:30	\N	\N
710	Pp100	gAAAAABq0HSQ6rngRWb_6s0XLKGteqDMpydRdL2qnKIS1uVT2L2_o60xo65Nof2UkGkHNXGhcC1w0jjNN0uufD1DcMdxLgvs0Q==	\N	\N	Dallas	2026-10-15 12:07:04.935673+05:30	\N	\N
711	Pp105	gAAAAABq0HSQIUuWIF-4j5_LI5t1hM-BD7VtVl-kkEKGPZQfQkEavRJyLk_CRFhtiwSogdyFle8S6NtqtHd_EM0pclPX2wO_Pw==	\N	\N	Dallas	2026-10-15 12:07:04.958257+05:30	\N	\N
712	Blk118	gAAAAABq0HSQ52chUbCPLTN8avQLarl49vJ9vKsBEFRMFgqfcfzN-cYFq-fmf04iYTMWw4YW782o9HEW8hQE7hy-0Z1UuMokkg==	\N	\N	Dallas	2026-10-15 12:07:04.981001+05:30	\N	\N
713	Bxt355	gAAAAABq0HSRGiNRjonYcExkBATGFMg9WgPGKa00JAh0dFuDQZOWDnAqgLapeTyuMwS8HEHNqVj6seopIA0q4wSmdTl10X6zhg==	\N	\N	Dallas	2026-10-15 12:07:05.00332+05:30	\N	\N
714	Sdr232	gAAAAABq0HSR0s2NQh9MWew5TDvAdpMLg8kt9P5LgNj-vN19mNLBqM_sHTwYfBEoCOMKulKKyHJXJdsq9j6OdmIFDcIBtmPEyg==	\N	\N	NYC	2026-10-15 12:07:05.022277+05:30	\N	\N
715	Eddierev1	gAAAAABq0HSR8ENUu8cQwEIylKz1PWM4R4pjtxWPBfjxQZ2jJeFjIR-iZsh--i_Y1AccHmcLiWj-WkU1tj5DqQOX8j4GfK47tw==	\N	\N	Minnesota	2026-10-15 12:07:05.037047+05:30	\N	\N
716	60401	gAAAAABq0HSR2mZKxLk8blgwc40DhGobV4ZWFJzI5XPbKcxPpVmd2yzCN2psTA1e8YG3AEL4wjXjI0bmBSeWkmv6NEpnMsbnUA==	\N	\N	Minnesota	2026-10-15 12:07:05.054348+05:30	\N	\N
717	Blue40014	gAAAAABq0HSRqeKcaGn4eQu5svR3Lt2qcUW-FePaYbW-izm15mmqTwZJggCRhY8wUByMMpyKdL24Mhi53Aqg2qVe1h2EN48rIg==	\N	\N	NYC	2026-10-15 12:07:05.073514+05:30	\N	\N
718	LNK93268	gAAAAABq0HSRAVcAdvGzZuOY2taO_ghciKIvvxjtft9D8sfYDDK2_RAYm3q0NzOHWavM6d_V1Ptm4Bg0JLxuFMhS7Mb7BIA8_w==	\N	\N	Minnesota	2026-10-15 12:07:05.090462+05:30	\N	\N
719	Lcj3190	gAAAAABq0HSRysDzvLipHAf8XoQMKlk_qOKbxU1PoBjbJ1px_fy7XRvq5wCalzpKeHBU8BX9DsIM4fpuh4HewENAhRerrBQ7wQ==	5000.00	\N	Dallas	2026-10-15 12:07:05.108413+05:30	\N	10k line now 2k/ bet
720	JD101X	gAAAAABq0HSRZk8ikIuWPXflJM4w_n0pY7HJhh5jVth0VfXzJn3yyH0gw6SFrk3Fbxc3zbdiMp09pT_ZOhxymjtbewQuchsgUw==	10000.00	10000.00	Dallas	2026-10-15 12:07:05.123376+05:30	\N	\N
721	M4083	gAAAAABq0HSRLXMwXiRamy6iLUqw431_OOiLw7aJLbyxm3ZzUUVSXn2V8ZjLW8lmRqTkGPo8qGctPZ7-oRPDabgHQwIN9pVu4Q==	2000.00	4000.00	Dallas	2026-10-15 12:07:05.139339+05:30	\N	\N
722	Mavs155	gAAAAABq0HSRHHTGd_N6g7WTUgtp4H4LRsPn5XYDpO9bSRkZ0EEBJ_zNQwc6r17XproehoQxH3yIU44Kfw17uPsvAR9KrOo7_w==	5000.00	2000.00	Dallas	2026-10-15 12:07:05.156538+05:30	\N	\N
723	Green4	gAAAAABq0HSRBGVLZkeQd9_eTutNKEUPd2-LpqiaylDC-0_6oZYI8TVJZl6Le_bz8Gfk6_rcdK9H1ktJFHsppeEnn7LbZo2MPg==	5000.00	10000.00	Dallas	2026-10-15 12:07:05.173759+05:30	\N	\N
724	51101	gAAAAABq0HSR-S-2zocuR_9Ce5p7eAJ9elOSqrvLEa4zZg8AM9Tu_jOTe2C1JeKxqus37fIw73UJnmSvSVsMYqJoMgln7qO6hw==	3000.00	2000.00	Dallas	2026-10-15 12:07:05.192207+05:30	\N	\N
725	Scr59108	gAAAAABq0HSR1lT_lalvsUvLts4n-ck1px90lORnWnAIZbYQA-wMTNI7zgXxl5nEgottDmBq8aVC-hx8Kf-oxmgzY3YWA7UBZA==	3000.00	3000.00	Dallas	2026-10-15 12:07:05.211036+05:30	\N	\N
726	Kb339	gAAAAABq0HSRY-LgfvgKkN110FfyVkpZ0bRl0VLvXF7TM24vPFb8l8pUXjJCQu04MmPDB3uvajDwHH4rkb0e1-3hgJUM8_a_Qw==	100000.00	20000.00	South Dakota	2026-10-15 12:07:05.226594+05:30	\N	\N
727	Kb647	gAAAAABq0HSRTlc55UUmKq5wZkTOfR4ppS6oVqets9QdkY5_KiWofaFMTxzAKeQbFHznrb128-__Hz0zO70IsJvc26k9wFp9Ig==	20000.00	10000.00	South Dakota	2026-10-15 12:07:05.242063+05:30	\N	\N
728	205354	gAAAAABq0HSRK9NJJuiZHmfV2PcoXAXfLqCZQTD0KrpbE7Q8QwUX959s-EwlNqtxrp5dSf9CTOzl8pQSOVIZSvCuoE5czqNtYg==	5000.00	2000.00	Cinci	2026-10-15 12:07:05.256656+05:30	\N	\N
729	Agt100	gAAAAABq0HSRpxEMXTUqnxkYmWjJBuDfnBA3vm5nP3lEoY-k3OCgzoxyt5KcoPCweKYofFTecwapq0v_FxwbXqJnsU_pNVe0DQ==	50000.00	20000.00	Cinci	2026-10-15 12:07:05.271366+05:30	\N	\N
730	Fsu68	gAAAAABq0HSRUG3E33N_s923ieJ3M3Z1iZYFk1OIcAOA0FuIiBtwlGnFaEc-CQUGkDX9uNiA_lu6VFPkrIa03BD5n4BnbFuaAA==	10000.00	20000.00	NYC	2026-10-15 12:07:05.283702+05:30	\N	\N
731	C2099	gAAAAABq0HSRSd2M9yKaAD4W1gbxo0hPI8x-aoKQ4xFyl_Mr-qDyTN-CpPxpIBN1OXLtqmGByjI6_Q1YF31mbl35qVNPogoGAg==	3000.00	3000.00	Hoboken NJ	2026-10-15 12:07:05.298518+05:30	\N	\N
736	Bd2159	gAAAAABq0HSRUddnGAj-XxBoPiMwwLUsNlQhbxesL2Gvhqp6lqmERk8MHoDUjWvm3vYLhXheqqKBNGjVjvJYz3fgWx-3_L8qjA==	8000.00	20000.00	Houston	2026-10-15 12:07:05.376983+05:30	\N	\N
741	1005	gAAAAABq0HSRm-eW4CNjKm9a4bQsgmV2FTe4acqg2o03VNsCEsAR_NqsSZr_gCDdmO5lYPYCp94tdfv5vMFB1lm2klgbvu2urg==	10000.00	\N	Dallas	2026-10-15 12:07:05.457563+05:30	\N	\N
746	Soy338	gAAAAABq0HSRe2FYJ7RIXEaNz1cagz-bia5Vgv7JxseIKpbc76Pl8lRlXI6kQB6_hziQ56SutjfFomVhVyhKjLaj8fy0Cgtc4g==	2000.00	2000.00	Dallas	2026-10-15 12:07:05.532898+05:30	\N	\N
751	Bnn39892	gAAAAABq0HSRvNDZyOaLntrrA7V3lGCs4vR1LicoiYA-nQw9EGKY6Y-8_PiL27ahEwf-V5m4fR9-YZXKstZaUUmi20TXuW4BLw==	4000.00	5000.00	NYC	2026-10-15 12:07:05.622971+05:30	\N	\N
732	rx9581	gAAAAABq0HSRoNfivuE7VawxoCVbgcyshKSSHxOK0mH2-Vmr9eD-xdbr615KMZKlZg6DrJoJYqSz2a2-db6YhfTwYhU7-Os6OA==	5000.00	3000.00	Lafayette	2026-10-15 12:07:05.313318+05:30	\N	\N
737	Wtl1545	gAAAAABq0HSRPpK__QpdJokqhDbsfk39N2xjDjOUQ-8r9dcFoOtsMN2foSHEMkmAlr8K1MmR0a4Y3686V_MNHxEEht2EkuCiXw==	3000.00	5000.00	Houston	2026-10-15 12:07:05.392516+05:30	\N	\N
742	Ly8	gAAAAABq0HSREPVFi0k9ZOTISajVyNyUaEoVLC6n4dL-osLMZAZfgyWCvxJNX2QltT_4QgyGtgtnpBvO9hgCw73ZSBJ8Wtz4tg==	20000.00	\N	Dallas	2026-10-15 12:07:05.473128+05:30	\N	\N
747	Soy426	gAAAAABq0HSRQ5lrJGPA_RDwWIQc500P8gSbk7pfsoUkG_4hiDS8FvsjpSsNdBbgJRO3J6jXUTMzFRbzh5meXGfaWY33INZC3A==	10000.00	\N	Dallas	2026-10-15 12:07:05.546753+05:30	\N	1pk
733	49008	gAAAAABq0HSRHWFFJ_vYnBxnAkoK4ZcJZezWdF21Cjbk_PiWNFnLNuZ9tNS_J_ol702ZIiW7FHnstqMY5tDIUzNR1EkhQq0N3w==	10000.00	\N	Detroit	2026-10-15 12:07:05.331162+05:30	\N	\N
738	Soy323	gAAAAABq0HSRsjY552_MZ2vOfNu6tmTDyskvOrtJG68imvMeK0oGkchJbjozGYlD-VsGZMIN1okZ4W8PMyU1pV-0yuCC5km2OQ==	5000.00	3000.00	Oklahoma City	2026-10-15 12:07:05.408343+05:30	\N	\N
743	Aa408	gAAAAABq0HSRJuKT-cKRuUOep51O7jJXP2CnGGlps4nFDrb8plIlb3I6FYlFtcWGlT6hNu0Vmay1IjccAv-x2xXgbegCuQFHUA==	2000.00	\N	Dallas	2026-10-15 12:07:05.488063+05:30	\N	\N
748	Soy450	gAAAAABq0HSR4HkieSNU-BNDj9Rs8Wic9CU1fvPewdguiUe9NjQMfN2r0g-y2LlWswDd4iSUR4pusnbAvrFgi5OtQ9iiW2ScDQ==	10000.00	10000.00	Dallas	2026-10-15 12:07:05.571377+05:30	\N	\N
734	S6849	gAAAAABq0HSR3r8hZlKQ0HPCOuB0VtmOYXxGo6fSXKgT19gAwgQVn3fukhEzDojBHhq38EJe5_enkPDtP_2AzTyOlrH03BBrsA==	75000.00	\N	Detroit	2026-10-15 12:07:05.346737+05:30	\N	\N
739	Soy327	gAAAAABq0HSRdc7OO8EWVX7iUPw47z1uLhNXwAWGoTQGFL3CaspSWkCU9zuHdR5FdWSp-s5vV8ti5PMhutf2xcfJmdWKNeL7sw==	1000.00	2000.00	Dallas	2026-10-15 12:07:05.426789+05:30	\N	\N
744	Ou218	gAAAAABq0HSRkgjWKdCl5jZceZMn5IbQR_dRlCGWnbDZAsO_3w1_5atBJYQIVrsLBsBBWouxZ3b-uSHQJ9XSeKnYuhGBwXvkuw==	20000.00	\N	Dallas	2026-10-15 12:07:05.503405+05:30	\N	\N
749	Amn178	gAAAAABq0HSRAZyReDWXnv_Z5dgVKurchZZRtV9Rg9YW6wFGltVGLVsfag7NCQzam9ApRfCbw_qn0SPvegrx3fZIsNHRUq8oeA==	5000.00	5000.00	Houston	2026-10-15 12:07:05.592473+05:30	\N	\N
735	Su183	gAAAAABq0HSR2UFbtypNVm_uoUBvzgS4fL0dz_lo6UTFerwLa1JK9p2d5_UEy12V-BBmq_riiPk-lkbmfRBd3eRmqOc0JRL8jg==	20000.00	\N	Detroit	2026-10-15 12:07:05.361541+05:30	\N	\N
740	1004	gAAAAABq0HSR31i9r2ypciojTvtwVqmxPMs0ZkwSmNfDciSor5fWZ13cv8uB5ZYrBT48xn3Jkfnm4TeLoOEj02zsk-NUroEnIg==	20000.00	\N	Dallas	2026-10-15 12:07:05.442735+05:30	\N	\N
745	Dal0056	gAAAAABq0HSRNbigYDkz-YumHAr4VRSIGMLiC1vIOuqgOkMz-SCo6w_IuPIVtX2aTk5H6cxP3WE90EvJH58tTKBzRJ11-qi6Jw==	20000.00	\N	Dallas	2026-10-15 12:07:05.51764+05:30	\N	\N
750	Amn203	gAAAAABq0HSRBe275C06WyraqKk_U5gN1b5JijApGgsyQXCrHAZ4_jdgq1KubVktMQWQ6BUt3wV98W_Z9x50IgoOXdBjGtQL-w==	5000.00	5000.00	NYC	2026-10-15 12:07:05.607475+05:30	\N	\N
752	Df9076	gAAAAABq0H75_2iescvZMFyVgWbqr6x-kddfysxeHrHFOcAAagCrZEusnL69kknwXiOKAGnp3vm9JCQGZz_cqZICZUCo0jvm5A==	500.00	\N	Dallas	2026-10-15 12:51:29.933397+05:30	\N	\N
753	Lvs121	gAAAAABq0H75YZfsxBAtWiXT43ITTgQre8elfrMoi9h4_7HoXrOnmXmwRA3HJYsuKgI5YKzLC7gbSuyky-TgXurxf0g4CNf7uA==	3000.00	5000.00	Dallas	2026-10-15 12:51:29.967402+05:30	\N	\N
754	N903	gAAAAABq0H75kRObLFuxvnF_YEw6Yz9W2oViP5HOphXeVVG5h6Cm9zzRhGUOiL5JVYauY0wcsqZHMKz-iTItTIFIaTjgNFcJrQ==	20000.00	\N	\N	2026-10-15 12:51:29.993809+05:30	\N	\N
755	Rzr365	gAAAAABq0H76SFf_Z3Aslllg51QHJZ0Mnv-TxL4Kw-zIsMfxEppO5q6u8sb31O89TXy-0AUdG3zlUvZKEQPDNksyggvXWtbnvw==	2500.00	\N	Houston	2026-10-15 12:51:30.034178+05:30	\N	\N
756	Ev356	gAAAAABq0H76EMAOdsbqxocCoFogAeUVh0qBJF58P1Mn-lgLoRtDt-2YVzU-RdqkeErdcfxBPzYMmzzSb6-v0_JFd8aXX0Ws4A==	2000.00	\N	Houston	2026-10-15 12:51:30.071514+05:30	\N	\N
757	Pja105	gAAAAABq0H76rcBiwT3bFZGZfEDfemuBMtOBGaKPI7W-6TeBgPEKHqUD3tfToJOzhMMrdBrEEH7wLhJ0bIGFSMRunYcuT0G2YQ==	20000.00	\N	Houston	2026-10-15 12:51:30.100667+05:30	\N	\N
758	Pja109	gAAAAABq0H76QIv4Fs0KkG-LLqirgPJ-PktoVA-v-FB-iMElzpZt0wEr_-eTy97tliNh6YOburdhSYRqR3HfCnNZteolylxYfw==	20000.00	\N	Houston	2026-10-15 12:51:30.127235+05:30	\N	\N
759	Texan1001	gAAAAABq0H76PmRTw90VRKJ2zNT3qAj-SPsS7-TnyJVYxhsYMcJR7BfVJwL0GfZtFtm45ueN4JhZv7pmrWT1StVlWSrRwM2NJg==	3000.00	5000.00	Houston	2026-10-15 12:51:30.151267+05:30	\N	\N
760	Pex703	gAAAAABq0H76mC2Z76w4TQAFhsG1KkDfQ0e3P-the3SQ_pDVPcO3il5wOETc8Fg2wRs7U-tYjO6ZVY9RyXRgcgGuT94hlmTjVw==	5000.00	3000.00	Houston	2026-10-15 12:51:30.183909+05:30	\N	\N
761	David224	gAAAAABq0H76xCz6RAX6-DgDs2zrD8P3dzePZpt05T_vigd4PrRyoaoFwI8RKZhGR7J8EvaxuVtXLGtqm7bq-cwxgkOm9-1uKA==	10000.00	5000.00	Houston	2026-10-15 12:51:30.208891+05:30	\N	\N
762	S715	gAAAAABq0H763NGAXkjb5nttJWnm50KPFsiiXPSObyehGMiuYTWI2LZFH0OfmL4lAuiMJz6-cB2K69609I2QCbcWWG1QnwfAgQ==	30000.00	10000.00	Houston	2026-10-15 12:51:30.233923+05:30	\N	\N
763	Sy166	gAAAAABq0H76fCXPD-GFtN5NDT_9mcMizb9-BetCTLKB_enXL-jhz6xyEp2T7ynDIi81hn1GpcEJjK7F8jpgpViflWQfcTjZ8g==	5000.00	8000.00	Houston	2026-10-15 12:51:30.257517+05:30	\N	\N
764	4s802	gAAAAABq0H76ZxyWxfrL0e0-Gy_47aAVE26htfIX9ntK_H8nsXIoaXaM1smhLuXBY8Hy27ijOjO94wJkGXfSZkwyTNgxsgdopQ==	10000.00	\N	Houston	2026-10-15 12:51:30.284327+05:30	\N	\N
765	4s801	gAAAAABq0H76z_VwSZe8xFl3-QmDlN3U5RSa_fA5gAxAxnqaEDVceK2ATzTrZc85-axNEABeRfe-igVWL8NsPEGwEafav1yteg==	10000.00	5000.00	Houston	2026-10-15 12:51:30.306968+05:30	\N	\N
766	Bs114	gAAAAABq0H76C6ZHc_Qfe1dkrU_W7zmTwuD_q1vLZ45g39l118nbSoU3G_wYJ3brT_IX7JuUdwfDj4O4d8WnBeH73NHJ-jwUKQ==	20000.00	\N	\N	2026-10-15 12:51:30.330731+05:30	\N	\N
767	Bs115	gAAAAABq0H76IjLOHqaiQQE8VffRx5ps_nQjpNWfOh4EMEDSKZZrbHzSWTYFWktPL2vzPmg1PoHqPXYEIAcSpoxmHbHkWVF1lA==	20000.00	\N	\N	2026-10-15 12:51:30.352663+05:30	\N	\N
768	Cs2008	gAAAAABq0H76U0EJlLybrIYgA1hKb8xIoEeXakAs02JIGsl9I_3gIayUTxto_wYb3l4Ov0TJs9hyky-_LBwcInAJtvJ0p_5oqg==	10000.00	5000.00	Houston	2026-10-15 12:51:30.375431+05:30	\N	\N
769	Cs2001	gAAAAABq0H76KPxm_XLrjdc2eGqAzy0QBVYne3n_XkI8cefYQA70M6pIWkIC1MfYXuSrUWXW-Rqy0WNvHWO-doKcyXCXRd2iWw==	10000.00	5000.00	Houston	2026-10-15 12:51:30.398838+05:30	\N	\N
770	Rn12	gAAAAABq0H76wtLyQzOjktmvbr8jripJ-JYsvDGnoaglLbflrkNtjUOfllFQnkQzrcWoykkQN01ZYK75dSYx0GG4dHryLfwiRg==	10000.00	3000.00	Houston	2026-10-15 12:51:30.42368+05:30	\N	\N
771	Rn01	gAAAAABq0H760CrXd8F_AD6e5XvkKY1EmYO5JkteZYeymAVmjf_SnByjAIuD1fQpd0x4dueWN1QaX80wWHuIkdaFANaQiggxUQ==	10000.00	5000.00	Houston	2026-10-15 12:51:30.449012+05:30	\N	\N
772	ys716	gAAAAABq0H76Zh_sOn9BH1B9MJOGeqK_tis1GSXditnSA1NcZPun-WDSdTjTZbAjWBtbIuxfVzmXm7_F0nZCNoXjvtvXf-5YNg==	10000.00	5000.00	Houston	2026-10-15 12:51:30.470653+05:30	\N	\N
773	Lot214	gAAAAABq0H76oKYcwwm2BiJ-elf3W0cJMh_rp8kA0RhQYIRgLKhbrjqn3gxdgEnx67FmrzwQvFE_4tiRKcKtR9ifrZGSodeYoQ==	10000.00	3000.00	Houston	2026-10-15 12:51:30.499987+05:30	\N	\N
774	Lot215	gAAAAABq0H76r9mV_GZagKB2lcSU2OKb2XQstyjnkTlovaxmRgSPOPFx9F_8iEvVI84npHZyD9Em6s3ZXzQbTdpgtza9ylSUrA==	10000.00	3000.00	Houston	2026-10-15 12:51:30.533551+05:30	\N	\N
775	JL1049	gAAAAABq0H762eua7PTdmL0a4gOQqry1cQNC7nCB3SnC6XqPFgfeigxpRpORdoM6Rh89lDm1JdrnnzYerEooMHqPA9STtu_yyA==	20000.00	5000.00	Houston	2026-10-15 12:51:30.562099+05:30	\N	\N
776	Cm73147	gAAAAABq0H76TgWyRwmDvDldMaqotadF8vNrmlo9TcF4vuWZxiAt5tmFMcA32nLVD9znkCDCyzaQob-LMmLtSXt3BjAyPCANCA==	10000.00	5000.00	Houston	2026-10-15 12:51:30.589649+05:30	\N	\N
777	Bd35	gAAAAABq0H76S2bEr6wcn7x99fezx9OjLimDynO7ucQOBhd4iwiWLsrQw-LPXRB5LZHvBRcg3XsujSA261WQTCQRIZl4cKFOEQ==	10000.00	\N	Houston	2026-10-15 12:51:30.614334+05:30	\N	Unlimited
778	Jac5108	gAAAAABq0H76Ja_9ip_9Q0GYHREpCVZwjmIMgjLwde_zrIJw4RWzperaxHsVnQ4Ch6Uta24aQm4g9pWaULXLtknyo7iZR08h5A==	10000.00	\N	Houston	2026-10-15 12:51:30.646453+05:30	\N	\N
779	Jac7302	gAAAAABq0H76fmIGf0042Fc5BeXYthpmnKvDjroiBCK6672xUY-ryM-0oX8OZ3m_JXRBeKdiJ-NzRM-q09Vn-IavGE2F9_P0hw==	10000.00	5000.00	Houston	2026-10-15 12:51:30.677762+05:30	\N	\N
780	Jac7303	gAAAAABq0H76BhlH9l3XSmV9m1Pcyn7gdrEdeyU1t8LTJU7oxaQZYsgHvGEHjawD5ys6wuffkXAeG8XW6OCZOTdybQPE1Lki1A==	10000.00	5000.00	Houston	2026-10-15 12:51:30.704319+05:30	\N	\N
781	Jac4235	gAAAAABq0H76x0BdrGhk2OyOon4vMy8DC4QoeLS8-H0c6l8RjCRQ6KmTBA7ApGcdzVR3BcUXwxJ-EThujlfZIOIBhioQnvAuIg==	10000.00	5000.00	Port Neches	2026-10-15 12:51:30.72767+05:30	\N	\N
782	Lx435	gAAAAABq0H76C-oITGwzQinXxgcv206NsViXkYAxBB8zKOhEost_EIvzm5rhkiU4S7xybzhsIoli6dAnBUAeGjeHM9RCOnpnrA==	5000.00	10000.00	Houston	2026-10-15 12:51:30.74834+05:30	\N	\N
783	Lx436	gAAAAABq0H76J6tcJ40DNsObi8mhkvKaHUnnEumOvozkJxp_cs04NmC9Wv3HKtm3hDb75y7sKoSqdweqW6wxPASTpIOpY1vh6Q==	5000.00	\N	Dallas	2026-10-15 12:51:30.77158+05:30	\N	Dallas
784	Cwn503	gAAAAABq0H76_jZ_ZF1y6zhavlpJ5P3HUKY0mwOIv5bTE5GpB3SD2FTYDvySJS0cua0gmVuTMGR2NUdbLE-Xj-J-phLHlFvk0Q==	10000.00	5000.00	Houston	2026-10-15 12:51:30.793489+05:30	\N	\N
785	Ki501	gAAAAABq0H76XpxIOtpINTVA_UF6_4qpry_WK0mmeBi6ph0H2jTZByexQs9bwseFHq8OdS0YD0WFjaa_DdH-uBmAhK5welnuAQ==	10000.00	\N	Houston	2026-10-15 12:51:30.815278+05:30	\N	\N
786	Mj49	gAAAAABq0H76-myVmWp9TjpM4B8tIT3A4y7dM39CEozt-enPvWLheTtrV1UkUIBlbffQnaccE_MNkFqYNPgf2veg7RQHokPniQ==	20000.00	\N	Houston	2026-10-15 12:51:30.838537+05:30	\N	\N
787	Tu0007	gAAAAABq0H76o_qYfCYk2-_nzTR25yN8M_SSbCwSjxKzRbde8_2dy-GjrqDb1tWW-m7ZQ-ImmsKR1qBCA1YKCImEX_gxuE4YMQ==	20000.00	\N	Houston	2026-10-15 12:51:30.859904+05:30	\N	\N
788	Lgx502	gAAAAABq0H76-57-jdY4syp6nCOUpIX5vkCc_XozFeu2GsMEmZMjCPY597l9DEbi4lKCMKmR59ZRBjhaKWyS53mPLCeYf0knpQ==	5000.00	5000.00	Houston	2026-10-15 12:51:30.885016+05:30	\N	\N
789	Texan1013	gAAAAABq0H76zbU1QOoJVWpJoD5-81LIeUl1uuNSwiGcZy_8HF3cIIm7s2vMOD7ItyXKAS525IFdGDdx8ACU32Yv9silXhmMCQ==	10000.00	5000.00	Houston	2026-10-15 12:51:30.914209+05:30	\N	\N
790	Mpp376	gAAAAABq0H76Im37ubxfx0IOrE8DJwwANPuJ_JDMJVxZqWjYFUfeLjJdnGtUQWMopeUIWx6uP-Tc-trSRVTqHJwZipqmchQvxg==	2000.00	3000.00	Dallas	2026-10-15 12:51:30.946496+05:30	\N	\N
791	Mpp377	gAAAAABq0H76F3Y4gqZ74B1NtsSMkFCop97vBz-NE00UOKkRq1NUTqTtltAj9ZTLBaSMYCGdeZQG_v97flKZbp0nKlDPT337PA==	2000.00	3000.00	Houston	2026-10-15 12:51:30.968102+05:30	\N	\N
792	Bg1032	gAAAAABq0H76NygwYfsm3FoR_DNjgEE-pO45rryyHcWb74APvhwkqPjL3w5ojh6EVPXzlUfYj_c6RQsRxQ7QM74yqapGvimjoA==	4000.00	2000.00	Houston	2026-10-15 12:51:30.992496+05:30	\N	\N
793	Mw1849	gAAAAABq0H77QGrBte-2GGNu5UgqtgIkvkZQ1G4FtIxixiWiGaJ5N_KPQBOXTuRin9yO98_Qd-wsMQ1M4twK_TePNtvsjAImZQ==	5000.00	3000.00	Houston	2026-10-15 12:51:31.01749+05:30	\N	\N
794	Pr215	gAAAAABq0H77MzjZdJWsEEsl0ZZ2yo1uwujJVVe1iKFVoPj2cbX73sgutfhW7O8vhn_3xjvRv1chIH8YYZN5yjXY6alGwbbw2w==	3500.00	5000.00	Dallas	2026-10-15 12:51:31.035657+05:30	\N	\N
799	Uhrich792	gAAAAABq0H77qQSNSMp4ABbXYEpNWyFbf4JUIrw0itMi5UB-pZUWwMNSad_kfbgWm7C5hDK6EEeY6AD7pE0g7Bsz4fh5W3JZvA==	300.00	\N	Chicago	2026-10-15 12:51:31.132872+05:30	\N	\N
804	Dec100	gAAAAABq0H77kJfSUQgb5ELzAq0a0_QmBabSRUdAlWEU4_CUZ4n_vZiwIl6nJIY00zivOJDASTdPsFb7pqQfs4jGQQc1dJRmcg==	500.00	1000.00	Miami	2026-10-15 12:51:31.216376+05:30	\N	\N
809	R194	gAAAAABq0H77t5ZuPPsyp3Q3RekWchnRHMaco4lOvM2vXoTpNECjUZEQoBC0ijUNPs3ShMl-HqTRUOmAJBjE_SFA0iVijPvj8w==	1500.00	\N	Kansas City	2026-10-15 12:51:31.309813+05:30	\N	\N
814	Griddle20	gAAAAABq0H77CYODCu2PASYq7xqqng0L_zTufgHQ5emwhc7X1mA7Wf-IR6pryw7xAg9_n4Y4EbZEQB3VhHXeYZb6GH9oSc1utA==	1000.00	2000.00	Missouri	2026-10-15 12:51:31.403955+05:30	\N	\N
795	BL250	gAAAAABq0H771-YtuO5yj6K8N8edOM19VBMT9lrRL2g1gD3x7KxV7d-VWsvkYHFa5ekFzKjY79I-Ai0b6i8K1hGKFvLS6WiP_g==	500.00	2000.00	Nashville	2026-10-15 12:51:31.054704+05:30	\N	\N
800	R197	gAAAAABq0H777j-CsJqNkzk2uYKvsXBOXgLNRBWJpXbQRDNPhZzDMUYYOmAHJ6lBxt3bK_dSZkh4JVh3Dck_-1xLNIhaV_S1sg==	1500.00	\N	Chicago	2026-10-15 12:51:31.149061+05:30	\N	\N
805	Jaretm786	gAAAAABq0H77ftUsExLr15WHIr5INt1gg9W8X08_yGnNXtwsnsNmOgvglgagC0ai-MaB-8YNq-bpMFnypwmotkM4Rj0XLgmINA==	700.00	2.00	Miami	2026-10-15 12:51:31.235222+05:30	\N	\N
810	blacksh001	gAAAAABq0H77kDvSjgRLI8lq91mvUuBgAyvG1ORLsJi489rEC8rEJvaSlR4CuY64a3J6hckazUo5xsdB3XwO5WgUcMWz_-yYdA==	1000.00	\N	Kansas City	2026-10-15 12:51:31.328014+05:30	\N	\N
815	KL2049	gAAAAABq0H77TO-4TUPifWtW-_QBPgl3Cr45n4jrv6uWV7_In-a2xMTnpJXLgs9lcDIiAi4pPh3MH7xR_6R0Ll4a7AFYgjAaZQ==	3000.00	\N	\N	2026-10-15 12:51:31.421167+05:30	\N	\N
796	Pm132	gAAAAABq0H777V-KGOJQKOgURlLNuDdNJ7YYR5zsLcF_TP5psr0UtvkS7X-w2kvBiqxe0SOrLxnca--LsHwBy-Y28mUDVyXvnQ==	1000.00	2000.00	Nashville	2026-10-15 12:51:31.073242+05:30	\N	\N
801	Bsu88	gAAAAABq0H77M2PleisnyELqFmzQAqdWsf0hSbEI29tQf1-EYNXZeRw-dyDonGzixqUkhLFkeOrIukBk5SZzPnBEiFdu8qOSfQ==	2000.00	\N	Chicago	2026-10-15 12:51:31.164908+05:30	\N	\N
806	AA365114	gAAAAABq0H77_11s2euwPmblu1W9nzOsHdAoJt-z2oufYpk7o1_xWGicleqFfkiwEoq1UBGWfq2vAcXCOjUlclFTabsWHNWWrw==	500.00	2.00	Miami	2026-10-15 12:51:31.256088+05:30	\N	\N
811	Scp238	gAAAAABq0H77MRbCTslcOJI7T70McWF3lO8bbZfkWLlO6vZFb2JKL4AX2tocdb8RFcVZBUDELe8Kz7ra_DMSXg45VBtytmyYRw==	500.00	2500.00	Pitt	2026-10-15 12:51:31.34421+05:30	\N	\N
816	MIsta85903	gAAAAABq0H77mylj613I2ChExe_6Nq2yvOnoXO116fF9EYEw8BFyxTlE0JiN5xOWh_h3lr-U02idZB8D_KS0iXKMAQFFfV6G5A==	10000.00	3000.00	\N	2026-10-15 12:51:31.438707+05:30	\N	\N
797	X22	gAAAAABq0H77Gnx4pjpe5C9bIMGIzIW184F3gSoHttRiwU6S-Eq2tc8zlhuiUDjfQfeP2zGh5RdqcJVpl3A46z_eJqjOGr1Pww==	850.00	2000.00	Fairway, KS	2026-10-15 12:51:31.092556+05:30	\N	\N
802	Chaffee1	gAAAAABq0H77XnMOuyw2fkYFSr0Z0S0PI5n4RD_lICPEK3Qzf2LvfGLN6Gi5C_IyoH6urKqLkD7rcHFp3SPZlRX5ikG3sRp-3g==	3000.00	3000.00	New port	2026-10-15 12:51:31.180602+05:30	\N	\N
807	Blue226	gAAAAABq0H779ijxaQ2tTEiKD4hzmeGLQyDMgLf9VkgK-hkkmdsS9AX8wT0qwtjYPAvSVk3t45YLMAnf1V_nwcGQn0OBWOkc_Q==	500.00	1000.00	Houston	2026-10-15 12:51:31.274584+05:30	\N	\N
812	Le4483	gAAAAABq0H77sHixnLuxw3jITQ0aeA8TzrtAas1WkPetToPrlP3_7T0oYDNA2aW2lkSjIYvIDK-URHUcWggQVDlva7MeWNwesA==	3000.00	3000.00	Missouri	2026-10-15 12:51:31.367187+05:30	\N	\N
817	Le4484	gAAAAABq0H77PicGP-L27dR0q3BzKNLtIv9YzQq73saszkCI2R2oiBhtqGv5_LswbW6uJWtVVwTqK5b-995t6FNnSbzGDwwCzA==	3000.00	\N	LA	2026-10-15 12:51:31.456563+05:30	\N	\N
798	jnolen001	gAAAAABq0H77vqNT5Cc1oIbGf3bZzCXW93ADaFz8oZmM3MpshZlQpzaLrLQRnEVKqDVcoujo--ifVJMNNlY9y1a6uNSd27peOQ==	500.00	\N	Las Vegas	2026-10-15 12:51:31.113644+05:30	\N	\N
803	Le4485	gAAAAABq0H77PbFzplT7f74nODHwcf419JOzK9c7X394VoIti08ILOUm6qfpQE75Fn-IW5PTTqooe-mNj7jGPlvqOAyxmBJYPA==	3000.00	3000.00	Miami	2026-10-15 12:51:31.199517+05:30	\N	\N
808	Zzz28	gAAAAABq0H77tKJeJb1ppvD70HsTtaxWKVdrEW0gYpuH8kFpIOGecmuFXIlcvLxGKtSMU58JjBSrcFJIa5VqJCiKwbOrjh7-BA==	2500.00	\N	Kansas City	2026-10-15 12:51:31.293218+05:30	\N	\N
813	MS1014	gAAAAABq0H77kK_1OsffNddW-b4SE_r4NfuI-xx0b8gJ7_PN3h_wxEY3fE_4Rw8TBHo8oSuKLeJxdrM_rVAOpCwsNkqjkfrrUg==	500.00	1000.00	Missouri	2026-10-15 12:51:31.385285+05:30	\N	\N
818	Nin89	gAAAAABq0Jku9MTN0MQo10f_1H_ZYugomIXydrQx0ZoDB1X7c4bfgecAKVITLx9INGc3l6vToXmHQN-B0eRjUaBON6AhvaEW2A==	500.00	\N	LA	2026-10-15 14:43:18.48024+05:30	\N	\N
819	prasada720	gAAAAABq0JkwBULle24gzySOvjfeNmcIg21YMN_ZwN_F6P5EIjwbir7K6rP69hFR_AW2aObWarwp0FsAVgtt_TjxniTNM9PsGQ==	700.00	1000.00	LA	2026-10-15 14:43:20.131572+05:30	\N	\N
820	Lnk78862	gAAAAABq0JkwM6oiHxcyYP19g0QwWXPNFMqvHM2btFP7h5AJu1UwaDAru1hKrbjffWsyM-It20f0tNAln3rsUw_sdo6mwuH6uw==	1000.00	2000.00	LA	2026-10-15 14:43:20.161152+05:30	\N	\N
821	Mdol9304	gAAAAABq0Jkwv2nKStCkhngAve48BEMxuvbtnJZs-q4xdTbegQtj7dUu4MQ84yZiAoh5B0bCfYhAvaqPNaePv4mGaHna5ySVjg==	750.00	2000.00	LA	2026-10-15 14:43:20.180375+05:30	\N	\N
822	Ce597	gAAAAABq0JkwiP7FWg5hhbePCHF8GU-jU4KrP_eW4pCw392jITpIGLHRTmqgeJYaBp0JIm5lrXrsYTX_IMtxZyOE1GMBunk1xg==	2500.00	3000.00	LA	2026-10-15 14:43:20.196835+05:30	\N	\N
823	QZSL378	gAAAAABq0JkxPPeKDch5UG6RGTcJ3VUkrIigYt53MYZWHJajCn0F7OYJOvn5GE_dpKxbtg7lgWVni-dRoYsPnXfAkh3wXZ54mw==	10000.00	5000.00	Hoboken	2026-10-15 14:43:21.787931+05:30	\N	\N
824	QZSL384	gAAAAABq0Jkx1d6kS47qimI9guH9iqqC_9WATw1pkdA_jYIpfsQ9yml3pIOd4vBlv_18EvQtRhMYAvY8kGVOwt5pP2hPlLrBDQ==	5000.00	5000.00	Hoboken	2026-10-15 14:43:21.803081+05:30	\N	\N
825	QZSL387	gAAAAABq0JkxpdiW_ku_mMbUBQKsEJhrG4LyZSzeADHeB6_aTJe3aX-HjY3Px0bvAlcOglt5EpWvLqcGeT-CL3FkQYJB6QYgKQ==	5000.00	5000.00	Hoboken	2026-10-15 14:43:21.818339+05:30	\N	\N
826	QZSL381	gAAAAABq0JkxfSL7IO7M-ag0zh-2joLFw1-Rbyn8jNfVTl9G0ZUeUCI6qXJWT_HGoXuuET8MbXzQk0uaIkewMV8wY8B8WLtPwQ==	10000.00	5000.00	Hoboken	2026-10-15 14:43:21.832948+05:30	\N	\N
827	QZSL377	gAAAAABq0Jkxx92GlIhJU8C-uBZR-4MCGTl4z1Nd1kI1CMg9OKp60DufXBxmWsPtI5y-gYwiEjNR3DgGn4PGpWKxAyQxFHsS0Q==	10000.00	5000.00	Hoboken	2026-10-15 14:43:21.847918+05:30	\N	\N
828	Le4479	gAAAAABq0JperONce68nyeKIjuTZelqgHUXYjFBMnW6IE5Y4UQw8chekEsguWZ9ub9Rv16XeNyllqhr0SSegoZMk5TKatcS7og==	3000.00	4000.00	NYC	2026-10-15 14:48:22.297258+05:30	\N	\N
829	Ghw58132	gAAAAABq0Jpe65gENC03cn5J7qTNVJHLhTR-5eaWeYBemwH1ubKFe_SL-JrL8Vt9Lb583Zt-_GtSntknszOXhcE9NC5njZIBTw==	500.00	1000.00	NYC	2026-10-15 14:48:22.331316+05:30	\N	\N
830	Cp801	gAAAAABq0JpePE35fcmhC5N4wJ6b0SKViDF0uHQlKXgN_XzW440mi3XsqNKKEdd1mDwuJlUxc-bD9HiBZoXjJuw0xzSg7AmqCw==	500.00	1000.00	Walnut Creek	2026-10-15 14:48:22.350495+05:30	\N	\N
831	Rbolin05	gAAAAABq0JpedW9mKXgTCWgDWbMXVprbNaVYgdIqv5Q-g842DmXCiS-k05fsM2wFMg_dzV8UlIA5AdmVT5A0SYP-KCgNcmwvww==	750.00	2000.00	Dallas	2026-10-15 14:48:22.368993+05:30	\N	\N
832	Rb33272	gAAAAABq0JpeT44E8rd72OrYEdbU3Uz5NKV5Nki_5Yv6XIpguClZE6Vdr5QKM42Sdb6XP5YxmNNd4fJ7TuJDIVRjhmJU8p0UXA==	300.00	1000.00	Dallas	2026-10-15 14:48:22.386676+05:30	\N	\N
833	Mdol9189	gAAAAABq0JpemzfXXfzCpznA-8wLd2wS0k3W_uJCWwhHSfCWahTkfMPCms67z1sV7gAqJ9lbkomTVzkoxIK3vEyJ4QF9GADHaw==	2000.00	2000.00	Fort Worth	2026-10-15 14:48:22.404829+05:30	\N	\N
834	Soy392	gAAAAABq0JpeAfWorq2idlfMsOox0vZAo8ReBtwAERWibFvjGVsIBwhPdUVtLgERcpPydMcQNgS-ec733DgKb9dUw1br5InxSQ==	2000.00	2000.00	Dallas	2026-10-15 14:48:22.428702+05:30	\N	\N
835	Ghw58125	gAAAAABq0JpeuCTsj5UDVymdX2hVQ06r888GMc5KRUX-vVx3F3pU3WQRLt0UkA1Qr8ONs_HrLzH_51MSEtGKSxEmsbEJTsyWXw==	2500.00	1000.00	Dallas	2026-10-15 14:48:22.445059+05:30	\N	\N
836	reidb903	gAAAAABq0Jpelb8MX6OK5DMUkU2bGkVKlYlIeSaj03Z1xh3ulz7u2GKRV_zUFNaeWfU6LWdmOWqulZy1dzzJ-lAjy2d-HBTy5g==	700.00	1000.00	Dallas	2026-10-15 14:48:22.469839+05:30	\N	\N
837	Le4465	gAAAAABq0Jpe6F7Oz8cVvNoxP9lAjy3ZOn4vJOg_Ixq3JpAzInRb5t-KZFcpcEVipLTLIj2M9d2GX6RAXAAKT8FaQguVPK96zw==	2000.00	2000.00	Dallas	2026-10-15 14:48:22.488125+05:30	\N	\N
838	TCB162	gAAAAABq0JpeNF4KN4AKuKkOGTBtkA64YZFCubhi-hZkVYlPOYxPDGhjJAlVgkLolDqRrCi0VCfEpHHZchVANGpTh0asjVZTMA==	500.00	1000.00	Dallas	2026-10-15 14:48:22.507079+05:30	\N	\N
839	FSU114	gAAAAABq0JpeiGeGjy-Hon_BDe1vpr2okT1wAX2RdaN8Gk8ta8_CXyQaurg3jX7--MzfShVgiLE6pNk3rku-VAcggIs1JpgALA==	1000.00	1000.00	Dallas	2026-10-15 14:48:22.529733+05:30	\N	\N
840	R195	gAAAAABq0JpeMzUdLCP2TPBJ9DA-XsOIy__VE318tq0oO7Ch-oC6L3Ak3wGIjqIG7AhNNFSQN60NSjN1F5ASGZ7vMdPnLcEKPg==	1000.00	1000.00	Dallas	2026-10-15 14:48:22.544998+05:30	\N	\N
841	Dawg65	gAAAAABq0JpeTx8YL9v9_8o9OuNW0AyVjq7-7EKFN2Jr9OzqaqaDC2V2xgsvHRkbafL_24f-8Y8MV669fU-Ws-Om9WKJoSqKZA==	500.00	1000.00	Austin	2026-10-15 14:48:22.576637+05:30	\N	\N
842	Soy416	gAAAAABq0JpeGLhQwoqvhLMm0Cirx_0X0qOXDLjZyDd_1X1LXFgojc8HrNdPk5I1tqVgrZb84bYaHYHwjpw8MQ_kyC6a1HCUkQ==	5000.00	\N	Dallas	2026-10-15 14:48:22.592368+05:30	\N	\N
843	Soy417	gAAAAABq0Jpe5X4GqtbGKIvxDmWuRbHqY0BSImqkBbLfSty4dgMimJJge4ximOTVKmTnQ2RhWIS08qkE3QY09_KR8rZthB7mEA==	5000.00	\N	Dallas	2026-10-15 14:48:22.612844+05:30	\N	\N
844	Mia2707	gAAAAABq0Jpe4ZsrFgqbWslnmayjJrcSsE3yAsVI3bPfQBh4dDTtHPolHtNiVChNBYX2Lyy635-GFmfTwzkVxzLFELkhPmmwbA==	\N	\N	NYC	2026-10-15 14:48:22.642423+05:30	\N	\N
845	Gs1007	gAAAAABq0Jpe5XLc6e1xbmYyimM8_UR2KMrVjYJQSHVL2gj16jZhSQt5mpw2SP1pXdD2OAfzwKqCaedbg82n7GMK1PaoQhZklw==	\N	\N	NYC	2026-10-15 14:48:22.676135+05:30	\N	\N
846	Jnt328	gAAAAABq0JpeFtEHTIUKRHO0nWco8tRQ-MMO8m8W2gpzwgrdhgrwI8Vip3eA-SFVfCkmmaRqgvoZ27I1BO9-lT2fWMfyFDTwsw==	\N	\N	NYC	2026-10-15 14:48:22.704162+05:30	\N	\N
847	qxb2500	gAAAAABq0JpekVo-QYHt8p6w9FmooKndRurOyDyqZYT-JRFsHPzLZGG2kky8kbTPM0IhSyg8uyeoo0pinOOoCaFnYqBPasM9gg==	\N	\N	NYC	2026-10-15 14:48:22.733743+05:30	\N	\N
848	cb123	gAAAAABq0JpeaPOQMXexh300o6WYabBF-GrfpXgblX-E9jhQ_olhQAgmtOQVcN88G9HQJegVhqAC2tKKcufAzZV6bZwxJLjmrw==	\N	\N	NYC	2026-10-15 14:48:22.754212+05:30	\N	\N
849	Clear008	gAAAAABq0JpeQn_wjmXE6fFEFBgMFbeAZIfZZZdM6mly16btQeTmq1xPHVib38WCOuGhDJRZSPQgjB0GlNkpzdVT5Ae6GMC2Xg==	\N	\N	NYC	2026-10-15 14:48:22.777852+05:30	\N	\N
850	ers102	gAAAAABq0JpeCj5bMSxjCms0yQ_UsG8PtHnOjYoDzUi0Tz02sK5QxEK-hFrEgywQlik9FzLwbc3tBr6PGdrylSynCuRaQemYkA==	\N	\N	NYC	2026-10-15 14:48:22.794145+05:30	\N	\N
851	Faa100	gAAAAABq0JpeSXofs1yp-O5kCSD4ZzmgkGQTNSatoECArPmUD4sr6VzOgxms1J43Kizk9wZl6xEYufpo_RoeWZDYtFiCc5j8Xw==	\N	\N	NYC	2026-10-15 14:48:22.81298+05:30	\N	\N
852	BTZ12	gAAAAABq0JpeW3eBsqpB3JbmceXAHSMVstN_lGRb2vwkrbMqq6LeYIcCtR05WQVGwZ2wJry2x-C5CEYpKAyGkAznQY8TRwJNTw==	\N	\N	\N	2026-10-15 14:48:22.834218+05:30	\N	\N
853	Ord1077	gAAAAABq0JpeeLq4Z9nnYSCvPuhAJNrpMwG5PkC81mLur8Y_wp_aaOe5bQ7dhglBMGZ0lUMC-4pDxNn-TWCvCsdqeAIEHoT6Cw==	\N	\N	\N	2026-10-15 14:48:22.845639+05:30	\N	\N
854	Jjnc1120	gAAAAABq0Jpe9ClgCHn11Rc590uOnQp6FKeYREpQOddG4YHuP9tBUwdyTjO7iIhHpurP6jopDyPdyHo8jhopsriwgFuC2n6isQ==	\N	\N	\N	2026-10-15 14:48:22.861831+05:30	\N	\N
855	Sr119	gAAAAABq0J1hziUT6TISzOW6qRpAmnWntjn7fOsh893FmbN0I6Mw_lB9_bK0HJpOaOLcCKb6zRHBAqvbm0H76p_UUolUy98nAQ==	20000.00	5000.00	Houston	2026-10-15 15:01:13.861501+05:30	\N	\N
856	Ta1042x	gAAAAABq0J1hNvQS08C5kEsL64hDqjUJhlh8BKfKyMKOKgL5xnduAAqkmMjGz1kCkNj-nOGHfpYaRWfCYHcZ1CslkC7eFEGdkA==	20000.00	\N	Houston	2026-10-15 15:01:13.883348+05:30	\N	\N
857	Mdol9306	gAAAAABq0J-Z1Wa05-Lxl-4pCKUvY0VhwNjm9ngXXpwcqnJhcpwZrE5LnuD3l4xx2pUdSxvgXov647EcbXXpo3TFhIRNvfW5kA==	750.00	1000.00	Kansas	2026-10-15 15:10:41.581974+05:30	\N	\N
858	Vincen402	gAAAAABq0J-ZZstoBSRqYRT015tGYVwK2QwgJ6CUxP770sfPZppKdu3ld0VPWliGCnInHON6Wgs7YLbBkqv7r7bgQYbHuv_d1w==	700.00	2000.00	Manhattan Kansas	2026-10-15 15:10:41.602377+05:30	\N	\N
859	Hou1020	gAAAAABq0KG7nHWmuWxjX29GpBN6v3YlwqgaAGkk3glsxpDYt85_7rBdy1RK6Aba3bIRVbJicIzhlJDn0MmvlEOegO6bge2xVA==	15000.00	5000.00	Houston	2026-10-15 15:19:47.288536+05:30	\N	\N
862	88xb1	gAAAAABq0KG7FeaF54CZXKAtMFh_fb8FOA3_iSNq5Yid2witOVHFy_tgSYxXn6ZSu7lwYtgMW7Khw6JeO7HHAgpCRzqhBvBwcQ==	100000.00	\N	\N	2026-10-15 15:19:47.36173+05:30	\N	\N
860	Rms505	gAAAAABq0KG7TNH2WrdJIsauf_NJiTuTrEWvSoQ0sCordW9ZW6cyzPjhxGyaRUFNVqxmGc--aow10voAUraldOWGWVyDJD99LQ==	20000.00	10000.00	Houston	2026-10-15 15:19:47.31332+05:30	\N	\N
865	Tx049	gAAAAABq0KG735izhyAroXkIb-7RYVEj0GB12LqNrcnfvYPvM2gIxhj4xZ0YQhVBhOy-Wz4QEvytsCzkyaIBi3WXFYSfpzw9UA==	30000.00	\N	New Orleans	2026-10-15 15:19:47.439127+05:30	\N	\N
870	Ghw58134	gAAAAABq0KG7Dfi-aLZE5JabFKrkKDbqXoAUZIRyBAwmAKqz4yG8KPnU_ze-k6aRU3UDLqUQttCHgqT9UbM3jOD3m68qs6tjhg==	1500.00	1000.00	LA	2026-10-15 15:19:47.559727+05:30	\N	\N
875	Baker1	gAAAAABq0KG7lxB4oQsZ9POiV4o5ebgzPwxorTljI4YbLmJaiMLbHM8-tIbr1qdZcTkkIMrIlRz-djEn9r2KJjkx6luRtOGmRg==	3000.00	\N	LA	2026-10-15 15:19:47.679333+05:30	\N	\N
883	X9149	gAAAAABq0KccRsBEdsxaVh-nPFlNaJ0VNQ1vbPoCTtfcOB831h7HLrbRsS37c4hmVS7_VRLondLsLZ7ClM6a2ny_RJC5y9iM6A==	10000.00	5000.00	Dallas	2026-10-15 15:42:44.708225+05:30	\N	\N
887	Tx56	gAAAAABq0KfEEr8qAJdPDfQzRjekCg5wriYBgdZoPrvFj1o_5ckqdmkDFyRtfalT3jZ_zJ8Q57ZXnPs5BzOTU3mV36hmLES4ug==	30000.00	10000.00	Houston	2026-10-15 15:45:32.936316+05:30	\N	\N
889	P803	gAAAAABq0KhzGSb-btMrPrym-zmsQPl-HMeT81urO_74VOEFoANBysK86BcXRXsMF33DjF-9gMgOUHK19OngaRKpXEQJ9iRICw==	2000.00	3000.00	Denver	2026-10-15 15:48:27.452911+05:30	\N	\N
896	LNK0268	gAAAAABq0KpB0pekLAfp8mzyPiRVmWIbOuja7j3o5KbS_17Z_g7Iw-Umtlm-DzGlraD6L6pSifM0_eKrieo14R6_dLRHqyujkg==	1000.00	\N	Houston	2026-10-15 15:56:09.987001+05:30	\N	\N
903	Xl114	gAAAAABq0KpEg43AoJ_97qdIsm9JjQCjtFFpm212cKZJE5GY_jnVf5C0-E0W-HpfdvfqzK0F0f8_JS3I14CbwUHuz9mFFgOzVQ==	5000.00	\N	Houston	2026-10-15 15:56:12.274434+05:30	\N	\N
905	LNK518102	gAAAAABq0KtrVnhD6ydZhX6lt139f3qi1TKdbzww-FEoumdJbPttJWIRdHqdmVu8L8ELpvoRInQG4tk5CvWhjjWc0zW4HUiVEg==	4000.00	2500.00	Houston	2026-10-15 16:01:07.370997+05:30	\N	\N
909	Ch101	gAAAAABq0KzzPAxmjJOZnZBsvp-i-XeKwzX-ebutCz59zxy_gZ_fOkKmIodwe28wKBO_LmpXXmHogFdJzSxyAgBa5aO-W50Muw==	5000.00	5000.00	Dallas	2026-10-15 16:07:39.771771+05:30	\N	\N
914	Jj1293	gAAAAABq0KzzY9Ok6qK2WUUg-UToU01k4CLU8jUR_xDL3RaukHT4NPCNBzTFRSoBVBTOiZcENpdnzpswPCv56ZqXOkFC2XLGmw==	\N	\N	\N	2026-10-15 16:07:39.857238+05:30	\N	\N
919	Wj6970	gAAAAABq0KzzpA-xXjl5aaPLlDmIcJrbXCq_o3-18PPmGff5iky9WdPZRUGTQnfZNRrtZhFZzk5cGZxCwgcqCDYEDaDhky518g==	500.00	1000.00	Tampa	2026-10-15 16:07:39.940728+05:30	\N	\N
924	Ppe105	gAAAAABq0Kz05x-AdDASg-EQNqgdT9J1KLo4GhCSwSWhpJmCi1YimwSPNaGGD8SdsdWt3zr8R-2WOBPqwyQImz4PXbcbDu1row==	10000.00	\N	Tampa	2026-10-15 16:07:40.029168+05:30	\N	\N
929	Manga98	gAAAAABq0Kz0s0hJlX1X5ty416JViv8fW8g-YXHf9xDZTpXv3nbN1ZvsGa6BOOfsdSAr21ARIvu4ZQb_LInprJlVX4aMZCZITw==	3000.00	5000.00	ATL	2026-10-15 16:07:40.115915+05:30	\N	\N
934	POW2206	gAAAAABq0Kz0X6v_lj7H9WBLj7NECaY4dUdzRo-9UxgUna2m75UFqheYBSv4Z_dk4mNABqBys96NU4LmPWlrrHryCsta13iq_w==	1500.00	2000.00	Tampa	2026-10-15 16:07:40.192396+05:30	\N	\N
939	Kw200	gAAAAABq0Kz0ywKZmw4RTcCImLGF67k3euBIfSe0z5IFPessFR0hAr2hSlOIuPpnTVooVD_g_76QKTSfDB6mnB_1t5s0NHWJ7Q==	30000.00	\N	LA	2026-10-15 16:07:40.268774+05:30	\N	\N
944	Wsw112	gAAAAABq0Kz0Rvqx322c9UjSQPMG2-_8D0qWpMAjJbeueHMEkMTOXRp3PaOQp5s0qbpbUWWFpcAPAAaT_Dpo4HHGYImVd4GiIQ==	20000.00	\N	LA	2026-10-15 16:07:40.358731+05:30	\N	\N
949	Bg908	gAAAAABq0Kz0d9R3EtpSY5xErlskTaWtXaZzlQk7B3QQ2kf_WaZ_rlHIAwJaYYyKg3iynG5Wb33FLuWEPOQmJRlPgpB8vTvncw==	50000.00	\N	LA	2026-10-15 16:07:40.439219+05:30	\N	\N
954	Gd015	gAAAAABq0Kz0rfbuTUa81ijg_beZMlJxtDMrQ3Vw2LdXGBt36cr_9c5HCklUtVsZl48IqABLSEo8ouRERpYER-7ThzmUt7TJhQ==	40000.00	\N	LA	2026-10-15 16:07:40.518126+05:30	\N	\N
959	Dt220	gAAAAABq0Kz0jsZWtRtYamLElMzlGhN0jlEeTP0lidW-fM9hgTMhp04nnnEEes_noaEoQ9VNvzhzUY8CJnRUybomh-Urq7aJiA==	10000.00	\N	LA	2026-10-15 16:07:40.650312+05:30	\N	\N
964	Ps255	gAAAAABq0Kz0VStemnYGnBaXm7asYPdo1PJgSw4siePouB5emcdqi49ZXnPwIboPH82QzC_S7miHnKJRoqOZjI-8huL5vqoaTQ==	5000.00	3000.00	Baltimore	2026-10-15 16:07:40.728658+05:30	\N	\N
861	Zp18	gAAAAABq0KG7Du6inQe4tyLN7TOsleVohqy0IPwlNl8yXiaP-zy7O_8LA8kT3cuWEiVJ8rvgNfZL5au6QTXtvg4T0WD35VBJzQ==	10000.00	10000.00	Houston	2026-10-15 15:19:47.339496+05:30	\N	\N
866	16015	gAAAAABq0KG7Mq3_JAkkq5iUCm44C2sGkwW33g3Wt7X_YQ_14jsM881fa-vb1z6QYHVbSVtdQaTduOrwuaUib1aw3WSbzS-lNA==	20000.00	\N	Pittsburg	2026-10-15 15:19:47.462703+05:30	\N	\N
871	Ss453	gAAAAABq0KG7tiv67TZgl1Ph8quoY8sFD0nwjta73PvD6VXHffbDzpzjAcYUhZYUMH-MV9MwEHe_YXPuaAYSagOK5o93huYNeQ==	1000.00	1000.00	Hillsborough	2026-10-15 15:19:47.584859+05:30	\N	\N
876	R196	gAAAAABq0KG7icsN8RzvqI3JlyGf0EdKiZVRolSg7WIrZyxO6Aj4AwLMIDLolWoHnjiV6teXh29sFvzNwHr7XwnrrEz9t-OGQQ==	1500.00	\N	LA	2026-10-15 15:19:47.701866+05:30	\N	\N
879	Texan1014	gAAAAABq0KcTf00B8VucwTLNujmxdbDhU0FlYvOBIqRSvyn_nnl_CR8vtK74iMsFR5ZM54Tg9kQaRl7lci0RP3vAiGU3G8FfmQ==	10000.00	\N	\N	2026-10-15 15:42:35.523043+05:30	\N	\N
888	Ta1017x	gAAAAABq0KfGb2x8nna5p5WJ3bB7LbIwseKvJG-NEkdjHd84ckTx9dU5ivQUh-dhDlGtKFYKG7RGDNp7ofjAE2xA3RZHhSxcjA==	30000.00	10000.00	Houston	2026-10-15 15:45:34.787205+05:30	\N	\N
890	LNK70937	gAAAAABq0KjriKCpJBDLDwgF1_yw8r7CxrJJkTgLQCkiCgdQ12fbiH28GBvJ2f1ZCjaOBQ9c4h26CoNcFi8iFzKzcjbnVSDwvg==	500.00	1000.00	LA	2026-10-15 15:50:27.679605+05:30	\N	\N
892	FL7045	gAAAAABq0KmBgIkDC2aH1BNumlpmqvHPsY9ockGIchCVIF5qjadyDwIUKHlJJM6EQn2V3LPOs_pzw7-NJVmTcUU8ng2XbaD2mA==	40000.00	\N	Dallas	2026-10-15 15:52:57.614009+05:30	\N	infinite
895	LNK91499	gAAAAABq0KpBeOWd86923Rp085PCdTDNAzRh-Zu2HNXXKJ4Qid649cSBBXVoJfHetjN5GYp4ov7moLq3igo9WwsAmk3ODL7OmA==	1000.00	\N	Houston	2026-10-15 15:56:09.967741+05:30	\N	\N
900	Lsm116	gAAAAABq0KpCBwGFVGhFI35y-6Zh-_CtM_GCT5Y4PQbM7e2uYZYTUXz0ltEMxtY0Io-9D9Zn1efKmLW8cEsB1HebT91t8Y0QFg==	\N	\N	Houston	2026-10-15 15:56:10.061225+05:30	\N	\N
902	Tp510	gAAAAABq0KpE-sl0mmYmAg3gOe6ZynbMeX210kqUY6bQpLOQmCoFBgMSiNlABPmlDi-fDdj_tWYIp-eOLOK_XTt4u0G7x8tzmg==	2000.00	\N	Houston	2026-10-15 15:56:12.258073+05:30	\N	\N
904	nit2347	gAAAAABq0KtrDFO8dwh57SCSNZLX98ocvc9-E5vt1ztjaqNtNRWsmy6U2IXLN0nVei5luD-64-rsDuRZH5v5qFxJ2uFiABeXBQ==	20000.00	30000.00	Houston	2026-10-15 16:01:07.355232+05:30	\N	\N
908	Kwd2208	gAAAAABq0Kzz_ISipnm7Pz1c7MWl2gcX6EkqEbJSo-2p9ZJh8k1PRgfhydXdh4ie5F5DNmhlypPY9QyeInB7OkjHdDClXPNSKw==	2000.00	4000.00	Dallas	2026-10-15 16:07:39.752923+05:30	\N	\N
913	JJ1242	gAAAAABq0KzzB0W7rnHWIn5ZAufwQMt970Jjy90Otr_afHWrSb_ebc8F2pbS2t1pdZq2id5LZJ4ngGLH8f7_hVKXMWAT4Kmd8Q==	\N	\N	\N	2026-10-15 16:07:39.842837+05:30	\N	\N
918	A11127	gAAAAABq0KzzgNMd_WvivPd5Lh2AeM2LMqRMRIPGfGBrPMLT3DhxQ3pSYzI2DJzzmlVVx7lgwIjY74fWbMp68KHnX4VKJ0QxNw==	500.00	1000.00	Tampa	2026-10-15 16:07:39.925858+05:30	\N	\N
923	PPE132	gAAAAABq0Kz0lhRKVdehnxZvSX25smc8SpeA9ahsnWuY-gSoRIb_5_98AlodvYCehwQy5FKf5EundYmtsEbu9tA1PthmcDeVxA==	3000.00	2000.00	Tampa	2026-10-15 16:07:40.01122+05:30	\N	\N
928	Bbs013	gAAAAABq0Kz00-taBzTqTFuXruoCrtFwkz3S4Bgg1T9WbYNnSw-wV7XI-P58dOfoYib3Wk1261u2fmH-aniqqu4Mhjt5VFMomQ==	2000.00	3000.00	Tampa	2026-10-15 16:07:40.095504+05:30	\N	\N
933	Crt116	gAAAAABq0Kz0doeKjwTUTlKkbi1RNQzLjGAa6Z7-FPTiNFZhpE7rQ_1NH4JNuTHv-AAclxLgpdVNbElZ1YuxmuABraWUr4CRJA==	1000.00	2000.00	Tampa	2026-10-15 16:07:40.177771+05:30	\N	\N
938	Qt502	gAAAAABq0Kz0Bvezpyy8daRYl7aNWx-yNz46p18uABk9xDQ5g11ywvPonXnJQJcBLrDTaUmBX73x58oqoykKRWAsHYDms2_g4g==	30000.00	\N	LA	2026-10-15 16:07:40.252737+05:30	\N	\N
943	Agt690	gAAAAABq0Kz0Z-Nku4vL3jQ-pM0IvW972Zrae-OWVFCgM0-HjmJGwaHzEaEWf8vSlMmQmsaCb59fh1qaaJFAE-Y4t0dod749SQ==	20000.00	\N	LA	2026-10-15 16:07:40.342975+05:30	\N	\N
948	Qt509	gAAAAABq0Kz0srBoyt17qpQtuTZZw3LtqeGUG_jvgZiqs8GyjVgg70iwKzDRX7_UYSunOkR_e32hbBpqUMDLbiMuYue3VH3a6g==	20000.00	\N	LA	2026-10-15 16:07:40.420233+05:30	\N	\N
953	Todd115	gAAAAABq0Kz06sDMmn9rDFIxkbtSHGLelBgI1-1whiSoM2O-elk65PcxXXbd4Sxz3Tx82Rxo0nUQsoC0Sw80gt5wR2JzaX_wng==	5000.00	\N	LA	2026-10-15 16:07:40.502059+05:30	\N	\N
958	Dt209	gAAAAABq0Kz0YoHhO9xnd0P_3UkEGw7dyQDukMj7hGbwMhooGDjW1JUePXL4ga-fz-Ctng2aI3sIyk3QG6WJKRKD2wFaanam8A==	10000.00	\N	LA	2026-10-15 16:07:40.583407+05:30	\N	\N
963	PX543	gAAAAABq0Kz0HvhtDNDKEl-oT5BEbbOZECxRjsUQ3R8dk9aVbKRP_PUV0B6d4gcfCj_mUQR-MuVJITMaLMXiYWqYjojtiwIF9w==	5000.00	\N	SD	2026-10-15 16:07:40.714423+05:30	\N	infinite
863	88xb10	gAAAAABq0KG7PN4CmMhgxtuOYXiApsbME6C0mwch6IggD0UbxA4Xv0fCYsU4_2tRrODwu6a3vV-v0MKgQg9oFpGQmKUPQdaTdQ==	50000.00	\N	\N	2026-10-15 15:19:47.388771+05:30	\N	\N
868	Book060	gAAAAABq0KG73AxL12gSKLhItIF-fp6kjlUVzj04-Fa-vw20pl-swIj3UAsck2vxxtqzhZEb2--AkTciVoUqrU-IOzEzRxujBA==	4000.00	5000.00	Houston	2026-10-15 15:19:47.51186+05:30	\N	\N
873	Mdol9318	gAAAAABq0KG7MDSIVftvqOoNm3R-q7rstIP8OSIjEXBg28Dlz6BzmD0lIx8SX5goJPbI8qqlcHW4ljUqD8UW989gVIu-lK02-A==	2000.00	1000.00	LA	2026-10-15 15:19:47.631638+05:30	\N	\N
882	c47	gAAAAABq0KcaL5vVkjT99vL0jfmCkyICvJzFxC6kLjakb9QtkTZfW6Z7gq7xOFkxdyaLCbVfrwSAmSXBotBzoTPOHZUttGhxrw==	10000.00	5000.00	Houston	2026-10-15 15:42:42.433067+05:30	\N	\N
886	Aa805	gAAAAABq0KfCwQ10hiA4eDgm3tK7QCe0WpXfbF6-v9CBIUEtFdY954Adu2CEy-NpYQuu9uheFDobFwC9NH7IuyFsWpK4vYiSqQ==	10000.00	5000.00	Houston	2026-10-15 15:45:30.580974+05:30	\N	\N
897	Tm1064x	gAAAAABq0KpCeO_lJTadZcYMyoldeGj5ujrrqB1uESd6WVG3mtiZitOpRBIqKhj51Lk_v9OXU1ph7DYWUiH1eSknH5C2X7M0Jg==	10000.00	\N	Houston	2026-10-15 15:56:10.007306+05:30	\N	\N
906	Bro129	gAAAAABq0KtrDjHoH--dgY4YOzv8JZzuCUiSAinqyBcWxzbRzNoJzzbv_U4_2y2W-0IzvPkaluYdTFAgmY0PmzTOSDvtP9Bzbg==	5000.00	\N	Houston	2026-10-15 16:01:07.386967+05:30	\N	\N
910	Q524	gAAAAABq0KzzE2u2gZi8FHZaIY9dAmLwnI9WdyxcudV0w-QGC0K_RVAP97q6fgqB-aeqvSRceAyG5b2jbmrHqyAHnMopvE2KuA==	120000.00	\N	Dallas	2026-10-15 16:07:39.791778+05:30	\N	\N
915	Zpt313	gAAAAABq0KzzaX4Of7gq73MXy_KrTKIflaDkHsTraj0p2N8UPTVX241hWhjLI2nStMdPBduoYMoVJYicFnenGJEmIOetmHaFYA==	\N	\N	\N	2026-10-15 16:07:39.875394+05:30	\N	\N
920	Tig117	gAAAAABq0KzzwC7Tc9N-tHV-JgUL64VqoVBQ25QayEWRKr4V9b22AyuC3R-vXwWzbGAqo0OfUgqVv6D9xJdW-do0ptBGbfF4Tg==	25000.00	\N	Tampa	2026-10-15 16:07:39.960467+05:30	\N	\N
925	Ppe139	gAAAAABq0Kz0SmTT_UbEBR2-2xKm8orvxNxUw36BinNa-UphMDMac2wwfQ3Lr3SEVTlWk8RUIEqT6hnwlBRS05PI0g7wPlvqhg==	5000.00	5000.00	Tampa	2026-10-15 16:07:40.044495+05:30	\N	\N
930	Jj1238	gAAAAABq0Kz0wHsrg0W61NHG2d4giAbbmy2WYjdn_q4vIEVTsH6gRj77ncB5FKc3yOn0hrTtm8KPd5Z0kxyIFF_YMADEddpgjA==	5000.00	5000.00	Tampa	2026-10-15 16:07:40.130482+05:30	\N	\N
935	w89355	gAAAAABq0Kz0_sF9OIvtail1LE8Z4h5MvbGiAPVx1LGYpM_gVskVhiUgnBMA4OgRk1GSCgBQLSRdegqAMqMLaV0u8QLyEfZ0Sw==	3000.00	5000.00	Tampa	2026-10-15 16:07:40.20762+05:30	\N	\N
940	Hbo102	gAAAAABq0Kz0oBMdVLz4oS0hJyAIyCnh5s9ApcxrWRuPihQgsD7jxflUY3GOygyLUT7NWHgimwAfDTN6YIfbryeOQuJn6b3Hyg==	10000.00	\N	LA	2026-10-15 16:07:40.283898+05:30	\N	\N
945	Br804	gAAAAABq0Kz0Shd9Y2Uik06k-8eZqqSj7BpeK_8Tns_OknrYR1ul_OZXbMPS25rbBHON76EfpSJbXy3a51RjXuoqDljCMrRiug==	20000.00	\N	LA	2026-10-15 16:07:40.37321+05:30	\N	\N
950	A1061	gAAAAABq0Kz03Vk2P18TptrCD8_rUxqG-yT1E91ZNIBhTKqvXk-ssnhMPhkBgqs3E6J39ECccgLm4fUPM95sokk3jsQKgIJZDw==	10000.00	\N	LA	2026-10-15 16:07:40.455777+05:30	\N	\N
955	TL3002	gAAAAABq0Kz0kQlHcK9Xj5Rbx5NAXtnWhBa8yeQaiF69MCxMTAZpR1oNboK6qzey9zCJqrCTt3NnncFu-t9i2XXTFB6afzsdhg==	10000.00	\N	LA	2026-10-15 16:07:40.533421+05:30	\N	\N
960	Dae180	gAAAAABq0Kz0oBbi28ZggZRIHVszhn2cG3sGiJ8pxDJE_U-xs2Sp1KIfZGOiKGk6TIZ805VatddBYtZy9Vqi8KqUU-1E_0xFEg==	3000.00	\N	SD	2026-10-15 16:07:40.666175+05:30	\N	\N
965	Zak7803	gAAAAABq0Kz0Hy6xaLQnXHQH4bf37mS0J-cpuwHyusPOm8qmFaO9KSOECqeNsuNRm8K9g6_XkX1vTJBKb_LctqxVVieAAg7CVw==	1500.00	1000.00	Baltimore	2026-10-15 16:07:40.743821+05:30	\N	\N
864	Xyz848	gAAAAABq0KG7bHvwwP2AhQDwDTWQNZKxWkmiQUAI5Rgin_4pCVH91o4PSYwBGfUXlKbxuZJIm4y2wUYSukyqUj2Lg3ATYyhY-Q==	3000.00	5000.00	Houston	2026-10-15 15:19:47.41118+05:30	\N	\N
869	Nit1066	gAAAAABq0KG7wZ3AnYOCcNZGs4ZMVcW1bmkKaS2gEjw13hXbmZqMFybHfnSABaudFss2lx_TJ3TrzT9uH54_ntv6xmGW3XfUrg==	3000.00	\N	Houston	2026-10-15 15:19:47.535432+05:30	\N	\N
874	KNC431	gAAAAABq0KG7hrdSAPM6aYGBENbx-Cmo5AJK1Zz74lcg2YMNvj1K8I9JyJX-E8GIKmbQdgyyD1CxhZ9J-zkF7z77u2lJVk7RMg==	2000.00	\N	LA	2026-10-15 15:19:47.654626+05:30	\N	\N
877	16016	gAAAAABq0KNfJeSjAEyK-SARcyBDTEoun6Qr-Y4PljJwK03HFmE2Bko1GT8XJe8qmHIi96kBvZxvuHlbJJJMa9sJt3RUSfPtRQ==	25000.00	\N	Dallas	2026-10-15 15:26:47.676527+05:30	\N	\N
880	Texan1002	gAAAAABq0KcVRUmutCoEK_mr9dQkLQBfbMmUsgMRNkRXC_UNgYODuPDffHOBCI71D9Gfcxd6v8ZVPPQPK1awrBfCyzZ3KZrJyw==	50000.00	20000.00	Houston	2026-10-15 15:42:37.609316+05:30	\N	\N
884	Rn31	gAAAAABq0Ke-QCuzieUTqv_y40lA-w3jiD_7q1DmZ3uxvX4Ja4XjUuXXdjKLYbZONMGBoFSv62CZNjsFYeFkyOhFCUoHyxxpVw==	10000.00	5000.00	Houston	2026-10-15 15:45:26.874194+05:30	\N	\N
891	FL7046	gAAAAABq0KmB_otb9pkx7dWKeYYjdwZxfGPGT1hwcqIrhXuNrZQ9M8PjUrfcCU0-Tp8JnfDL46O_UYxJQ7ZDq7HOcG5L9Lv3yQ==	40000.00	\N	Dallas	2026-10-15 15:52:57.598854+05:30	\N	infinite
894	LNK091559	gAAAAABq0KpB-XbheNvdYbvqU0YLzn4qXSl3uUB03Mbi8c80ILD1WUC3LU7yygTOYKJ5O0V_uKSrOWShsvOacjblG_ZOgItpRw==	1000.00	\N	Houston	2026-10-15 15:56:09.949809+05:30	\N	\N
899	Cr1044	gAAAAABq0KpCcsx2OYog5B81qid5ZuIPFtZkH0AUrO4jhOgz3g4EkC2KG3tPhL2m8X5jMqK77Lz0vZYcZ4cnqlGXK_zRNFxiUQ==	5000.00	\N	Houston	2026-10-15 15:56:10.044924+05:30	\N	\N
901	Xl113	gAAAAABq0KpEGvU5CwuryLp3X7TxS9tUQ-HLJ5pVdwTIiV6XMyp5eS4exeD8yiPHl0U2xbjX0s0qx0s5oBgFcHeOGvRr1of0fg==	10000.00	\N	Houston	2026-10-15 15:56:12.241023+05:30	\N	\N
907	Aplautz	gAAAAABq0KzzbOsZL3691uWaD1oWwYxbpyw_5Od8ec8PuxIApB8JiVwoHl6LoWYJsvE07rdbBiAqO5D3Gg-U_1-UsO5Ngi9vJg==	2000.00	\N	Dallas	2026-10-15 16:07:39.726498+05:30	\N	\N
912	Ppe142	gAAAAABq0KzztKVk7CEOwtH7jm7nRRPnY8t-a5vxQPiFKwPjr-ZdVJq5aHIeVqKm8Z0NEfo2W9Exu1OVP60AC2ath99pUVeG5Q==	\N	5000.00	\N	2026-10-15 16:07:39.826651+05:30	\N	\N
917	36901	gAAAAABq0Kzzp4yjIn6cU81JI8rdnu1wVy0GknRqqFs-ust_6EI6o2tBqaZkGcgljubQmJUCgLuLBBnBsv_XcCKzbfKNhhjKdQ==	3000.00	\N	Tampa	2026-10-15 16:07:39.90652+05:30	\N	\N
922	314	gAAAAABq0Kzz-4k0HzKQdqUJRaGMsyPY259_wxsvBstaANQ2Uzm0kVnnLlrYGOXrg6pePyRBIc3C5gISxgl2d7rD_tRhuaAjEg==	10000.00	5000.00	Mass	2026-10-15 16:07:39.994971+05:30	\N	\N
927	Xrt543	gAAAAABq0Kz0IYIX_2Lr8AhS8NnNyUzWyiDmkKuOPV7_0yr8P1zrtEpTUtUD1Kph0u52lIRlhQ4dn40WYv6l_a5wRbvoEo6-ng==	5000.00	\N	LA	2026-10-15 16:07:40.079632+05:30	\N	\N
932	Mia166	gAAAAABq0Kz0PBylV3Z0JN_MUKwScP1Bx2iZEJdkZY5ZYZrh8K_8fE3VUklrcxepQZixBfcnIxk6VUQtrljbBiddch-bk6Z1MQ==	1000.00	1000.00	Tampa	2026-10-15 16:07:40.161172+05:30	\N	\N
937	Mv6632	gAAAAABq0Kz0qaUxBzv_isqGN7gltE2MbJBN4YIlmUcUxF_0so6alYJGWtxaZjm8TZ8QswK4ffKMHRQQobbveSrK6apQainGGg==	20000.00	\N	LA	2026-10-15 16:07:40.23785+05:30	\N	\N
942	Ppp300	gAAAAABq0Kz02mBs6SQAqyrKUPePIZT2bsIXMIJkOhFS35ZsHjxgdAPr2Kd92GLWkhOh9fRjxv8PVBetq5FZCMQagACqs8iehw==	10000.00	\N	LA	2026-10-15 16:07:40.322867+05:30	\N	\N
947	tt804	gAAAAABq0Kz0MtWYbejT3YMV7FUPt4OQgZ8PaPWoZ59v2dkrz0Vh79aTShR4nYL0JN8rcPrMYPyLT2w8eHFPWM9oxsxtPTzv4g==	10000.00	\N	LA	2026-10-15 16:07:40.40441+05:30	\N	\N
952	Ftt24	gAAAAABq0Kz0sGO5cAfosy1DDYDxHq-fGnJX3fH7Y2rJoW_H4-E4zrtwAuIvv-h5Xn882daCH5j58PWx4tnlZg37iAuhteLuKQ==	10000.00	\N	LA	2026-10-15 16:07:40.486927+05:30	\N	\N
957	Dt223	gAAAAABq0Kz0jPiJeRxO7wY9rc2EJx0RsO2WthWpnPhamcNWP7be-C8evWbeDnCY3ArhoP8HcXMxfupUuD-mty4noVZyIq6fmA==	10000.00	\N	LA	2026-10-15 16:07:40.567769+05:30	\N	\N
962	Srt1002	gAAAAABq0Kz0Mu5ztqHFD4lQIkJipfPZNH-BN8B5SxN8rofnD2P3JbadrjNQHZ-YxYb-2Ji4EzTDQyDX8-SP7HDhmxty3jNUIA==	2000.00	1000.00	SD	2026-10-15 16:07:40.699246+05:30	\N	\N
967	Sean125	gAAAAABq0Kz0d-Ut0eOMyoN1xJWwhqwDd-hUOoWBTo8p3xVea3I6QV13-Mu8FRxirDIjsTJ6JG6oapm8zmhVxO1FB7m9xBSuSA==	2000.00	5000.00	Baltimore	2026-10-15 16:07:40.774103+05:30	\N	\N
867	Sam2352	gAAAAABq0KG7-Vsgvo2VxupoIzGbJq0br7BvPv5Tgx-rSyYnOFUmvZ9s8F-_qzTpbz1DS0pKTujcM4ndiT4YrXnjLxPG2zcYEg==	2500.00	3000.00	Houston	2026-10-15 15:19:47.485043+05:30	\N	\N
872	+Le4449	gAAAAABq0KG74BBupUoKltSIXeoIins5WJi0M8EgvpCekm4ZMkx41gkt9UTuCM3UmhrcpSidUfP4Rc7JgLcwKMK9slSRjWOmOQ==	2000.00	1000.00	Hillsborough	2026-10-15 15:19:47.608847+05:30	\N	\N
878	Sb302	gAAAAABq0KVokJ3StME0JqD5hfLTYX8oKEIWr5KQoAWXmbidWlcvRPMyJBgm3v2X4GFyJ6SNZc5eK4xa3GwR9s_BoUSD1VhLZw==	5000.00	3000.00	Dallas	2026-10-15 15:35:28.200444+05:30	\N	\N
881	Lm1019	gAAAAABq0KcYNm7kZmUrJFwajNrWBW99K-_OvgJoKOUFbB97Ek7fapo2RTIhKXRSXJApJ9akcFJkZ0DGg3AaKTQO7OO4SlW5xQ==	10000.00	10000.00	Houston	2026-10-15 15:42:40.029942+05:30	\N	\N
885	Htx113	gAAAAABq0KfAeCZzmgxyrVXtYrXYAM9hw1eak3H9BuZJfvQNdqZ9B-H2jEwKuNbyb5nYf55zOf1CuQ8sa7A5Ldh7BEc0SvrgBw==	10000.00	5000.00	Houston	2026-10-15 15:45:28.775841+05:30	\N	\N
893	Hk117	gAAAAABq0KpBJYiWqMmtv338CbkMo6r4SdYd0G_0NlPYCfCkn1GkuUoOGvPyYCwFU3rFUK6CtXXQbNipZiY04sHf5p6GYRTxVg==	1000.00	\N	Houston	2026-10-15 15:56:09.933485+05:30	\N	\N
898	Tm1067x	gAAAAABq0KpC-WYmpC315AeNkTMwG3oJyErkzxnhVqcyCB7RRi7g6rsV9MUSD0o8Ap_m7X9NoAULei5gXy-svXMpMucYUl2IEQ==	10000.00	\N	Houston	2026-10-15 15:56:10.02821+05:30	\N	\N
911	100j	gAAAAABq0KzzcjdXoFvsQjXHKkr3IYpb0C1iZnm1YPf5OcVzKNJwFw_q-HpOi1IyTcIkTgOP-3LTdZYCQ-wtxyhrQF-4fsCW_A==	\N	\N	\N	2026-10-15 16:07:39.808332+05:30	\N	\N
916	Crt118	gAAAAABq0KzzRtenGRRf2PCDPbkF5A2FAUGOqUdC-yGsaaGdEdHK7_y-a8szxrsiChIhHv0jC3W73sSkDpF_Njq3MK33TTXeSw==	7500.00	10000.00	Tampa	2026-10-15 16:07:39.89138+05:30	\N	\N
921	FSU134	gAAAAABq0KzznKfEMgnImZCBR88ZkesQVtUMxvUTYPpA1uFA_k4uovysEj10sj7ZMrjX79Kz2QzZ4lQftiJp_cxICgvfivKwlA==	10000.00	5000.00	Tampa	2026-10-15 16:07:39.97872+05:30	\N	\N
926	Aus11	gAAAAABq0Kz0UbfWqCheShsd9Lgsw8oB5uWQG8dpd9VG2ZNmciW82VvXB1rPVWp-jJ-lhFA14KJFoXFE0JWSca2jPc1p2jOCYg==	50000.00	\N	NYC	2026-10-15 16:07:40.059919+05:30	\N	\N
931	Skin822	gAAAAABq0Kz0VUzUoBePkTwg5ttNJeeoI68RiSpILH2alIiy1wZXQneLUVMRLHyLLiRaxEVheFUGzcjDb4GqMERN0NuJ1EEezQ==	10000.00	3000.00	San Fran	2026-10-15 16:07:40.146574+05:30	\N	\N
936	St966	gAAAAABq0Kz0qrMGppowhfl7PKgzF3k4X5OMj3yVPz65qyqAoO27Mc3qiKNOkLktrMtG5Gd-ynE-zhgakwq5DPTrsX1JV1jJxQ==	25000.00	\N	Dallas	2026-10-15 16:07:40.222597+05:30	\N	\N
941	Xo444	gAAAAABq0Kz09lMrwtrdpV3uoF6bcfF0tHJvWO3qqHlvK4cLLZDyNIKnkecavsELBedoLs7BO92Cu_9MMJA4nXfewO8_ig6AUw==	10000.00	\N	LA	2026-10-15 16:07:40.30177+05:30	\N	\N
946	Sf112	gAAAAABq0Kz0S67kLjRq37py2UqZLOyD3hCz2ZriJrJW_zLa1yl_JWYba0nYlkioaN366z0uL-QW9gVbfnHMm1YvKSqX6AcvTg==	20000.00	\N	LA	2026-10-15 16:07:40.389329+05:30	\N	\N
951	Ren403	gAAAAABq0Kz0hPjXwtchOPlFndw2eBP-aipxa2oZ6Dp314wCJ84TlkUk3aq4h31w7CHCW-dRBkGnPxjGLnutqSBPDGYPuXvn7g==	10000.00	\N	LA	2026-10-15 16:07:40.471222+05:30	\N	\N
956	Todd111	gAAAAABq0Kz0VA2b7-BmeS6Eoo0BCJx1SRghPdlH5o4HQpGtzbgV6onbR7d-9gPoSS1ujIS0yTVmE8hJv-x6-rRW-4rXlJCPOQ==	10000.00	\N	LA	2026-10-15 16:07:40.551888+05:30	\N	\N
961	San20	gAAAAABq0Kz0Or3CqvnCRXamOMVgwtC6ldEVWD3R-LrsYH1lGBRyYjq7_o-Ygay2zn59hAd9e933_tnaC305eiQ0of0d4BNPXg==	10000.00	\N	SD	2026-10-15 16:07:40.684065+05:30	\N	\N
966	Jos132	gAAAAABq0Kz02P2WrXek9oBq67yD8Lrj5f_Z7XymzxsjK4e_7XJsoU7aXBR4UCI7I0ajMgBB1wSPEEgjBcm99GvRIJZJ4-rP6Q==	20000.00	10000.00	Baltimore	2026-10-15 16:07:40.758925+05:30	\N	\N
968	Ju2048v	gAAAAABq0K4wv8T6ssMAlvVLMNoOCA0MOeHAALYip8kD9mYItxEV8V1kiJZXoTDyemFp-XT7-fNNj-B2dCUFNE2pn9hXlTBcbg==	\N	10000.00	LA	2026-10-15 16:12:56.547256+05:30	\N	\N
969	Bgg411	gAAAAABq0K4wlsSXmbeGVgnK49NngxMTfCQset428ph5Jt5szNo_jsLrPXxN1cziGfZLk9XYmmMi0FCaCrlYjFCDof9sOvKuAQ==	\N	10000.00	LA	2026-10-15 16:12:56.581956+05:30	\N	\N
970	Jrsdb1921	gAAAAABq0K4wwRSdAV1Nerj5BbOfGBBIjp45iCaTyH0WxQEB7EBki2Rk0XU2L3kU1EfY2LepsLPyZDN9TPKUnfQJiYODUpUBdA==	\N	\N	LA	2026-10-15 16:12:56.600201+05:30	\N	Unlimited
971	Nh132	gAAAAABq0K4wH7_X4Fnw4QLZYn6Pwr-lgOj057-ILRNuW7UR2yO1pITmobXJMg1-j3D9exJD8k_T5dV6PoXqfYkDuP9wxlpoBw==	\N	\N	LA	2026-10-15 16:12:56.626547+05:30	\N	Unlimited
972	Nnj13	gAAAAABq0K4wiLTTrRCvng-63rUGKS7L19efIjDvW1bPInaBF4bXN72h34XX4ZrBmbTBfL-1wjMLM1yFcU5UVoirV_vHSZv-bg==	\N	\N	LA	2026-10-15 16:12:56.643373+05:30	\N	\N
973	B3412	gAAAAABq0K4wXpYYjXYAnrygjLlc2N-wo0Ltz27r5CMpdX6DL53JlOb864lhYGbONfhOLpxtNaF0doU5MY0PG0aZTUQDF7rd2Q==	\N	\N	\N	2026-10-15 16:12:56.662557+05:30	\N	\N
974	B3436	gAAAAABq0K4wV7rPJDPkjVn1p75Ac8ZPDYz6mwuD10udzBkibCDyj7z_bZMKKW_EgZpgPFUzqTp70dhkYzSaWjiXwvZ9p4jgTg==	\N	\N	\N	2026-10-15 16:12:56.675991+05:30	\N	\N
975	B3437	gAAAAABq0K4wE4W3htIVMBwNYzWv56YAJ2pDde2LW2Yoi6UFYV8fCpap0oeVrb2MYtmmZxVZrHf1qAzTfgOkI08kEj2hsy4oiA==	\N	\N	\N	2026-10-15 16:12:56.688502+05:30	\N	\N
976	B3438	gAAAAABq0K4woXjzGvuCNytNelUoL-0hnBi60CA8sLb7DjMdkjiipmtpvSKUrfxKZvt0DVA14uFrFRx3t-Jilb3MIhuqgNfm_w==	\N	\N	\N	2026-10-15 16:12:56.701812+05:30	\N	\N
977	Blk204	gAAAAABq0K4yGx7DKpRJgWdC54BGmnOZP4YoyjuWxmX_EcyWqRRt9dkhuPEVVWre0wLxhoi3jGMEiga1WV1bLASrlcMDCG5pyA==	20000.00	\N	Tampa	2026-10-15 16:12:58.681846+05:30	\N	\N
978	Tn318	gAAAAABq0K40_NSlrcK_yBFnDEE4Nft-_Sl21iPnlrwz25YhlipeBQOoeo1gb_WxEdyrRfPdB0i4gp4v3EKVnz03BLNIvEIT1g==	20000.00	\N	\N	2026-10-15 16:13:00.676837+05:30	\N	CLT
979	W27254	gAAAAABq0K40M4aJ7XoshpEEXJUyNVMkGjj-i2nu_YWOujEn94Cctf1_l_cT4U9d-PE3VQ8llSGJamzVwC_l9IeojRaJ_mQ4VA==	20000.00	8000.00	Mass	2026-10-15 16:13:00.703548+05:30	\N	\N
980	Ccc2419	gAAAAABq0K42tVPfeSIC9t2ILN0KuoXl7_oSAmXzGWQu-xtvVyvbpf0Sz0yV6bmkZU0md_xaHsVl_OG7g54LHOAhUlvdc1qLvA==	25000.00	5000.00	Dallas	2026-10-15 16:13:02.671174+05:30	\N	\N
981	Tb269	gAAAAABq0K423Hl61wkdXsIsNzE-oEFMqrDrhzdprCL2otcIT7_cM-6UhahPRKtdN2BGFaUKBs5X_ryoQUcVnbLee6WfUMexqQ==	5000.00	5000.00	Dallas	2026-10-15 16:13:02.69767+05:30	\N	\N
982	Mc189	gAAAAABq0K42lLZNWfbbrvPbfiUBR2rFrq_KvM1XCTm77l5t3xOVJVKOhRmYZyTgRrdZGrQkmA7Erqnn7Ibqmb-tKWG-UEJBew==	5000.00	5000.00	Dallas	2026-10-15 16:13:02.713183+05:30	\N	\N
983	Xx10	gAAAAABq0K_tBFTAozHIs_J2FcvB0VRtAKIzv-HB_WnK175OnoNiJpNOlvnTH_Wx4O1ocxwvPj6_sl-yOZnszMnr0Qd8hJePzA==	\N	\N	\N	2026-10-15 16:20:21.467867+05:30	\N	\N
984	Xx122	gAAAAABq0K_tYTdtcqmih31GJBjjao4d5YvLKtAu7fuTe16pl3ZVf-z6dy0YQRr1WiLBo3nsZqOvHl6RxRNO3Q49PEQdZAAHtg==	\N	\N	\N	2026-10-15 16:20:21.480961+05:30	\N	\N
985	Xx123	gAAAAABq0K_t1pePBkv6MVA4aGZ3auJYuCvGhS7DkG2zOWEP7V4slVfJNQ736BfZfcz-ZbkXfJqoel28043LBLIUdYher-a2FQ==	\N	\N	\N	2026-10-15 16:20:21.492393+05:30	\N	\N
986	Xxx125	gAAAAABq0K_tVSDxjpctY7u5ddAkpwxyu_lf3PUPhrTsPoLLE1nCFtLSPMzkpGxI3A-o3j6uYe5R2EM6ZW-EK8Rp4B8dcmprhw==	\N	\N	\N	2026-10-15 16:20:21.508896+05:30	\N	\N
987	Jt2002	gAAAAABq0LEgwPi83P5ZVGvqa8Oz8eJbfNP24YKqvp3RyMQiF3-2YPYltaYwXJnB60xCBZpQQs_AsqcjTOhwLRoZti3SqkFoOQ==	10000.00	2000.00	Dallas	2026-10-15 16:25:28.654696+05:30	\N	\N
988	Pro729	gAAAAABq0LEgvZlny7v69dG8fRUEou4XvV-Qox4qhE4texECllR1RiWbMvOO-pzkorS23gmZTudd0yBCs_BpsgIqcpiH1UVi7w==	2000.00	3000.00	Dallas	2026-10-15 16:25:28.683363+05:30	\N	\N
\.


--
-- Data for Name: admin_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_credentials (id, username, password_hash) FROM stdin;
1	admin	d56bc5b85793bc8722d057437df58d3c$42ec2d1d6dd9d927ee2ddb76934632edd13125c413ed35669b5d495a1954a034
\.


--
-- Data for Name: figures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.figures (id, party_id, account_id, figure, figure_date, start_date, end_date, entered_by, created_at) FROM stdin;
1	162	185	100.00	2026-10-14	\N	\N	1	2026-10-14 15:42:52.926341+05:30
2	162	177	450.00	2026-10-14	\N	\N	1	2026-10-14 15:48:16.079285+05:30
5	164	737	120.00	2026-10-15	2026-10-16	2026-10-23	1	2026-10-15 12:42:36.92663+05:30
6	163	723	200.00	2026-10-15	2026-10-14	2026-10-22	1	2026-10-15 12:43:59.876378+05:30
7	164	737	100.00	2026-10-15	2026-10-14	2026-10-22	1	2026-10-15 12:44:55.865505+05:30
8	173	732	250.00	2026-10-15	2026-10-15	2026-10-15	1	2026-10-15 14:12:32.605453+05:30
\.


--
-- Data for Name: parties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parties (id, kind, name, name_key, created_at) FROM stdin;
1	partner	Baws	baws	2026-10-13 16:53:00.198581+05:30
2	partner	SlumDog	slumdog	2026-10-13 16:53:00.217169+05:30
3	partner	Jon Bowman	jon bowman	2026-10-13 16:53:00.224092+05:30
4	partner	Arnone	arnone	2026-10-13 16:53:00.230151+05:30
5	partner	Sleepy	sleepy	2026-10-13 16:53:00.237692+05:30
6	partner	Ronak Patel	ronak patel	2026-10-13 16:53:00.244244+05:30
7	partner	Jack Sheplack	jack sheplack	2026-10-13 16:53:00.249996+05:30
8	partner	Brian Dunivant	brian dunivant	2026-10-13 16:53:00.255576+05:30
9	partner	Rudy De La Cruz	rudy de la cruz	2026-10-13 16:53:00.26154+05:30
10	partner	Paul C	paul c	2026-10-13 16:53:00.267486+05:30
11	partner	Paul C 2	paul c 2	2026-10-13 16:53:00.273187+05:30
12	partner	Alex Maroney	alex maroney	2026-10-13 16:53:00.2788+05:30
13	partner	Leech	leech	2026-10-13 16:53:00.285363+05:30
14	partner	Dylan Epinger	dylan epinger	2026-10-13 16:53:00.291792+05:30
15	partner	Cam D	cam d	2026-10-13 16:53:00.297197+05:30
16	partner	Tuan	tuan	2026-10-13 16:53:00.302621+05:30
17	partner	Sand	sand	2026-10-13 16:53:00.30917+05:30
18	partner	Blitzcrank	blitzcrank	2026-10-13 16:53:00.314845+05:30
19	partner	Noy	noy	2026-10-13 16:53:00.320689+05:30
20	partner	Brian Nguyen	brian nguyen	2026-10-13 16:53:00.325997+05:30
21	partner	Leo Martinez	leo martinez	2026-10-13 16:53:00.331471+05:30
22	partner	Tommy	tommy	2026-10-13 16:53:00.33862+05:30
23	partner	Tommy 2	tommy 2	2026-10-13 16:53:00.344124+05:30
24	partner	Michael Nicoletta	michael nicoletta	2026-10-13 16:53:00.349923+05:30
25	partner	Joe Cassidy	joe cassidy	2026-10-13 16:53:00.355659+05:30
26	partner	Sham	sham	2026-10-13 16:53:00.360945+05:30
27	partner	Jack C	jack c	2026-10-13 16:53:00.366915+05:30
28	partner	Dre	dre	2026-10-13 16:53:00.372668+05:30
29	partner	Dom Olinger	dom olinger	2026-10-13 16:53:00.377708+05:30
30	partner	Ryan Leal	ryan leal	2026-10-13 16:53:00.384149+05:30
31	partner	Rubika	rubika	2026-10-13 16:53:00.391259+05:30
32	partner	Justin Seidman	justin seidman	2026-10-13 16:53:00.396599+05:30
33	partner	Crypto	crypto	2026-10-13 16:53:00.402784+05:30
34	partner	BGORA	bgora	2026-10-13 16:53:00.408002+05:30
35	partner	BGORA 2	bgora 2	2026-10-13 16:53:00.414131+05:30
36	partner	Vinny	vinny	2026-10-13 16:53:00.420461+05:30
37	partner	Vinny 2	vinny 2	2026-10-13 16:53:00.425817+05:30
38	partner	Andy Reed	andy reed	2026-10-13 16:53:00.431938+05:30
39	partner	Pete	pete	2026-10-13 16:53:00.438987+05:30
40	partner	Devan	devan	2026-10-13 16:53:00.444601+05:30
41	partner	Warren	warren	2026-10-13 16:53:00.451825+05:30
42	partner	Andy Reed	andy reed	2026-10-13 16:53:00.458488+05:30
43	partner	Eugene Golubchik	eugene golubchik	2026-10-13 16:53:00.464594+05:30
44	partner	Matt Campos	matt campos	2026-10-13 16:53:00.469969+05:30
45	partner	Tyler F/Ben	tyler f/ben	2026-10-13 16:53:00.475769+05:30
46	partner	Eddie Lepore	eddie lepore	2026-10-13 16:53:00.481834+05:30
47	partner	Gabe Moskow	gabe moskow	2026-10-13 16:53:00.488645+05:30
48	partner	Spencer Stenger	spencer stenger	2026-10-13 16:53:00.494367+05:30
49	partner	Ryan Hogan	ryan hogan	2026-10-13 16:53:00.499979+05:30
50	partner	jamie	jamie	2026-10-13 16:53:00.505263+05:30
51	partner	Garrison	garrison	2026-10-13 16:53:00.511211+05:30
52	partner	Garrison 2	garrison 2	2026-10-13 16:53:00.516656+05:30
53	partner	Johnathan Schnitzer	johnathan schnitzer	2026-10-13 16:53:00.522072+05:30
54	partner	Johnathan Schnitzer	johnathan schnitzer	2026-10-13 16:53:00.527507+05:30
55	partner	Joey Callahan	joey callahan	2026-10-13 16:53:00.533625+05:30
56	partner	Pablo G Accounts	pablo g accounts	2026-10-13 16:53:00.541187+05:30
57	partner	Ryan Holtz	ryan holtz	2026-10-13 16:53:00.546661+05:30
58	partner	MAR	mar	2026-10-13 16:53:00.552245+05:30
59	partner	Decky	decky	2026-10-13 16:53:00.558261+05:30
60	partner	Rico	rico	2026-10-13 16:53:00.563726+05:30
61	partner	Donnie B Accounts	donnie b accounts	2026-10-13 16:53:00.576359+05:30
62	partner	Donnie B Accounts	donnie b accounts	2026-10-13 16:53:00.628172+05:30
63	partner	Erik Preuss	erik preuss	2026-10-13 16:53:00.638981+05:30
64	partner	Playtech	playtech	2026-10-13 16:53:00.648154+05:30
65	partner	Manny Fresco	manny fresco	2026-10-13 16:53:00.6597+05:30
66	partner	Tim	tim	2026-10-13 16:53:00.666516+05:30
67	partner	Sweiss	sweiss	2026-10-13 16:53:00.671693+05:30
68	partner	Ray Cordano	ray cordano	2026-10-13 16:53:00.676789+05:30
69	partner	Ray Cordano 2	ray cordano 2	2026-10-13 16:53:00.682981+05:30
70	partner	Ryan Kid	ryan kid	2026-10-13 16:53:00.68987+05:30
71	partner	Ben Bosker	ben bosker	2026-10-13 16:53:00.695362+05:30
72	partner	Ben Bosker 2	ben bosker 2	2026-10-13 16:53:00.701018+05:30
73	partner	Drago /Drago 2	drago /drago 2	2026-10-13 16:53:00.706324+05:30
74	partner	Jonathan	jonathan	2026-10-13 16:53:00.712183+05:30
75	partner	Jonathan 2	jonathan 2	2026-10-13 16:53:00.71906+05:30
76	partner	Josh Banuelos	josh banuelos	2026-10-13 16:53:00.724149+05:30
77	partner	Dylan/Dustin	dylan/dustin	2026-10-13 16:53:00.729863+05:30
78	partner	Hippy	hippy	2026-10-13 16:53:00.736891+05:30
79	partner	John S	john s	2026-10-13 16:53:00.743281+05:30
80	partner	Austin A	austin a	2026-10-13 16:53:00.749092+05:30
81	partner	Austin 2	austin 2	2026-10-13 16:53:00.754267+05:30
82	partner	Austin 3	austin 3	2026-10-13 16:53:00.75987+05:30
83	partner	Leaks	leaks	2026-10-13 16:53:00.76548+05:30
84	partner	Gerald Medina	gerald medina	2026-10-13 16:53:00.770519+05:30
85	partner	Sean Lorden	sean lorden	2026-10-13 16:53:00.776592+05:30
86	partner	Angus	angus	2026-10-13 16:53:00.782408+05:30
87	partner	Guapo	guapo	2026-10-13 16:53:00.789409+05:30
88	partner	Cutter	cutter	2026-10-13 16:53:00.795151+05:30
89	partner	Baylor	baylor	2026-10-13 16:53:00.800945+05:30
90	partner	WIlliam Watson	william watson	2026-10-13 16:53:00.806754+05:30
91	partner	Rece Gustafson	rece gustafson	2026-10-13 16:53:00.812466+05:30
92	partner	Marcus Schoepp	marcus schoepp	2026-10-13 16:53:00.818131+05:30
93	partner	Nolan	nolan	2026-10-13 16:53:00.823798+05:30
94	partner	Turtle	turtle	2026-10-13 16:53:00.828832+05:30
95	partner	Eddie	eddie	2026-10-13 16:53:00.835874+05:30
96	partner	Mike	mike	2026-10-13 16:53:00.842346+05:30
97	partner	Cade/Barrett	cade/barrett	2026-10-13 16:53:00.847834+05:30
98	partner	Sean Zeer	sean zeer	2026-10-13 16:53:00.853746+05:30
99	partner	Sean Zeer 2	sean zeer 2	2026-10-13 16:53:00.858949+05:30
100	partner	Jason /Trey	jason /trey	2026-10-13 16:53:00.864448+05:30
101	partner	Carlos	carlos	2026-10-13 16:53:00.870121+05:30
102	partner	Connor	connor	2026-10-13 16:53:00.875341+05:30
103	partner	Dad	dad	2026-10-13 16:53:00.880828+05:30
104	partner	Bro	bro	2026-10-13 16:53:00.88799+05:30
105	partner	BullDog	bulldog	2026-10-13 16:53:00.893424+05:30
106	partner	Andrew Gombas	andrew gombas	2026-10-13 16:53:00.899818+05:30
107	partner	Danny weez	danny weez	2026-10-13 16:53:00.905197+05:30
108	partner	Vinny Russo	vinny russo	2026-10-13 16:53:00.910958+05:30
109	partner	Hung	hung	2026-10-13 16:53:00.916799+05:30
110	partner	Hung 2	hung 2	2026-10-13 16:53:00.922418+05:30
111	partner	The Operation	the operation	2026-10-13 16:53:00.92747+05:30
112	partner	Blake Andrews	blake andrews	2026-10-13 16:53:00.934409+05:30
113	partner	Stone Joseph	stone joseph	2026-10-13 16:53:00.94318+05:30
114	partner	John nolen	john nolen	2026-10-13 16:53:00.952107+05:30
115	partner	Davis Cooper	davis cooper	2026-10-13 16:53:00.958286+05:30
116	partner	Will Uhrich	will uhrich	2026-10-13 16:53:00.964488+05:30
117	partner	Chandler Chaffee	chandler chaffee	2026-10-13 16:53:00.969776+05:30
118	partner	Ted Fernandez	ted fernandez	2026-10-13 16:53:00.974887+05:30
119	partner	Luke Hodgkinson	luke hodgkinson	2026-10-13 16:53:00.980891+05:30
120	partner	Spencer Blacksher	spencer blacksher	2026-10-13 16:53:00.986328+05:30
121	partner	Sam Georgiana	sam georgiana	2026-10-13 16:53:00.991857+05:30
122	partner	Ridds	ridds	2026-10-13 16:53:00.998322+05:30
123	partner	Grant Champman	grant champman	2026-10-13 16:53:01.004171+05:30
124	partner	Bru	bru	2026-10-13 16:53:01.010867+05:30
125	partner	Zach Stephen	zach stephen	2026-10-13 16:53:01.016572+05:30
126	partner	Ryan Baker	ryan baker	2026-10-13 16:53:01.021653+05:30
127	partner	Nick Mcadam	nick mcadam	2026-10-13 16:53:01.027954+05:30
128	partner	Vinny Nguyen	vinny nguyen	2026-10-13 16:53:01.033748+05:30
129	partner	Luke Hatfield	luke hatfield	2026-10-13 16:53:01.040186+05:30
130	partner	Reid Bolin	reid bolin	2026-10-13 16:53:01.046833+05:30
131	partner	Blake Martin	blake martin	2026-10-13 16:53:01.055199+05:30
132	partner	Zay	zay	2026-10-13 16:53:01.061967+05:30
133	partner	Braden	braden	2026-10-13 16:53:01.068971+05:30
134	partner	Zach Witcher	zach witcher	2026-10-13 16:53:01.076988+05:30
135	partner	CB	cb	2026-10-13 16:53:01.083417+05:30
136	partner	Shiv	shiv	2026-10-13 16:53:01.091088+05:30
137	partner	Shiv2	shiv2	2026-10-13 16:53:01.097693+05:30
138	partner	Max	max	2026-10-13 16:53:01.103751+05:30
139	partner	Josh F/Himothy	josh f/himothy	2026-10-13 16:53:01.108943+05:30
140	partner	Josh F/Himothy	josh f/himothy	2026-10-13 16:53:01.114419+05:30
141	partner	Shiv	shiv	2026-10-13 16:53:01.120235+05:30
142	partner	Shiv 2	shiv 2	2026-10-13 16:53:01.125321+05:30
143	partner	Sam Adlakha	sam adlakha	2026-10-13 16:53:01.13078+05:30
144	partner	James & D	james & d	2026-10-13 16:53:01.136237+05:30
145	partner	Noodles	noodles	2026-10-13 16:53:01.141304+05:30
146	partner	Mo's Accounts	mo's accounts	2026-10-13 16:53:01.147008+05:30
147	partner	Mo's 2	mo's 2	2026-10-13 16:53:01.15241+05:30
148	partner	Butters	butters	2026-10-13 16:53:01.158231+05:30
149	partner	Hien 1	hien 1	2026-10-13 16:53:01.165634+05:30
150	partner	Hien 2	hien 2	2026-10-13 16:53:01.173517+05:30
151	partner	Hien 3	hien 3	2026-10-13 16:53:01.179844+05:30
152	partner	Coffee's	coffee's	2026-10-13 16:53:01.187068+05:30
153	partner	Thieu 1	thieu 1	2026-10-13 16:53:01.196923+05:30
154	partner	Ginger	ginger	2026-10-13 16:53:01.203346+05:30
155	partner	Gerard 2	gerard 2	2026-10-13 16:53:01.209842+05:30
156	partner	Rabbit’s Accounts	rabbit’s accounts	2026-10-13 16:53:01.216423+05:30
157	partner	Rabbit’s 2	rabbit’s 2	2026-10-13 16:53:01.222325+05:30
158	partner	Rabbit’s 3	rabbit’s 3	2026-10-13 16:53:01.228665+05:30
159	partner	Hubert	hubert	2026-10-13 16:53:01.235336+05:30
160	partner	John	john	2026-10-13 16:53:01.240808+05:30
161	partner	Jack Proctor	jack proctor	2026-10-13 16:53:01.246042+05:30
162	partner	Ben Freeman	ben freeman	2026-10-13 16:53:01.25135+05:30
163	capper	Green	green	2026-10-13 17:06:08.039205+05:30
164	capper	Lime Green	lime green	2026-10-13 17:06:08.062772+05:30
165	capper	Yellow	yellow	2026-10-13 17:06:08.068785+05:30
166	capper	Light Yellow	light yellow	2026-10-13 17:06:08.074607+05:30
167	capper	Pink	pink	2026-10-13 17:06:08.081428+05:30
168	capper	Light Pink	light pink	2026-10-13 17:06:08.087297+05:30
169	capper	Purple	purple	2026-10-13 17:06:08.094229+05:30
170	capper	Red	red	2026-10-13 17:06:08.102311+05:30
171	capper	Grey	grey	2026-10-13 17:06:08.108979+05:30
172	capper	Black	black	2026-10-13 17:06:08.115266+05:30
173	capper	Orange	orange	2026-10-13 17:06:08.120937+05:30
174	capper	Light Orange	light orange	2026-10-13 17:06:08.127312+05:30
175	capper	Blue	blue	2026-10-13 17:06:08.133065+05:30
176	capper	Turquoise	turquoise	2026-10-13 17:06:08.138894+05:30
177	capper	Teal	teal	2026-10-13 17:06:08.146837+05:30
178	capper	Maroon	maroon	2026-10-13 17:06:08.153991+05:30
181	partner	Luke Sugiyama	luke sugiyama	2026-10-15 14:40:02.270064+05:30
182	partner	Prasad Romijn	prasad romijn	2026-10-15 14:40:02.301947+05:30
183	partner	Anthony	anthony	2026-10-15 14:40:02.318786+05:30
\.


--
-- Data for Name: party_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.party_accounts (id, party_id, account_id, created_at) FROM stdin;
1400	49	565	2026-10-15 11:21:24.106369+05:30
1401	167	565	2026-10-15 11:21:24.106372+05:30
1402	163	565	2026-10-15 11:21:24.106373+05:30
1403	50	566	2026-10-15 11:21:24.142482+05:30
1404	50	567	2026-10-15 11:21:24.154112+05:30
1405	50	568	2026-10-15 11:21:24.166273+05:30
1406	50	569	2026-10-15 11:21:24.178054+05:30
1407	50	570	2026-10-15 11:21:24.189577+05:30
1408	51	571	2026-10-15 11:21:24.203457+05:30
1409	175	571	2026-10-15 11:21:24.20346+05:30
1410	168	571	2026-10-15 11:21:24.203461+05:30
1411	176	571	2026-10-15 11:21:24.203461+05:30
1412	51	572	2026-10-15 11:21:24.217511+05:30
1413	175	572	2026-10-15 11:21:24.217514+05:30
1414	51	573	2026-10-15 11:21:24.232005+05:30
1415	171	573	2026-10-15 11:21:24.232007+05:30
1416	51	574	2026-10-15 11:21:24.247285+05:30
1417	175	574	2026-10-15 11:21:24.247288+05:30
1418	176	574	2026-10-15 11:21:24.247289+05:30
1419	51	575	2026-10-15 11:21:24.261451+05:30
1420	172	575	2026-10-15 11:21:24.261453+05:30
1421	171	575	2026-10-15 11:21:24.261454+05:30
1422	51	576	2026-10-15 11:21:24.280036+05:30
1423	172	576	2026-10-15 11:21:24.280039+05:30
1424	171	576	2026-10-15 11:21:24.280039+05:30
1425	51	577	2026-10-15 11:21:24.294881+05:30
1426	172	577	2026-10-15 11:21:24.294884+05:30
1427	176	577	2026-10-15 11:21:24.294884+05:30
1428	175	577	2026-10-15 11:21:24.294885+05:30
1429	166	577	2026-10-15 11:21:24.294886+05:30
1430	51	578	2026-10-15 11:21:24.310605+05:30
1431	175	578	2026-10-15 11:21:24.310608+05:30
1432	51	579	2026-10-15 11:21:24.324644+05:30
1433	169	579	2026-10-15 11:21:24.324646+05:30
1434	166	579	2026-10-15 11:21:24.324647+05:30
1435	51	580	2026-10-15 11:21:24.340072+05:30
1436	169	580	2026-10-15 11:21:24.340074+05:30
1437	175	580	2026-10-15 11:21:24.340075+05:30
1438	176	580	2026-10-15 11:21:24.340076+05:30
1439	51	581	2026-10-15 11:21:24.35445+05:30
1440	175	581	2026-10-15 11:21:24.354453+05:30
1441	176	581	2026-10-15 11:21:24.354454+05:30
1442	51	582	2026-10-15 11:21:24.370536+05:30
1443	166	582	2026-10-15 11:21:24.370538+05:30
1444	171	582	2026-10-15 11:21:24.370539+05:30
1445	51	583	2026-10-15 11:21:24.38823+05:30
1446	172	583	2026-10-15 11:21:24.388234+05:30
1447	171	583	2026-10-15 11:21:24.388235+05:30
1448	176	583	2026-10-15 11:21:24.388235+05:30
80	1	48	2026-10-13 21:46:39.424985+05:30
81	171	48	2026-10-13 21:46:39.424987+05:30
82	2	49	2026-10-13 21:48:45.54923+05:30
83	171	49	2026-10-13 21:48:45.549232+05:30
84	168	49	2026-10-13 21:48:45.549233+05:30
85	2	50	2026-10-13 21:48:45.578856+05:30
86	171	50	2026-10-13 21:48:45.578859+05:30
87	3	51	2026-10-13 21:51:27.238338+05:30
88	163	51	2026-10-13 21:51:27.23834+05:30
89	168	51	2026-10-13 21:51:27.238341+05:30
90	177	51	2026-10-13 21:55:19.695067+05:30
91	4	52	2026-10-13 22:20:04.159239+05:30
92	164	52	2026-10-13 22:20:04.159242+05:30
93	4	53	2026-10-13 22:20:04.175891+05:30
94	166	53	2026-10-13 22:20:04.175894+05:30
95	4	54	2026-10-13 22:20:04.193159+05:30
96	167	54	2026-10-13 22:20:04.193162+05:30
97	4	55	2026-10-13 22:20:04.208767+05:30
98	167	55	2026-10-13 22:20:04.20877+05:30
99	4	56	2026-10-13 22:20:04.22704+05:30
100	178	56	2026-10-13 22:20:04.227043+05:30
101	4	57	2026-10-13 22:20:04.242639+05:30
102	176	57	2026-10-13 22:20:04.242642+05:30
103	4	58	2026-10-13 22:20:04.262333+05:30
104	176	58	2026-10-13 22:20:04.262335+05:30
105	5	59	2026-10-13 22:25:22.444916+05:30
106	175	59	2026-10-13 22:25:22.444919+05:30
107	6	60	2026-10-13 22:27:44.189023+05:30
108	165	60	2026-10-13 22:27:44.189026+05:30
109	168	60	2026-10-13 22:27:44.189027+05:30
110	6	61	2026-10-13 22:27:44.215836+05:30
111	163	61	2026-10-13 22:27:44.215839+05:30
112	6	62	2026-10-13 22:27:44.294359+05:30
113	163	62	2026-10-13 22:27:44.294361+05:30
114	6	63	2026-10-13 22:27:44.312503+05:30
115	171	63	2026-10-13 22:27:44.312506+05:30
116	6	64	2026-10-13 22:27:44.327341+05:30
117	171	64	2026-10-13 22:27:44.327343+05:30
118	6	65	2026-10-13 22:27:44.342797+05:30
119	171	65	2026-10-13 22:27:44.3428+05:30
120	6	66	2026-10-13 22:27:44.357323+05:30
121	163	66	2026-10-13 22:27:44.357325+05:30
122	174	66	2026-10-13 22:27:44.357326+05:30
123	6	67	2026-10-13 22:27:44.371674+05:30
124	171	67	2026-10-13 22:27:44.371677+05:30
125	168	67	2026-10-13 22:27:44.371678+05:30
126	6	68	2026-10-13 22:27:44.387372+05:30
127	165	68	2026-10-13 22:27:44.387375+05:30
128	168	68	2026-10-13 22:27:44.387375+05:30
129	7	69	2026-10-13 22:37:51.105603+05:30
130	165	69	2026-10-13 22:37:51.105623+05:30
131	7	70	2026-10-13 22:37:51.13124+05:30
132	171	70	2026-10-13 22:37:51.131243+05:30
133	7	71	2026-10-13 22:37:51.151695+05:30
134	169	71	2026-10-13 22:37:51.151698+05:30
135	7	72	2026-10-13 22:37:51.175283+05:30
136	163	72	2026-10-13 22:37:51.175287+05:30
137	8	73	2026-10-13 22:41:02.278073+05:30
138	167	73	2026-10-13 22:41:02.278077+05:30
139	163	73	2026-10-13 22:41:02.278077+05:30
140	9	74	2026-10-13 22:44:08.470242+05:30
141	174	74	2026-10-13 22:44:08.470244+05:30
142	178	74	2026-10-13 22:44:08.470245+05:30
143	9	75	2026-10-13 22:44:08.498407+05:30
144	169	75	2026-10-13 22:44:08.49841+05:30
145	10	76	2026-10-13 22:45:43.317+05:30
146	172	76	2026-10-13 22:45:43.317002+05:30
147	10	77	2026-10-13 22:45:43.34398+05:30
148	175	77	2026-10-13 22:45:43.343983+05:30
149	10	78	2026-10-13 22:45:43.36092+05:30
150	176	78	2026-10-13 22:45:43.360923+05:30
151	10	79	2026-10-13 22:45:43.376168+05:30
152	177	79	2026-10-13 22:45:43.37617+05:30
153	10	80	2026-10-13 22:45:43.395149+05:30
154	171	80	2026-10-13 22:45:43.395152+05:30
155	12	81	2026-10-14 11:58:17.794073+05:30
156	171	81	2026-10-14 11:58:17.794076+05:30
157	174	81	2026-10-14 11:58:17.794077+05:30
158	13	82	2026-10-14 12:13:17.645301+05:30
159	177	82	2026-10-14 12:13:17.645305+05:30
160	13	83	2026-10-14 12:13:17.676853+05:30
161	171	83	2026-10-14 12:13:17.676859+05:30
162	14	84	2026-10-14 13:05:28.473498+05:30
163	172	84	2026-10-14 13:05:28.473502+05:30
164	171	84	2026-10-14 13:05:28.473502+05:30
165	163	84	2026-10-14 13:05:28.473503+05:30
166	14	85	2026-10-14 13:05:28.494146+05:30
167	163	85	2026-10-14 13:05:28.494149+05:30
168	14	86	2026-10-14 13:05:28.516536+05:30
169	171	86	2026-10-14 13:05:28.51654+05:30
170	175	86	2026-10-14 13:05:28.516541+05:30
171	177	86	2026-10-14 13:05:28.516541+05:30
172	172	86	2026-10-14 13:05:28.516542+05:30
173	14	87	2026-10-14 13:05:28.534544+05:30
174	176	87	2026-10-14 13:05:28.534547+05:30
175	14	88	2026-10-14 13:05:28.550331+05:30
176	171	88	2026-10-14 13:05:28.550334+05:30
177	14	89	2026-10-14 13:05:28.567128+05:30
178	169	89	2026-10-14 13:05:28.567131+05:30
179	165	89	2026-10-14 13:05:28.567132+05:30
180	14	90	2026-10-14 13:05:28.583538+05:30
181	176	90	2026-10-14 13:05:28.583541+05:30
182	165	90	2026-10-14 13:05:28.583542+05:30
183	15	91	2026-10-14 13:15:31.284205+05:30
184	168	91	2026-10-14 13:15:31.284208+05:30
185	171	91	2026-10-14 13:15:31.284209+05:30
186	15	92	2026-10-14 13:15:31.311912+05:30
187	174	92	2026-10-14 13:15:31.311915+05:30
188	163	92	2026-10-14 13:15:31.311915+05:30
189	16	93	2026-10-14 14:45:38.7589+05:30
190	167	93	2026-10-14 14:45:38.758905+05:30
191	163	93	2026-10-14 14:45:38.758907+05:30
192	178	93	2026-10-14 14:45:38.758909+05:30
193	174	93	2026-10-14 14:45:38.75891+05:30
194	16	94	2026-10-14 14:45:38.797885+05:30
195	172	94	2026-10-14 14:45:38.797893+05:30
196	16	95	2026-10-14 14:45:38.840372+05:30
197	171	95	2026-10-14 14:45:38.840376+05:30
198	16	96	2026-10-14 14:45:38.863842+05:30
199	166	96	2026-10-14 14:45:38.863847+05:30
200	16	97	2026-10-14 14:45:38.889348+05:30
201	172	97	2026-10-14 14:45:38.889361+05:30
202	171	97	2026-10-14 14:45:38.889362+05:30
203	16	98	2026-10-14 14:45:38.919157+05:30
204	175	98	2026-10-14 14:45:38.91916+05:30
205	16	99	2026-10-14 14:45:38.942558+05:30
206	166	99	2026-10-14 14:45:38.942561+05:30
207	16	100	2026-10-14 14:45:38.968183+05:30
208	171	100	2026-10-14 14:45:38.968186+05:30
209	172	100	2026-10-14 14:45:38.968187+05:30
210	16	101	2026-10-14 14:45:38.986716+05:30
211	171	101	2026-10-14 14:45:38.98672+05:30
212	172	101	2026-10-14 14:45:38.986721+05:30
213	16	102	2026-10-14 14:45:39.010174+05:30
214	171	102	2026-10-14 14:45:39.010178+05:30
215	165	102	2026-10-14 14:45:39.010179+05:30
216	16	103	2026-10-14 14:45:39.0314+05:30
217	169	103	2026-10-14 14:45:39.031404+05:30
218	16	104	2026-10-14 14:45:39.054588+05:30
219	171	104	2026-10-14 14:45:39.054592+05:30
220	16	105	2026-10-14 14:45:39.073805+05:30
221	171	105	2026-10-14 14:45:39.073809+05:30
222	16	106	2026-10-14 14:45:39.089817+05:30
223	177	106	2026-10-14 14:45:39.08982+05:30
224	16	107	2026-10-14 14:45:39.106464+05:30
225	171	107	2026-10-14 14:45:39.106467+05:30
226	16	108	2026-10-14 14:45:39.127922+05:30
227	171	108	2026-10-14 14:45:39.127926+05:30
228	16	109	2026-10-14 14:45:39.158745+05:30
229	177	109	2026-10-14 14:45:39.158749+05:30
230	16	110	2026-10-14 14:45:39.190209+05:30
231	166	110	2026-10-14 14:45:39.19022+05:30
232	169	110	2026-10-14 14:45:39.190221+05:30
233	16	111	2026-10-14 14:45:39.221443+05:30
234	167	111	2026-10-14 14:45:39.221446+05:30
235	16	112	2026-10-14 14:45:39.254435+05:30
236	171	112	2026-10-14 14:45:39.254441+05:30
237	165	112	2026-10-14 14:45:39.254442+05:30
238	16	113	2026-10-14 14:45:39.280912+05:30
239	172	113	2026-10-14 14:45:39.280916+05:30
240	16	114	2026-10-14 14:45:39.305775+05:30
241	171	114	2026-10-14 14:45:39.30578+05:30
242	16	115	2026-10-14 14:45:39.335842+05:30
243	171	115	2026-10-14 14:45:39.335848+05:30
244	16	116	2026-10-14 14:45:39.371324+05:30
245	177	116	2026-10-14 14:45:39.371327+05:30
246	16	117	2026-10-14 14:45:39.39216+05:30
247	171	117	2026-10-14 14:45:39.392164+05:30
248	16	118	2026-10-14 14:45:39.419901+05:30
249	171	118	2026-10-14 14:45:39.419904+05:30
250	16	119	2026-10-14 14:45:39.437913+05:30
251	175	119	2026-10-14 14:45:39.437916+05:30
252	16	120	2026-10-14 14:45:39.455784+05:30
253	170	120	2026-10-14 14:45:39.455787+05:30
254	166	120	2026-10-14 14:45:39.455788+05:30
255	16	121	2026-10-14 14:45:39.477934+05:30
256	174	121	2026-10-14 14:45:39.477937+05:30
257	177	121	2026-10-14 14:45:39.477937+05:30
258	16	122	2026-10-14 14:45:39.50408+05:30
259	171	122	2026-10-14 14:45:39.504084+05:30
260	16	123	2026-10-14 14:45:39.533211+05:30
261	176	123	2026-10-14 14:45:39.533214+05:30
262	16	124	2026-10-14 14:45:39.549973+05:30
263	166	124	2026-10-14 14:45:39.549976+05:30
264	175	124	2026-10-14 14:45:39.549977+05:30
265	16	125	2026-10-14 14:45:39.575492+05:30
266	166	125	2026-10-14 14:45:39.575495+05:30
267	175	125	2026-10-14 14:45:39.575496+05:30
268	16	126	2026-10-14 14:45:39.601983+05:30
269	167	126	2026-10-14 14:45:39.601987+05:30
270	16	127	2026-10-14 14:45:39.635827+05:30
271	167	127	2026-10-14 14:45:39.635831+05:30
272	16	128	2026-10-14 14:45:39.657656+05:30
273	174	128	2026-10-14 14:45:39.657663+05:30
274	163	128	2026-10-14 14:45:39.657665+05:30
275	16	129	2026-10-14 14:45:39.685796+05:30
276	174	129	2026-10-14 14:45:39.6858+05:30
277	167	129	2026-10-14 14:45:39.685801+05:30
278	16	130	2026-10-14 14:45:39.707076+05:30
279	174	130	2026-10-14 14:45:39.707079+05:30
280	16	131	2026-10-14 14:45:39.738677+05:30
281	163	131	2026-10-14 14:45:39.738695+05:30
282	167	131	2026-10-14 14:45:39.738695+05:30
283	16	132	2026-10-14 14:45:39.769364+05:30
284	167	132	2026-10-14 14:45:39.769376+05:30
285	16	133	2026-10-14 14:45:39.793051+05:30
286	167	133	2026-10-14 14:45:39.793055+05:30
287	174	133	2026-10-14 14:45:39.793056+05:30
288	16	134	2026-10-14 14:45:39.819218+05:30
289	165	134	2026-10-14 14:45:39.819222+05:30
290	16	135	2026-10-14 14:45:39.840163+05:30
291	169	135	2026-10-14 14:45:39.840171+05:30
292	167	135	2026-10-14 14:45:39.840172+05:30
293	16	136	2026-10-14 14:45:39.87622+05:30
294	163	136	2026-10-14 14:45:39.876223+05:30
295	16	137	2026-10-14 14:45:39.90115+05:30
296	174	137	2026-10-14 14:45:39.901154+05:30
297	16	138	2026-10-14 14:45:39.925284+05:30
298	165	138	2026-10-14 14:45:39.925288+05:30
299	16	139	2026-10-14 14:45:39.944466+05:30
300	170	139	2026-10-14 14:45:39.94447+05:30
301	167	139	2026-10-14 14:45:39.94447+05:30
302	169	139	2026-10-14 14:45:39.944471+05:30
303	16	140	2026-10-14 14:45:39.971408+05:30
304	170	140	2026-10-14 14:45:39.971412+05:30
305	167	140	2026-10-14 14:45:39.971413+05:30
306	16	141	2026-10-14 14:45:39.991556+05:30
307	163	141	2026-10-14 14:45:39.99156+05:30
308	167	141	2026-10-14 14:45:39.991561+05:30
309	16	142	2026-10-14 14:45:40.02294+05:30
310	163	142	2026-10-14 14:45:40.022943+05:30
311	16	143	2026-10-14 14:45:40.048381+05:30
312	167	143	2026-10-14 14:45:40.048386+05:30
313	16	144	2026-10-14 14:45:40.079016+05:30
314	169	144	2026-10-14 14:45:40.07902+05:30
315	16	145	2026-10-14 14:45:40.105408+05:30
316	170	145	2026-10-14 14:45:40.105412+05:30
317	165	145	2026-10-14 14:45:40.105413+05:30
318	168	145	2026-10-14 14:45:40.105414+05:30
330	16	150	2026-10-14 14:45:40.226635+05:30
331	170	150	2026-10-14 14:45:40.226639+05:30
343	16	155	2026-10-14 14:45:40.338832+05:30
344	175	155	2026-10-14 14:45:40.338835+05:30
345	171	155	2026-10-14 14:45:40.338836+05:30
356	16	160	2026-10-14 14:45:40.435883+05:30
357	172	160	2026-10-14 14:45:40.435886+05:30
358	177	160	2026-10-14 14:45:40.435887+05:30
368	16	165	2026-10-14 14:45:40.524572+05:30
369	171	165	2026-10-14 14:45:40.524574+05:30
380	16	170	2026-10-14 14:45:40.616053+05:30
381	172	170	2026-10-14 14:45:40.616056+05:30
382	165	170	2026-10-14 14:45:40.616057+05:30
1449	51	584	2026-10-15 11:21:24.404589+05:30
1450	168	584	2026-10-15 11:21:24.404594+05:30
1451	171	584	2026-10-15 11:21:24.404595+05:30
1452	52	585	2026-10-15 11:21:24.417834+05:30
1453	52	586	2026-10-15 11:21:24.431546+05:30
1454	53	587	2026-10-15 11:21:24.444469+05:30
1455	169	587	2026-10-15 11:21:24.444472+05:30
1456	165	587	2026-10-15 11:21:24.444472+05:30
1457	171	587	2026-10-15 11:21:24.444473+05:30
1458	53	588	2026-10-15 11:21:24.459229+05:30
1459	176	588	2026-10-15 11:21:24.459232+05:30
1460	166	588	2026-10-15 11:21:24.459232+05:30
1461	53	589	2026-10-15 11:21:24.474127+05:30
1462	166	589	2026-10-15 11:21:24.47413+05:30
1463	165	589	2026-10-15 11:21:24.47413+05:30
1464	171	589	2026-10-15 11:21:24.474131+05:30
1465	53	590	2026-10-15 11:21:24.488565+05:30
1466	172	590	2026-10-15 11:21:24.488568+05:30
1467	169	590	2026-10-15 11:21:24.488568+05:30
1468	171	590	2026-10-15 11:21:24.488569+05:30
1469	53	591	2026-10-15 11:21:24.505463+05:30
1470	165	591	2026-10-15 11:21:24.505468+05:30
1471	170	591	2026-10-15 11:21:24.505469+05:30
1472	53	592	2026-10-15 11:21:24.521425+05:30
1473	171	592	2026-10-15 11:21:24.521428+05:30
1474	53	593	2026-10-15 11:21:24.536992+05:30
1475	172	593	2026-10-15 11:21:24.536995+05:30
1476	171	593	2026-10-15 11:21:24.536996+05:30
1477	53	594	2026-10-15 11:21:24.551255+05:30
1478	168	594	2026-10-15 11:21:24.551258+05:30
1479	171	594	2026-10-15 11:21:24.551258+05:30
1480	53	595	2026-10-15 11:21:24.566483+05:30
1481	172	595	2026-10-15 11:21:24.566486+05:30
1482	171	595	2026-10-15 11:21:24.566487+05:30
1483	53	596	2026-10-15 11:21:24.58087+05:30
1484	169	596	2026-10-15 11:21:24.580873+05:30
1485	165	596	2026-10-15 11:21:24.580874+05:30
1486	166	596	2026-10-15 11:21:24.580874+05:30
1487	53	597	2026-10-15 11:21:24.596021+05:30
1488	175	597	2026-10-15 11:21:24.596023+05:30
1489	169	597	2026-10-15 11:21:24.596024+05:30
1490	53	598	2026-10-15 11:21:24.610523+05:30
1491	170	598	2026-10-15 11:21:24.610525+05:30
1492	54	599	2026-10-15 11:21:24.624231+05:30
1493	54	600	2026-10-15 11:21:24.640015+05:30
1494	54	601	2026-10-15 11:21:24.651408+05:30
1495	55	602	2026-10-15 11:21:24.667034+05:30
1496	175	602	2026-10-15 11:21:24.667039+05:30
1497	171	602	2026-10-15 11:21:24.667039+05:30
1498	168	602	2026-10-15 11:21:24.66704+05:30
1499	56	603	2026-10-15 11:21:24.682088+05:30
1500	172	603	2026-10-15 11:21:24.682091+05:30
1501	171	603	2026-10-15 11:21:24.682092+05:30
1502	56	604	2026-10-15 11:21:24.698443+05:30
1503	172	604	2026-10-15 11:21:24.698446+05:30
1504	171	604	2026-10-15 11:21:24.698446+05:30
1505	57	605	2026-10-15 11:21:24.716501+05:30
1506	163	605	2026-10-15 11:21:24.716504+05:30
1507	57	606	2026-10-15 11:21:24.732549+05:30
1508	171	606	2026-10-15 11:21:24.732552+05:30
1509	168	606	2026-10-15 11:21:24.732553+05:30
1510	57	607	2026-10-15 11:21:24.750878+05:30
1511	168	607	2026-10-15 11:21:24.75088+05:30
1512	163	607	2026-10-15 11:21:24.750881+05:30
1513	57	608	2026-10-15 11:21:24.768843+05:30
1514	171	608	2026-10-15 11:21:24.768845+05:30
1515	57	609	2026-10-15 11:21:24.787492+05:30
1516	171	609	2026-10-15 11:21:24.787495+05:30
1517	57	610	2026-10-15 11:21:24.801474+05:30
1518	165	610	2026-10-15 11:21:24.801476+05:30
1519	57	611	2026-10-15 11:21:24.819118+05:30
1520	163	611	2026-10-15 11:21:24.819121+05:30
1521	58	612	2026-10-15 11:21:24.833858+05:30
1522	174	612	2026-10-15 11:21:24.833861+05:30
1523	163	612	2026-10-15 11:21:24.833861+05:30
1524	58	613	2026-10-15 11:21:24.849119+05:30
1525	176	613	2026-10-15 11:21:24.849122+05:30
1526	171	613	2026-10-15 11:21:24.849122+05:30
1527	58	614	2026-10-15 11:21:24.867233+05:30
1528	175	614	2026-10-15 11:21:24.867235+05:30
1529	58	615	2026-10-15 11:21:24.882556+05:30
1530	174	615	2026-10-15 11:21:24.882559+05:30
1531	58	616	2026-10-15 11:21:24.89828+05:30
1532	171	616	2026-10-15 11:21:24.898283+05:30
1533	58	617	2026-10-15 11:21:24.917754+05:30
1534	169	617	2026-10-15 11:21:24.917757+05:30
1535	58	618	2026-10-15 11:21:24.932911+05:30
1536	171	618	2026-10-15 11:21:24.932915+05:30
1537	168	618	2026-10-15 11:21:24.932915+05:30
1538	58	619	2026-10-15 11:21:24.949025+05:30
1539	171	619	2026-10-15 11:21:24.949028+05:30
1540	59	620	2026-10-15 11:21:24.970873+05:30
1541	171	620	2026-10-15 11:21:24.970877+05:30
1542	59	621	2026-10-15 11:21:24.991508+05:30
1543	171	621	2026-10-15 11:21:24.991512+05:30
1544	175	621	2026-10-15 11:21:24.991512+05:30
1545	59	622	2026-10-15 11:21:25.013522+05:30
1546	175	622	2026-10-15 11:21:25.013525+05:30
1547	59	623	2026-10-15 11:21:25.028349+05:30
1548	171	623	2026-10-15 11:21:25.028351+05:30
1549	59	624	2026-10-15 11:21:25.044618+05:30
1550	171	624	2026-10-15 11:21:25.044621+05:30
1551	172	624	2026-10-15 11:21:25.044621+05:30
1552	59	625	2026-10-15 11:21:25.062024+05:30
1553	176	625	2026-10-15 11:21:25.062027+05:30
1554	59	626	2026-10-15 11:21:25.077903+05:30
1555	172	626	2026-10-15 11:21:25.07791+05:30
1556	169	626	2026-10-15 11:21:25.077911+05:30
1557	60	627	2026-10-15 11:21:25.092782+05:30
1558	175	627	2026-10-15 11:21:25.092785+05:30
1559	176	627	2026-10-15 11:21:25.092785+05:30
1560	60	628	2026-10-15 11:21:25.111718+05:30
1561	172	628	2026-10-15 11:21:25.111721+05:30
1562	171	628	2026-10-15 11:21:25.111722+05:30
1563	60	629	2026-10-15 11:21:25.127053+05:30
1564	172	629	2026-10-15 11:21:25.127064+05:30
1565	60	630	2026-10-15 11:21:25.143016+05:30
1566	166	630	2026-10-15 11:21:25.143019+05:30
1567	61	631	2026-10-15 11:36:51.60383+05:30
1568	172	631	2026-10-15 11:36:51.603832+05:30
1569	176	631	2026-10-15 11:36:51.603833+05:30
1570	61	632	2026-10-15 11:36:51.619567+05:30
1571	172	632	2026-10-15 11:36:51.619569+05:30
1572	168	632	2026-10-15 11:36:51.61957+05:30
1573	171	632	2026-10-15 11:36:51.61957+05:30
1574	62	633	2026-10-15 11:36:51.634531+05:30
1575	166	633	2026-10-15 11:36:51.634533+05:30
1576	62	634	2026-10-15 11:36:51.648393+05:30
1577	171	634	2026-10-15 11:36:51.648396+05:30
1578	62	635	2026-10-15 11:36:51.663003+05:30
1579	172	635	2026-10-15 11:36:51.663005+05:30
1580	177	635	2026-10-15 11:36:51.663006+05:30
1581	62	636	2026-10-15 11:36:51.675776+05:30
1582	63	637	2026-10-15 11:36:51.689112+05:30
1583	168	637	2026-10-15 11:36:51.689115+05:30
1584	63	638	2026-10-15 11:36:51.70341+05:30
1585	175	638	2026-10-15 11:36:51.703413+05:30
1586	63	639	2026-10-15 11:36:51.717837+05:30
1587	166	639	2026-10-15 11:36:51.71784+05:30
1588	63	640	2026-10-15 11:36:51.735773+05:30
1589	175	640	2026-10-15 11:36:51.735776+05:30
319	16	146	2026-10-14 14:45:40.129223+05:30
320	175	146	2026-10-14 14:45:40.129228+05:30
321	177	146	2026-10-14 14:45:40.129228+05:30
332	16	151	2026-10-14 14:45:40.245283+05:30
333	165	151	2026-10-14 14:45:40.245286+05:30
334	171	151	2026-10-14 14:45:40.245287+05:30
346	16	156	2026-10-14 14:45:40.360096+05:30
347	169	156	2026-10-14 14:45:40.360099+05:30
348	172	156	2026-10-14 14:45:40.3601+05:30
359	16	161	2026-10-14 14:45:40.458447+05:30
360	171	161	2026-10-14 14:45:40.45845+05:30
370	16	166	2026-10-14 14:45:40.540085+05:30
371	171	166	2026-10-14 14:45:40.540087+05:30
372	175	166	2026-10-14 14:45:40.540088+05:30
383	16	171	2026-10-14 14:45:40.633961+05:30
384	163	171	2026-10-14 14:45:40.633965+05:30
385	167	171	2026-10-14 14:45:40.633966+05:30
386	178	171	2026-10-14 14:45:40.633966+05:30
1590	63	641	2026-10-15 11:36:51.750164+05:30
1591	176	641	2026-10-15 11:36:51.750167+05:30
1592	63	642	2026-10-15 11:36:51.765281+05:30
1593	172	642	2026-10-15 11:36:51.765284+05:30
1594	63	643	2026-10-15 11:36:51.780193+05:30
1595	172	643	2026-10-15 11:36:51.780196+05:30
1596	63	644	2026-10-15 11:36:51.794869+05:30
1597	176	644	2026-10-15 11:36:51.794872+05:30
1598	63	645	2026-10-15 11:36:51.815173+05:30
1599	175	645	2026-10-15 11:36:51.815175+05:30
1600	63	646	2026-10-15 11:36:51.829902+05:30
1601	163	646	2026-10-15 11:36:51.829905+05:30
1602	63	647	2026-10-15 11:36:51.845633+05:30
1603	176	647	2026-10-15 11:36:51.845637+05:30
1604	172	647	2026-10-15 11:36:51.845638+05:30
1605	63	648	2026-10-15 11:36:51.86383+05:30
1606	163	648	2026-10-15 11:36:51.863832+05:30
1607	167	648	2026-10-15 11:36:51.863833+05:30
1608	63	649	2026-10-15 11:36:51.87858+05:30
1609	163	649	2026-10-15 11:36:51.878582+05:30
1610	169	649	2026-10-15 11:36:51.878583+05:30
1611	63	650	2026-10-15 11:36:51.895228+05:30
1612	178	650	2026-10-15 11:36:51.89523+05:30
1613	63	651	2026-10-15 11:36:51.909715+05:30
1614	167	651	2026-10-15 11:36:51.909718+05:30
1615	163	651	2026-10-15 11:36:51.909718+05:30
1616	63	652	2026-10-15 11:36:51.924028+05:30
1617	163	652	2026-10-15 11:36:51.924031+05:30
1618	63	653	2026-10-15 11:36:51.938563+05:30
1619	163	653	2026-10-15 11:36:51.938566+05:30
1620	63	654	2026-10-15 11:36:51.952376+05:30
1621	164	654	2026-10-15 11:36:51.952379+05:30
1622	63	655	2026-10-15 11:36:51.966605+05:30
1623	168	655	2026-10-15 11:36:51.966608+05:30
1624	63	656	2026-10-15 11:36:51.984759+05:30
1625	166	656	2026-10-15 11:36:51.984762+05:30
1626	63	657	2026-10-15 11:36:52.002238+05:30
1627	165	657	2026-10-15 11:36:52.002241+05:30
1628	176	657	2026-10-15 11:36:52.002242+05:30
1629	63	658	2026-10-15 11:36:52.017174+05:30
1630	172	658	2026-10-15 11:36:52.017176+05:30
1631	63	659	2026-10-15 11:36:52.032051+05:30
1632	163	659	2026-10-15 11:36:52.032054+05:30
1633	63	660	2026-10-15 11:36:52.046438+05:30
1634	168	660	2026-10-15 11:36:52.046441+05:30
1635	63	661	2026-10-15 11:36:52.061308+05:30
1636	176	661	2026-10-15 11:36:52.061311+05:30
1637	63	662	2026-10-15 11:36:52.074649+05:30
1638	165	662	2026-10-15 11:36:52.074651+05:30
1639	168	662	2026-10-15 11:36:52.074652+05:30
1640	63	663	2026-10-15 11:36:52.089088+05:30
1641	172	663	2026-10-15 11:36:52.089091+05:30
1642	63	664	2026-10-15 11:36:52.10699+05:30
1643	172	664	2026-10-15 11:36:52.106993+05:30
1644	63	665	2026-10-15 11:36:52.121252+05:30
1645	172	665	2026-10-15 11:36:52.121256+05:30
1646	63	666	2026-10-15 11:36:52.136096+05:30
1647	168	666	2026-10-15 11:36:52.136099+05:30
1648	177	666	2026-10-15 11:36:52.136099+05:30
1649	63	667	2026-10-15 11:36:52.150503+05:30
1650	172	667	2026-10-15 11:36:52.150506+05:30
1651	63	668	2026-10-15 11:36:52.165326+05:30
1652	167	668	2026-10-15 11:36:52.165328+05:30
1653	63	669	2026-10-15 11:36:52.179388+05:30
1654	165	669	2026-10-15 11:36:52.17939+05:30
1655	168	669	2026-10-15 11:36:52.179391+05:30
1656	63	670	2026-10-15 11:36:52.197597+05:30
1657	175	670	2026-10-15 11:36:52.197599+05:30
1658	63	416	2026-10-15 11:36:52.220108+05:30
1659	172	416	2026-10-15 11:36:52.220111+05:30
1660	63	671	2026-10-15 11:36:52.239742+05:30
1661	167	671	2026-10-15 11:36:52.239745+05:30
1662	178	671	2026-10-15 11:36:52.239746+05:30
1663	63	672	2026-10-15 11:36:52.254868+05:30
1664	175	672	2026-10-15 11:36:52.254871+05:30
1665	64	673	2026-10-15 11:36:52.270804+05:30
1666	171	673	2026-10-15 11:36:52.270807+05:30
1667	172	673	2026-10-15 11:36:52.270808+05:30
1668	176	673	2026-10-15 11:36:52.270809+05:30
1669	65	674	2026-10-15 11:36:52.287735+05:30
1670	175	674	2026-10-15 11:36:52.287738+05:30
1671	65	675	2026-10-15 11:36:52.350212+05:30
1672	167	675	2026-10-15 11:36:52.350215+05:30
1673	163	675	2026-10-15 11:36:52.350216+05:30
1674	65	676	2026-10-15 11:36:52.37118+05:30
1675	175	676	2026-10-15 11:36:52.371183+05:30
1676	65	677	2026-10-15 11:36:52.388536+05:30
1677	176	677	2026-10-15 11:36:52.388538+05:30
1678	66	678	2026-10-15 11:36:52.404033+05:30
1679	176	678	2026-10-15 11:36:52.404036+05:30
1680	166	678	2026-10-15 11:36:52.404036+05:30
1681	170	678	2026-10-15 11:36:52.404037+05:30
1682	66	679	2026-10-15 11:36:52.420122+05:30
1683	177	679	2026-10-15 11:36:52.420125+05:30
1684	67	680	2026-10-15 11:36:52.437975+05:30
1685	165	680	2026-10-15 11:36:52.437978+05:30
1686	175	680	2026-10-15 11:36:52.437978+05:30
1687	176	680	2026-10-15 11:36:52.437979+05:30
1688	68	681	2026-10-15 11:36:52.452548+05:30
1689	172	681	2026-10-15 11:36:52.452551+05:30
1690	68	682	2026-10-15 11:36:52.471498+05:30
1691	176	682	2026-10-15 11:36:52.471501+05:30
1692	172	682	2026-10-15 11:36:52.471502+05:30
1693	68	683	2026-10-15 11:36:52.488716+05:30
1694	168	683	2026-10-15 11:36:52.488719+05:30
1695	68	684	2026-10-15 11:36:52.504827+05:30
1696	177	684	2026-10-15 11:36:52.504829+05:30
1697	175	684	2026-10-15 11:36:52.50483+05:30
1698	68	685	2026-10-15 11:36:52.519603+05:30
1699	172	685	2026-10-15 11:36:52.519607+05:30
1700	175	685	2026-10-15 11:36:52.519607+05:30
1701	68	686	2026-10-15 11:36:52.537433+05:30
1702	172	686	2026-10-15 11:36:52.537436+05:30
1703	175	686	2026-10-15 11:36:52.537436+05:30
1704	68	687	2026-10-15 11:36:52.551667+05:30
1705	172	687	2026-10-15 11:36:52.55167+05:30
1706	168	687	2026-10-15 11:36:52.551671+05:30
1707	68	688	2026-10-15 11:36:52.569848+05:30
1708	172	688	2026-10-15 11:36:52.569852+05:30
1709	165	688	2026-10-15 11:36:52.569853+05:30
1710	70	689	2026-10-15 11:36:52.589674+05:30
1711	171	689	2026-10-15 11:36:52.589677+05:30
1712	70	690	2026-10-15 11:36:52.607337+05:30
1713	163	690	2026-10-15 11:36:52.60734+05:30
1714	168	690	2026-10-15 11:36:52.607341+05:30
1715	70	691	2026-10-15 11:36:52.626505+05:30
1716	163	691	2026-10-15 11:36:52.626509+05:30
1717	71	692	2026-10-15 11:36:52.644843+05:30
1718	176	692	2026-10-15 11:36:52.644846+05:30
1719	72	693	2026-10-15 11:36:52.659354+05:30
1720	172	693	2026-10-15 11:36:52.659357+05:30
1721	72	694	2026-10-15 11:36:52.677111+05:30
1722	175	694	2026-10-15 11:36:52.677114+05:30
1723	163	694	2026-10-15 11:36:52.677115+05:30
1724	166	694	2026-10-15 11:36:52.677115+05:30
1962	174	787	2026-10-15 12:51:30.863846+05:30
1972	110	792	2026-10-15 12:51:30.997877+05:30
1973	165	792	2026-10-15 12:51:30.99788+05:30
1974	168	792	2026-10-15 12:51:30.997881+05:30
322	16	147	2026-10-14 14:45:40.154384+05:30
323	172	147	2026-10-14 14:45:40.15439+05:30
324	171	147	2026-10-14 14:45:40.154391+05:30
335	16	152	2026-10-14 14:45:40.26752+05:30
336	172	152	2026-10-14 14:45:40.267524+05:30
337	166	152	2026-10-14 14:45:40.267525+05:30
349	16	157	2026-10-14 14:45:40.38408+05:30
350	166	157	2026-10-14 14:45:40.384083+05:30
351	168	157	2026-10-14 14:45:40.384084+05:30
361	16	162	2026-10-14 14:45:40.473953+05:30
362	171	162	2026-10-14 14:45:40.473956+05:30
373	16	167	2026-10-14 14:45:40.558884+05:30
374	171	167	2026-10-14 14:45:40.558887+05:30
375	168	167	2026-10-14 14:45:40.558888+05:30
1725	164	694	2026-10-15 11:40:33.605184+05:30
1975	110	793	2026-10-15 12:51:31.020107+05:30
1976	174	793	2026-10-15 12:51:31.02011+05:30
1977	163	793	2026-10-15 12:51:31.020111+05:30
1988	114	798	2026-10-15 12:51:31.118379+05:30
1989	171	798	2026-10-15 12:51:31.118382+05:30
1997	118	803	2026-10-15 12:51:31.202629+05:30
1998	165	803	2026-10-15 12:51:31.202632+05:30
2008	120	808	2026-10-15 12:51:31.29581+05:30
2009	170	808	2026-10-15 12:51:31.295813+05:30
2017	122	813	2026-10-15 12:51:31.388685+05:30
2018	171	813	2026-10-15 12:51:31.388701+05:30
2031	181	818	2026-10-15 14:43:18.492754+05:30
2032	174	818	2026-10-15 14:43:18.492757+05:30
2043	183	823	2026-10-15 14:43:21.790401+05:30
2044	168	823	2026-10-15 14:43:21.790404+05:30
2061	130	832	2026-10-15 14:48:22.389323+05:30
2062	171	832	2026-10-15 14:48:22.389326+05:30
2072	130	837	2026-10-15 14:48:22.491027+05:30
2073	175	837	2026-10-15 14:48:22.49103+05:30
2074	165	837	2026-10-15 14:48:22.491031+05:30
2084	134	842	2026-10-15 14:48:22.594821+05:30
2085	175	842	2026-10-15 14:48:22.594824+05:30
2099	135	847	2026-10-15 14:48:22.737371+05:30
2100	167	847	2026-10-15 14:48:22.737374+05:30
2101	174	847	2026-10-15 14:48:22.737375+05:30
2102	176	847	2026-10-15 14:48:22.737375+05:30
2113	138	852	2026-10-15 14:48:22.836072+05:30
2135	154	863	2026-10-15 15:19:47.392922+05:30
2136	172	863	2026-10-15 15:19:47.392929+05:30
2137	171	863	2026-10-15 15:19:47.39293+05:30
2147	143	868	2026-10-15 15:19:47.516182+05:30
2148	163	868	2026-10-15 15:19:47.516186+05:30
2149	178	868	2026-10-15 15:19:47.516188+05:30
2158	126	873	2026-10-15 15:19:47.635351+05:30
2159	171	873	2026-10-15 15:19:47.635355+05:30
2171	99	45	2026-10-15 15:35:30.055979+05:30
2181	150	882	2026-10-15 15:42:42.43637+05:30
2182	167	882	2026-10-15 15:42:42.436373+05:30
2192	156	886	2026-10-15 15:45:30.583532+05:30
2193	176	886	2026-10-15 15:45:30.583535+05:30
2214	137	854	2026-10-15 15:55:05.594986+05:30
2228	139	897	2026-10-15 15:56:10.011024+05:30
2229	177	897	2026-10-15 15:56:10.011027+05:30
2230	167	897	2026-10-15 15:56:10.011028+05:30
2256	76	906	2026-10-15 16:01:07.389392+05:30
2257	178	906	2026-10-15 16:01:07.389394+05:30
2266	78	910	2026-10-15 16:07:39.795098+05:30
2267	178	910	2026-10-15 16:07:39.795101+05:30
2268	174	910	2026-10-15 16:07:39.795102+05:30
2269	167	910	2026-10-15 16:07:39.795102+05:30
2281	79	915	2026-10-15 16:07:39.878727+05:30
2282	171	915	2026-10-15 16:07:39.87873+05:30
2283	177	915	2026-10-15 16:07:39.87873+05:30
2293	80	920	2026-10-15 16:07:39.963989+05:30
2294	172	920	2026-10-15 16:07:39.963993+05:30
2304	80	925	2026-10-15 16:07:40.046912+05:30
2305	171	925	2026-10-15 16:07:40.046915+05:30
2306	172	925	2026-10-15 16:07:40.046916+05:30
2321	80	930	2026-10-15 16:07:40.133447+05:30
2322	164	930	2026-10-15 16:07:40.13345+05:30
2323	178	930	2026-10-15 16:07:40.133451+05:30
2324	171	930	2026-10-15 16:07:40.133452+05:30
2333	80	935	2026-10-15 16:07:40.211005+05:30
2334	171	935	2026-10-15 16:07:40.211008+05:30
2345	83	940	2026-10-15 16:07:40.286585+05:30
2346	169	940	2026-10-15 16:07:40.286589+05:30
2356	83	945	2026-10-15 16:07:40.376262+05:30
2357	171	945	2026-10-15 16:07:40.376265+05:30
2358	172	945	2026-10-15 16:07:40.376265+05:30
2370	83	950	2026-10-15 16:07:40.458698+05:30
2371	171	950	2026-10-15 16:07:40.458703+05:30
2372	174	950	2026-10-15 16:07:40.458703+05:30
2373	172	950	2026-10-15 16:07:40.458704+05:30
2384	83	955	2026-10-15 16:07:40.536262+05:30
2385	174	955	2026-10-15 16:07:40.536265+05:30
2386	163	955	2026-10-15 16:07:40.536265+05:30
2397	84	960	2026-10-15 16:07:40.67139+05:30
2398	163	960	2026-10-15 16:07:40.671393+05:30
2399	167	960	2026-10-15 16:07:40.671394+05:30
2412	85	965	2026-10-15 16:07:40.746165+05:30
2413	164	965	2026-10-15 16:07:40.746168+05:30
2414	176	965	2026-10-15 16:07:40.746169+05:30
2429	74	970	2026-10-15 16:12:56.60508+05:30
2430	172	970	2026-10-15 16:12:56.605083+05:30
2431	171	970	2026-10-15 16:12:56.605084+05:30
2432	178	970	2026-10-15 16:12:56.605084+05:30
2441	74	975	2026-10-15 16:12:56.690757+05:30
2443	81	977	2026-10-15 16:12:58.684907+05:30
2444	172	977	2026-10-15 16:12:58.684909+05:30
2449	82	979	2026-10-15 16:13:00.70601+05:30
2450	165	979	2026-10-15 16:13:00.706012+05:30
2451	172	979	2026-10-15 16:13:00.706013+05:30
2452	171	979	2026-10-15 16:13:00.706013+05:30
2456	161	981	2026-10-15 16:13:02.700407+05:30
2457	168	981	2026-10-15 16:13:02.70041+05:30
2458	166	981	2026-10-15 16:13:02.70041+05:30
2462	75	28	2026-10-15 16:13:04.675647+05:30
2464	11	984	2026-10-15 16:20:21.482723+05:30
325	16	148	2026-10-14 14:45:40.177458+05:30
326	169	148	2026-10-14 14:45:40.177462+05:30
327	165	148	2026-10-14 14:45:40.177463+05:30
338	16	153	2026-10-14 14:45:40.288899+05:30
339	171	153	2026-10-14 14:45:40.288904+05:30
352	16	158	2026-10-14 14:45:40.402797+05:30
353	171	158	2026-10-14 14:45:40.4028+05:30
363	16	163	2026-10-14 14:45:40.489733+05:30
364	171	163	2026-10-14 14:45:40.489736+05:30
365	172	163	2026-10-14 14:45:40.489737+05:30
376	16	168	2026-10-14 14:45:40.57888+05:30
377	175	168	2026-10-14 14:45:40.578883+05:30
1734	86	698	2026-10-15 12:07:04.606044+05:30
1735	174	698	2026-10-15 12:07:04.606049+05:30
1744	87	703	2026-10-15 12:07:04.73883+05:30
1745	167	703	2026-10-15 12:07:04.738834+05:30
1746	169	703	2026-10-15 12:07:04.738835+05:30
1756	87	708	2026-10-15 12:07:04.898936+05:30
1757	171	708	2026-10-15 12:07:04.89894+05:30
1772	87	713	2026-10-15 12:07:05.008412+05:30
1773	172	713	2026-10-15 12:07:05.008416+05:30
1784	87	718	2026-10-15 12:07:05.093193+05:30
1785	167	718	2026-10-15 12:07:05.093196+05:30
1786	163	718	2026-10-15 12:07:05.093196+05:30
1798	90	723	2026-10-15 12:07:05.176221+05:30
1799	167	723	2026-10-15 12:07:05.176224+05:30
1800	163	723	2026-10-15 12:07:05.176225+05:30
1811	93	728	2026-10-15 12:07:05.258997+05:30
1812	167	728	2026-10-15 12:07:05.258999+05:30
1823	98	733	2026-10-15 12:07:05.335195+05:30
1824	176	733	2026-10-15 12:07:05.335199+05:30
1825	166	733	2026-10-15 12:07:05.335199+05:30
1837	101	738	2026-10-15 12:07:05.410731+05:30
1838	175	738	2026-10-15 12:07:05.410734+05:30
1850	103	743	2026-10-15 12:07:05.490423+05:30
1851	169	743	2026-10-15 12:07:05.490426+05:30
1862	104	748	2026-10-15 12:07:05.574646+05:30
1863	165	748	2026-10-15 12:07:05.57465+05:30
1864	169	748	2026-10-15 12:07:05.57465+05:30
1865	166	748	2026-10-15 12:07:05.574651+05:30
1978	111	794	2026-10-15 12:51:31.039767+05:30
1979	169	794	2026-10-15 12:51:31.03977+05:30
1980	173	794	2026-10-15 12:51:31.039771+05:30
1990	116	799	2026-10-15 12:51:31.135786+05:30
1991	171	799	2026-10-15 12:51:31.135789+05:30
1999	118	804	2026-10-15 12:51:31.219943+05:30
2000	171	804	2026-10-15 12:51:31.219949+05:30
2010	120	809	2026-10-15 12:51:31.312577+05:30
2011	163	809	2026-10-15 12:51:31.31258+05:30
2019	122	814	2026-10-15 12:51:31.408728+05:30
2020	163	814	2026-10-15 12:51:31.408732+05:30
2035	182	820	2026-10-15 14:43:20.164848+05:30
2036	165	820	2026-10-15 14:43:20.164851+05:30
2037	168	820	2026-10-15 14:43:20.164852+05:30
2047	183	825	2026-10-15 14:43:21.821532+05:30
2048	175	825	2026-10-15 14:43:21.821535+05:30
2057	129	830	2026-10-15 14:48:22.353092+05:30
2058	168	830	2026-10-15 14:48:22.353094+05:30
2068	130	835	2026-10-15 14:48:22.448404+05:30
2069	168	835	2026-10-15 14:48:22.448408+05:30
2080	130	840	2026-10-15 14:48:22.548196+05:30
2081	174	840	2026-10-15 14:48:22.5482+05:30
2093	135	845	2026-10-15 14:48:22.680693+05:30
2094	176	845	2026-10-15 14:48:22.680697+05:30
2095	171	845	2026-10-15 14:48:22.680698+05:30
2108	135	850	2026-10-15 14:48:22.796597+05:30
2109	169	850	2026-10-15 14:48:22.7966+05:30
2110	167	850	2026-10-15 14:48:22.7966+05:30
2123	128	858	2026-10-15 15:10:41.606237+05:30
2124	168	858	2026-10-15 15:10:41.60624+05:30
2131	153	861	2026-10-15 15:19:47.343415+05:30
2132	171	861	2026-10-15 15:19:47.343419+05:30
2143	160	866	2026-10-15 15:19:47.466563+05:30
2144	166	866	2026-10-15 15:19:47.466567+05:30
2154	126	871	2026-10-15 15:19:47.589051+05:30
2155	171	871	2026-10-15 15:19:47.589055+05:30
2164	126	876	2026-10-15 15:19:47.704534+05:30
2174	146	879	2026-10-15 15:42:35.527431+05:30
2175	169	879	2026-10-15 15:42:35.527435+05:30
2176	167	879	2026-10-15 15:42:35.527436+05:30
2197	158	888	2026-10-15 15:45:34.789783+05:30
2198	167	888	2026-10-15 15:45:34.789786+05:30
2199	174	888	2026-10-15 15:45:34.789786+05:30
2203	131	890	2026-10-15 15:50:27.682165+05:30
2204	168	890	2026-10-15 15:50:27.682168+05:30
2205	171	890	2026-10-15 15:50:27.682169+05:30
2209	136	892	2026-10-15 15:52:57.617209+05:30
2210	166	892	2026-10-15 15:52:57.617212+05:30
2211	176	892	2026-10-15 15:52:57.617212+05:30
2212	172	892	2026-10-15 15:52:57.617213+05:30
2222	139	895	2026-10-15 15:56:09.972585+05:30
2223	174	895	2026-10-15 15:56:09.972591+05:30
2224	163	895	2026-10-15 15:56:09.972593+05:30
2236	139	900	2026-10-15 15:56:10.063868+05:30
2237	171	900	2026-10-15 15:56:10.063872+05:30
2241	140	902	2026-10-15 15:56:12.260597+05:30
2242	175	902	2026-10-15 15:56:12.260599+05:30
2247	76	904	2026-10-15 16:01:07.357837+05:30
2248	168	904	2026-10-15 16:01:07.35784+05:30
2249	176	904	2026-10-15 16:01:07.357841+05:30
2250	172	904	2026-10-15 16:01:07.357841+05:30
2251	171	904	2026-10-15 16:01:07.357842+05:30
2260	73	908	2026-10-15 16:07:39.755793+05:30
2261	171	908	2026-10-15 16:07:39.755796+05:30
2262	177	908	2026-10-15 16:07:39.755797+05:30
2276	79	913	2026-10-15 16:07:39.845423+05:30
2277	171	913	2026-10-15 16:07:39.845426+05:30
2289	80	918	2026-10-15 16:07:39.928958+05:30
2290	171	918	2026-10-15 16:07:39.928961+05:30
2299	80	923	2026-10-15 16:07:40.014964+05:30
2300	171	923	2026-10-15 16:07:40.014967+05:30
2313	80	928	2026-10-15 16:07:40.101171+05:30
2314	176	928	2026-10-15 16:07:40.101175+05:30
2315	172	928	2026-10-15 16:07:40.101175+05:30
2316	171	928	2026-10-15 16:07:40.101176+05:30
2329	80	933	2026-10-15 16:07:40.180397+05:30
2330	171	933	2026-10-15 16:07:40.1804+05:30
2339	83	938	2026-10-15 16:07:40.255612+05:30
2340	166	938	2026-10-15 16:07:40.255615+05:30
2341	172	938	2026-10-15 16:07:40.255615+05:30
2351	83	943	2026-10-15 16:07:40.345405+05:30
2352	171	943	2026-10-15 16:07:40.345408+05:30
2365	83	948	2026-10-15 16:07:40.422656+05:30
2366	171	948	2026-10-15 16:07:40.422659+05:30
2367	166	948	2026-10-15 16:07:40.42266+05:30
2379	83	953	2026-10-15 16:07:40.504452+05:30
2380	167	953	2026-10-15 16:07:40.504455+05:30
2391	83	958	2026-10-15 16:07:40.586075+05:30
2392	174	958	2026-10-15 16:07:40.586078+05:30
2393	163	958	2026-10-15 16:07:40.586078+05:30
2407	84	963	2026-10-15 16:07:40.716745+05:30
2408	175	963	2026-10-15 16:07:40.716747+05:30
2420	85	931	2026-10-15 16:07:40.794994+05:30
2421	171	931	2026-10-15 16:07:40.794997+05:30
2422	167	931	2026-10-15 16:07:40.794998+05:30
2433	74	971	2026-10-15 16:12:56.630225+05:30
2434	167	971	2026-10-15 16:12:56.630228+05:30
2435	177	971	2026-10-15 16:12:56.630229+05:30
2442	74	976	2026-10-15 16:12:56.705564+05:30
2459	161	982	2026-10-15 16:13:02.71605+05:30
2460	175	982	2026-10-15 16:13:02.716053+05:30
2461	166	982	2026-10-15 16:13:02.716053+05:30
2465	11	985	2026-10-15 16:20:21.494971+05:30
2469	77	987	2026-10-15 16:25:28.657523+05:30
2470	168	987	2026-10-15 16:25:28.657525+05:30
2471	171	987	2026-10-15 16:25:28.657526+05:30
2472	176	987	2026-10-15 16:25:28.657527+05:30
2473	169	987	2026-10-15 16:25:28.657527+05:30
328	16	149	2026-10-14 14:45:40.200169+05:30
329	171	149	2026-10-14 14:45:40.200173+05:30
340	16	154	2026-10-14 14:45:40.316104+05:30
341	172	154	2026-10-14 14:45:40.316107+05:30
342	177	154	2026-10-14 14:45:40.316108+05:30
354	16	159	2026-10-14 14:45:40.420495+05:30
355	172	159	2026-10-14 14:45:40.420499+05:30
366	16	164	2026-10-14 14:45:40.507146+05:30
367	177	164	2026-10-14 14:45:40.507149+05:30
378	16	169	2026-10-14 14:45:40.595708+05:30
379	177	169	2026-10-14 14:45:40.595711+05:30
390	17	172	2026-10-14 15:26:15.267241+05:30
391	176	172	2026-10-14 15:26:15.267244+05:30
392	17	173	2026-10-14 15:26:15.285924+05:30
393	172	173	2026-10-14 15:26:15.285927+05:30
394	177	173	2026-10-14 15:26:15.285928+05:30
395	17	174	2026-10-14 15:26:15.3016+05:30
396	163	174	2026-10-14 15:26:15.301603+05:30
397	171	174	2026-10-14 15:26:15.301603+05:30
398	17	175	2026-10-14 15:26:15.318772+05:30
399	163	175	2026-10-14 15:26:15.318775+05:30
400	174	175	2026-10-14 15:26:15.318776+05:30
401	17	176	2026-10-14 15:26:15.334528+05:30
402	176	176	2026-10-14 15:26:15.334531+05:30
403	17	177	2026-10-14 15:26:15.34933+05:30
404	177	177	2026-10-14 15:26:15.349332+05:30
405	17	178	2026-10-14 15:26:15.366379+05:30
406	176	178	2026-10-14 15:26:15.366383+05:30
407	18	179	2026-10-14 15:26:15.383448+05:30
408	167	179	2026-10-14 15:26:15.383452+05:30
409	174	179	2026-10-14 15:26:15.383452+05:30
410	19	180	2026-10-14 15:26:15.400471+05:30
411	166	180	2026-10-14 15:26:15.400474+05:30
412	20	181	2026-10-14 15:26:15.414789+05:30
413	172	181	2026-10-14 15:26:15.414792+05:30
414	20	182	2026-10-14 15:26:15.429727+05:30
415	174	182	2026-10-14 15:26:15.42973+05:30
416	163	182	2026-10-14 15:26:15.42973+05:30
417	20	183	2026-10-14 15:26:15.444533+05:30
418	174	183	2026-10-14 15:26:15.444536+05:30
419	163	183	2026-10-14 15:26:15.444536+05:30
420	167	183	2026-10-14 15:26:15.444537+05:30
421	20	184	2026-10-14 15:26:15.460163+05:30
422	171	184	2026-10-14 15:26:15.460166+05:30
423	172	184	2026-10-14 15:26:15.460166+05:30
424	20	185	2026-10-14 15:26:15.474615+05:30
425	171	185	2026-10-14 15:26:15.474618+05:30
426	172	185	2026-10-14 15:26:15.474619+05:30
427	20	186	2026-10-14 15:26:15.490592+05:30
428	172	186	2026-10-14 15:26:15.490595+05:30
429	171	186	2026-10-14 15:26:15.490596+05:30
430	162	185	2026-10-14 15:42:42.0822+05:30
431	162	177	2026-10-14 15:48:05.031189+05:30
432	22	187	2026-10-14 15:57:43.153207+05:30
433	172	187	2026-10-14 15:57:43.153211+05:30
434	22	188	2026-10-14 15:57:43.183616+05:30
435	22	189	2026-10-14 15:57:43.21421+05:30
436	172	189	2026-10-14 15:57:43.214214+05:30
437	24	190	2026-10-14 15:57:43.291627+05:30
438	163	190	2026-10-14 15:57:43.291633+05:30
439	24	191	2026-10-14 15:57:43.318023+05:30
440	171	191	2026-10-14 15:57:43.318027+05:30
441	24	192	2026-10-14 15:57:43.342753+05:30
442	171	192	2026-10-14 15:57:43.342757+05:30
443	168	192	2026-10-14 15:57:43.342758+05:30
444	25	193	2026-10-14 15:57:43.364457+05:30
445	167	193	2026-10-14 15:57:43.364461+05:30
446	163	193	2026-10-14 15:57:43.364462+05:30
447	172	193	2026-10-14 15:57:43.364463+05:30
448	26	194	2026-10-14 15:57:43.386017+05:30
449	163	194	2026-10-14 15:57:43.386021+05:30
450	26	195	2026-10-14 15:57:43.406311+05:30
451	163	195	2026-10-14 15:57:43.406315+05:30
452	26	196	2026-10-14 15:57:43.429872+05:30
453	166	196	2026-10-14 15:57:43.429876+05:30
454	175	196	2026-10-14 15:57:43.429877+05:30
455	35	29	2026-10-14 16:45:29.424499+05:30
1727	86	695	2026-10-15 12:07:04.511653+05:30
457	35	30	2026-10-14 16:45:29.449329+05:30
1728	163	695	2026-10-15 12:07:04.511656+05:30
459	35	31	2026-10-14 16:45:29.475472+05:30
1729	176	695	2026-10-15 12:07:04.511657+05:30
461	35	32	2026-10-14 16:45:29.493207+05:30
1738	87	700	2026-10-15 12:07:04.660587+05:30
463	35	33	2026-10-14 16:45:29.520509+05:30
1739	171	700	2026-10-15 12:07:04.660593+05:30
465	35	34	2026-10-14 16:45:29.544446+05:30
1749	87	705	2026-10-15 12:07:04.798055+05:30
467	35	35	2026-10-14 16:45:29.560279+05:30
1750	171	705	2026-10-15 12:07:04.798059+05:30
469	35	36	2026-10-14 16:45:29.579506+05:30
1761	87	710	2026-10-15 12:07:04.938609+05:30
471	35	37	2026-10-14 16:45:29.596646+05:30
1762	176	710	2026-10-15 12:07:04.938612+05:30
473	35	38	2026-10-14 16:45:29.616287+05:30
1763	171	710	2026-10-15 12:07:04.938613+05:30
475	35	39	2026-10-14 16:45:29.635476+05:30
1764	172	710	2026-10-15 12:07:04.938614+05:30
477	27	197	2026-10-14 16:45:29.839233+05:30
478	175	197	2026-10-14 16:45:29.839236+05:30
479	27	198	2026-10-14 16:45:29.856805+05:30
480	175	198	2026-10-14 16:45:29.856808+05:30
481	27	199	2026-10-14 16:45:29.87239+05:30
482	27	200	2026-10-14 16:45:29.888744+05:30
483	167	200	2026-10-14 16:45:29.888747+05:30
484	27	201	2026-10-14 16:45:29.905842+05:30
485	176	201	2026-10-14 16:45:29.905845+05:30
486	27	202	2026-10-14 16:45:29.923932+05:30
487	167	202	2026-10-14 16:45:29.923935+05:30
488	163	202	2026-10-14 16:45:29.923935+05:30
489	27	203	2026-10-14 16:45:29.940374+05:30
490	176	203	2026-10-14 16:45:29.940376+05:30
491	168	203	2026-10-14 16:45:29.940377+05:30
492	27	204	2026-10-14 16:45:29.957752+05:30
493	167	204	2026-10-14 16:45:29.957755+05:30
494	163	204	2026-10-14 16:45:29.957756+05:30
495	27	205	2026-10-14 16:45:29.979417+05:30
496	163	205	2026-10-14 16:45:29.979423+05:30
497	27	206	2026-10-14 16:45:30.003172+05:30
498	167	206	2026-10-14 16:45:30.003176+05:30
499	169	206	2026-10-14 16:45:30.003176+05:30
500	28	207	2026-10-14 16:45:30.022023+05:30
501	172	207	2026-10-14 16:45:30.022027+05:30
502	169	207	2026-10-14 16:45:30.022027+05:30
503	28	208	2026-10-14 16:45:30.041094+05:30
504	171	208	2026-10-14 16:45:30.041097+05:30
505	165	208	2026-10-14 16:45:30.041098+05:30
506	28	209	2026-10-14 16:45:30.05893+05:30
507	175	209	2026-10-14 16:45:30.058933+05:30
508	171	209	2026-10-14 16:45:30.058934+05:30
509	29	210	2026-10-14 16:45:30.07767+05:30
510	167	210	2026-10-14 16:45:30.077674+05:30
511	29	211	2026-10-14 16:45:30.131311+05:30
512	171	211	2026-10-14 16:45:30.131316+05:30
513	29	212	2026-10-14 16:45:30.157608+05:30
514	163	212	2026-10-14 16:45:30.157613+05:30
515	29	213	2026-10-14 16:45:30.179752+05:30
516	167	213	2026-10-14 16:45:30.179756+05:30
517	29	214	2026-10-14 16:45:30.202708+05:30
518	171	214	2026-10-14 16:45:30.202712+05:30
519	175	214	2026-10-14 16:45:30.202713+05:30
520	29	215	2026-10-14 16:45:30.222163+05:30
521	176	215	2026-10-14 16:45:30.222167+05:30
522	30	216	2026-10-14 16:45:30.240314+05:30
523	171	216	2026-10-14 16:45:30.240317+05:30
524	177	216	2026-10-14 16:45:30.240318+05:30
525	163	216	2026-10-14 16:45:30.240319+05:30
526	30	217	2026-10-14 16:45:30.26446+05:30
527	171	217	2026-10-14 16:45:30.264464+05:30
528	174	217	2026-10-14 16:45:30.264465+05:30
529	31	218	2026-10-14 16:45:30.282732+05:30
530	178	218	2026-10-14 16:45:30.282735+05:30
531	163	218	2026-10-14 16:45:30.282736+05:30
532	32	219	2026-10-14 16:45:30.301999+05:30
533	167	219	2026-10-14 16:45:30.302002+05:30
534	163	219	2026-10-14 16:45:30.302003+05:30
542	34	224	2026-10-14 16:45:30.396863+05:30
543	172	224	2026-10-14 16:45:30.396866+05:30
553	34	229	2026-10-14 16:45:30.4978+05:30
554	172	229	2026-10-14 16:45:30.497804+05:30
1730	86	696	2026-10-15 12:07:04.551915+05:30
1731	163	696	2026-10-15 12:07:04.551919+05:30
1740	87	701	2026-10-15 12:07:04.685806+05:30
1741	171	701	2026-10-15 12:07:04.685809+05:30
1751	87	706	2026-10-15 12:07:04.836768+05:30
1752	176	706	2026-10-15 12:07:04.836772+05:30
1753	177	706	2026-10-15 12:07:04.836773+05:30
1765	87	711	2026-10-15 12:07:04.963111+05:30
1766	177	711	2026-10-15 12:07:04.963115+05:30
1767	171	711	2026-10-15 12:07:04.963116+05:30
1768	172	711	2026-10-15 12:07:04.963116+05:30
1779	87	716	2026-10-15 12:07:05.058763+05:30
1780	163	716	2026-10-15 12:07:05.058766+05:30
1792	89	721	2026-10-15 12:07:05.141829+05:30
1793	165	721	2026-10-15 12:07:05.141832+05:30
1794	176	721	2026-10-15 12:07:05.141832+05:30
1806	92	726	2026-10-15 12:07:05.229054+05:30
1807	165	726	2026-10-15 12:07:05.229056+05:30
1808	166	726	2026-10-15 12:07:05.229057+05:30
1816	96	731	2026-10-15 12:07:05.302016+05:30
1817	168	731	2026-10-15 12:07:05.30202+05:30
1831	100	736	2026-10-15 12:07:05.379335+05:30
1832	171	736	2026-10-15 12:07:05.379338+05:30
1844	103	741	2026-10-15 12:07:05.460282+05:30
1845	165	741	2026-10-15 12:07:05.460285+05:30
1856	104	746	2026-10-15 12:07:05.535392+05:30
1857	176	746	2026-10-15 12:07:05.535395+05:30
1872	105	751	2026-10-15 12:07:05.62529+05:30
1873	168	751	2026-10-15 12:07:05.625292+05:30
1984	112	796	2026-10-15 12:51:31.076304+05:30
1985	171	796	2026-10-15 12:51:31.076308+05:30
1993	116	801	2026-10-15 12:51:31.167665+05:30
1994	163	801	2026-10-15 12:51:31.167667+05:30
2004	118	806	2026-10-15 12:51:31.25953+05:30
2005	171	806	2026-10-15 12:51:31.259533+05:30
2014	121	811	2026-10-15 12:51:31.34725+05:30
2024	124	816	2026-10-15 12:51:31.441768+05:30
2025	169	816	2026-10-15 12:51:31.441771+05:30
2026	167	816	2026-10-15 12:51:31.441771+05:30
2027	163	816	2026-10-15 12:51:31.441772+05:30
2038	182	821	2026-10-15 14:43:20.183405+05:30
2039	168	821	2026-10-15 14:43:20.183408+05:30
2049	183	826	2026-10-15 14:43:21.83545+05:30
2050	171	826	2026-10-15 14:43:21.835453+05:30
2053	127	828	2026-10-15 14:48:22.299804+05:30
2054	169	828	2026-10-15 14:48:22.299807+05:30
2063	130	833	2026-10-15 14:48:22.409522+05:30
2064	171	833	2026-10-15 14:48:22.409525+05:30
2065	163	833	2026-10-15 14:48:22.409526+05:30
2075	130	838	2026-10-15 14:48:22.510797+05:30
2076	168	838	2026-10-15 14:48:22.510801+05:30
2077	171	838	2026-10-15 14:48:22.510801+05:30
2086	134	843	2026-10-15 14:48:22.620867+05:30
2087	171	843	2026-10-15 14:48:22.620871+05:30
2103	135	848	2026-10-15 14:48:22.759644+05:30
2104	166	848	2026-10-15 14:48:22.759648+05:30
2105	171	848	2026-10-15 14:48:22.759648+05:30
2114	142	853	2026-10-15 14:48:22.848179+05:30
2116	109	855	2026-10-15 15:01:13.866091+05:30
2117	177	855	2026-10-15 15:01:13.866096+05:30
2125	144	859	2026-10-15 15:19:47.292625+05:30
2126	168	859	2026-10-15 15:19:47.292629+05:30
2127	171	859	2026-10-15 15:19:47.29263+05:30
2138	159	864	2026-10-15 15:19:47.416149+05:30
2139	171	864	2026-10-15 15:19:47.416154+05:30
2150	143	869	2026-10-15 15:19:47.539452+05:30
2151	171	869	2026-10-15 15:19:47.539457+05:30
2160	126	874	2026-10-15 15:19:47.658459+05:30
2161	163	874	2026-10-15 15:19:47.658463+05:30
2165	160	877	2026-10-15 15:26:47.679009+05:30
2166	168	877	2026-10-15 15:26:47.679012+05:30
2167	171	877	2026-10-15 15:26:47.679012+05:30
2172	86	483	2026-10-15 15:39:37.205251+05:30
2177	147	880	2026-10-15 15:42:37.612397+05:30
2178	170	880	2026-10-15 15:42:37.6124+05:30
2186	152	884	2026-10-15 15:45:26.877217+05:30
2187	168	884	2026-10-15 15:45:26.87722+05:30
2188	177	884	2026-10-15 15:45:26.877221+05:30
2189	172	884	2026-10-15 15:45:26.877222+05:30
2206	136	891	2026-10-15 15:52:57.601371+05:30
2207	171	891	2026-10-15 15:52:57.601374+05:30
2208	175	891	2026-10-15 15:52:57.601375+05:30
2219	139	894	2026-10-15 15:56:09.952309+05:30
2220	168	894	2026-10-15 15:56:09.952311+05:30
2221	163	894	2026-10-15 15:56:09.952312+05:30
2233	139	899	2026-10-15 15:56:10.047958+05:30
2234	169	899	2026-10-15 15:56:10.047962+05:30
2235	165	899	2026-10-15 15:56:10.047963+05:30
2238	140	901	2026-10-15 15:56:12.243756+05:30
2239	169	901	2026-10-15 15:56:12.243759+05:30
2240	165	901	2026-10-15 15:56:12.24376+05:30
2258	73	907	2026-10-15 16:07:39.729064+05:30
2259	163	907	2026-10-15 16:07:39.729067+05:30
2272	79	912	2026-10-15 16:07:39.829268+05:30
2273	172	912	2026-10-15 16:07:39.82927+05:30
2274	171	912	2026-10-15 16:07:39.829271+05:30
2275	177	912	2026-10-15 16:07:39.829271+05:30
2287	80	917	2026-10-15 16:07:39.909522+05:30
2288	163	917	2026-10-15 16:07:39.909525+05:30
2297	80	922	2026-10-15 16:07:39.997281+05:30
2298	172	922	2026-10-15 16:07:39.997284+05:30
2310	80	927	2026-10-15 16:07:40.082238+05:30
2311	175	927	2026-10-15 16:07:40.082241+05:30
2312	165	927	2026-10-15 16:07:40.082242+05:30
2327	80	932	2026-10-15 16:07:40.16392+05:30
2328	171	932	2026-10-15 16:07:40.163923+05:30
2337	83	937	2026-10-15 16:07:40.240586+05:30
2338	172	937	2026-10-15 16:07:40.240589+05:30
2349	83	942	2026-10-15 16:07:40.329214+05:30
2350	171	942	2026-10-15 16:07:40.329217+05:30
2362	83	947	2026-10-15 16:07:40.406796+05:30
2363	171	947	2026-10-15 16:07:40.406798+05:30
2364	166	947	2026-10-15 16:07:40.406799+05:30
2376	83	952	2026-10-15 16:07:40.489361+05:30
2377	171	952	2026-10-15 16:07:40.489363+05:30
2378	166	952	2026-10-15 16:07:40.489364+05:30
2389	83	957	2026-10-15 16:07:40.570451+05:30
2390	174	957	2026-10-15 16:07:40.570453+05:30
2404	84	962	2026-10-15 16:07:40.701771+05:30
2405	163	962	2026-10-15 16:07:40.701773+05:30
2406	171	962	2026-10-15 16:07:40.701774+05:30
2417	85	967	2026-10-15 16:07:40.777702+05:30
2418	168	967	2026-10-15 16:07:40.777705+05:30
2419	171	967	2026-10-15 16:07:40.777706+05:30
2436	74	972	2026-10-15 16:12:56.647502+05:30
2437	167	972	2026-10-15 16:12:56.647505+05:30
2438	163	972	2026-10-15 16:12:56.647506+05:30
2466	11	986	2026-10-15 16:20:21.510793+05:30
2474	77	988	2026-10-15 16:25:28.687024+05:30
2475	175	988	2026-10-15 16:25:28.687027+05:30
535	32	220	2026-10-14 16:45:30.320233+05:30
536	167	220	2026-10-14 16:45:30.320236+05:30
544	34	225	2026-10-14 16:45:30.416818+05:30
545	172	225	2026-10-14 16:45:30.416822+05:30
546	171	225	2026-10-14 16:45:30.416823+05:30
555	34	230	2026-10-14 16:45:30.517069+05:30
556	171	230	2026-10-14 16:45:30.517072+05:30
557	166	230	2026-10-14 16:45:30.517073+05:30
1732	86	697	2026-10-15 12:07:04.58044+05:30
1733	163	697	2026-10-15 12:07:04.580444+05:30
1742	87	702	2026-10-15 12:07:04.708032+05:30
1743	167	702	2026-10-15 12:07:04.708036+05:30
1754	87	707	2026-10-15 12:07:04.870732+05:30
1755	171	707	2026-10-15 12:07:04.870737+05:30
1769	87	712	2026-10-15 12:07:04.984162+05:30
1770	171	712	2026-10-15 12:07:04.984166+05:30
1771	172	712	2026-10-15 12:07:04.984167+05:30
1781	87	717	2026-10-15 12:07:05.076703+05:30
1782	163	717	2026-10-15 12:07:05.076707+05:30
1783	170	717	2026-10-15 12:07:05.076707+05:30
1795	90	722	2026-10-15 12:07:05.159847+05:30
1796	165	722	2026-10-15 12:07:05.15985+05:30
1797	174	722	2026-10-15 12:07:05.159851+05:30
1809	92	727	2026-10-15 12:07:05.24437+05:30
1810	176	727	2026-10-15 12:07:05.244373+05:30
1818	97	732	2026-10-15 12:07:05.316742+05:30
1819	168	732	2026-10-15 12:07:05.316745+05:30
1820	173	732	2026-10-15 12:07:05.316746+05:30
1821	175	732	2026-10-15 12:07:05.316747+05:30
1822	166	732	2026-10-15 12:07:05.316747+05:30
1833	100	737	2026-10-15 12:07:05.394902+05:30
1834	176	737	2026-10-15 12:07:05.394905+05:30
1835	164	737	2026-10-15 12:07:05.394906+05:30
1836	169	737	2026-10-15 12:07:05.394906+05:30
1846	103	742	2026-10-15 12:07:05.475954+05:30
1847	174	742	2026-10-15 12:07:05.475958+05:30
1848	163	742	2026-10-15 12:07:05.475959+05:30
1849	167	742	2026-10-15 12:07:05.475959+05:30
1858	104	747	2026-10-15 12:07:05.549785+05:30
1859	170	747	2026-10-15 12:07:05.549788+05:30
1860	168	747	2026-10-15 12:07:05.549789+05:30
1861	172	747	2026-10-15 12:07:05.549789+05:30
1986	113	797	2026-10-15 12:51:31.096591+05:30
1987	163	797	2026-10-15 12:51:31.096594+05:30
1995	117	802	2026-10-15 12:51:31.184359+05:30
1996	169	802	2026-10-15 12:51:31.184362+05:30
2006	119	807	2026-10-15 12:51:31.278399+05:30
2007	171	807	2026-10-15 12:51:31.278402+05:30
2015	122	812	2026-10-15 12:51:31.369905+05:30
2016	169	812	2026-10-15 12:51:31.369908+05:30
2028	125	817	2026-10-15 12:51:31.459537+05:30
2029	163	817	2026-10-15 12:51:31.45954+05:30
2040	182	822	2026-10-15 14:43:20.199961+05:30
2041	176	822	2026-10-15 14:43:20.199964+05:30
2042	170	822	2026-10-15 14:43:20.199964+05:30
2051	183	827	2026-10-15 14:43:21.850428+05:30
2052	176	827	2026-10-15 14:43:21.850431+05:30
2055	127	829	2026-10-15 14:48:22.336881+05:30
2056	171	829	2026-10-15 14:48:22.336883+05:30
2066	130	834	2026-10-15 14:48:22.431898+05:30
2067	171	834	2026-10-15 14:48:22.431901+05:30
2078	130	839	2026-10-15 14:48:22.53296+05:30
2079	163	839	2026-10-15 14:48:22.532963+05:30
2088	135	844	2026-10-15 14:48:22.646507+05:30
2089	167	844	2026-10-15 14:48:22.646511+05:30
2090	163	844	2026-10-15 14:48:22.646512+05:30
2091	178	844	2026-10-15 14:48:22.646513+05:30
2092	174	844	2026-10-15 14:48:22.646514+05:30
2106	135	849	2026-10-15 14:48:22.781675+05:30
2107	174	849	2026-10-15 14:48:22.781678+05:30
2115	142	854	2026-10-15 14:48:22.864457+05:30
2118	109	856	2026-10-15 15:01:13.886936+05:30
2119	167	856	2026-10-15 15:01:13.88694+05:30
2120	178	856	2026-10-15 15:01:13.886941+05:30
2121	128	857	2026-10-15 15:10:41.585495+05:30
2122	168	857	2026-10-15 15:10:41.585499+05:30
2128	145	860	2026-10-15 15:19:47.319379+05:30
2129	178	860	2026-10-15 15:19:47.319384+05:30
2130	174	860	2026-10-15 15:19:47.319386+05:30
2140	148	865	2026-10-15 15:19:47.443569+05:30
2141	171	865	2026-10-15 15:19:47.443573+05:30
2142	166	865	2026-10-15 15:19:47.443574+05:30
2152	126	870	2026-10-15 15:19:47.56409+05:30
2153	168	870	2026-10-15 15:19:47.564094+05:30
2162	126	875	2026-10-15 15:19:47.683299+05:30
2163	163	875	2026-10-15 15:19:47.683303+05:30
2173	86	439	2026-10-15 15:39:37.234302+05:30
2183	151	883	2026-10-15 15:42:44.711528+05:30
2184	167	883	2026-10-15 15:42:44.711532+05:30
2185	174	883	2026-10-15 15:42:44.711533+05:30
2194	157	887	2026-10-15 15:45:32.938934+05:30
2195	174	887	2026-10-15 15:45:32.938937+05:30
2196	167	887	2026-10-15 15:45:32.938937+05:30
2200	133	889	2026-10-15 15:48:27.45546+05:30
2201	175	889	2026-10-15 15:48:27.455463+05:30
2202	173	889	2026-10-15 15:48:27.455464+05:30
2213	137	853	2026-10-15 15:55:05.585208+05:30
2225	139	896	2026-10-15 15:56:09.99003+05:30
2226	165	896	2026-10-15 15:56:09.990033+05:30
2227	175	896	2026-10-15 15:56:09.990034+05:30
2243	140	903	2026-10-15 15:56:12.277191+05:30
2244	165	903	2026-10-15 15:56:12.277194+05:30
2245	169	903	2026-10-15 15:56:12.277195+05:30
2246	170	903	2026-10-15 15:56:12.277195+05:30
2252	76	905	2026-10-15 16:01:07.373588+05:30
2253	165	905	2026-10-15 16:01:07.373591+05:30
2254	171	905	2026-10-15 16:01:07.373592+05:30
2255	175	905	2026-10-15 16:01:07.373592+05:30
2263	73	909	2026-10-15 16:07:39.774244+05:30
2264	168	909	2026-10-15 16:07:39.774247+05:30
2265	171	909	2026-10-15 16:07:39.774248+05:30
2278	79	914	2026-10-15 16:07:39.860619+05:30
2279	176	914	2026-10-15 16:07:39.860622+05:30
2280	171	914	2026-10-15 16:07:39.860623+05:30
2291	80	919	2026-10-15 16:07:39.944517+05:30
2292	171	919	2026-10-15 16:07:39.94452+05:30
2301	80	924	2026-10-15 16:07:40.031633+05:30
2302	177	924	2026-10-15 16:07:40.031635+05:30
2303	171	924	2026-10-15 16:07:40.031636+05:30
2317	80	929	2026-10-15 16:07:40.118387+05:30
2318	171	929	2026-10-15 16:07:40.11839+05:30
2319	168	929	2026-10-15 16:07:40.11839+05:30
2320	172	929	2026-10-15 16:07:40.118391+05:30
2331	80	934	2026-10-15 16:07:40.19539+05:30
2332	163	934	2026-10-15 16:07:40.195393+05:30
2342	83	939	2026-10-15 16:07:40.271736+05:30
2343	172	939	2026-10-15 16:07:40.271739+05:30
2344	171	939	2026-10-15 16:07:40.27174+05:30
2353	83	944	2026-10-15 16:07:40.361285+05:30
2354	171	944	2026-10-15 16:07:40.361287+05:30
2355	166	944	2026-10-15 16:07:40.361288+05:30
2368	83	949	2026-10-15 16:07:40.442394+05:30
2369	172	949	2026-10-15 16:07:40.442397+05:30
2381	83	954	2026-10-15 16:07:40.521007+05:30
2382	174	954	2026-10-15 16:07:40.52101+05:30
2383	167	954	2026-10-15 16:07:40.521011+05:30
2394	83	959	2026-10-15 16:07:40.652774+05:30
2395	167	959	2026-10-15 16:07:40.652777+05:30
2396	163	959	2026-10-15 16:07:40.652778+05:30
2409	85	964	2026-10-15 16:07:40.731147+05:30
2410	165	964	2026-10-15 16:07:40.73115+05:30
2411	169	964	2026-10-15 16:07:40.731151+05:30
537	33	221	2026-10-14 16:45:30.340406+05:30
547	34	226	2026-10-14 16:45:30.437255+05:30
548	171	226	2026-10-14 16:45:30.437259+05:30
558	34	231	2026-10-14 16:45:30.534525+05:30
559	171	231	2026-10-14 16:45:30.534528+05:30
1736	86	699	2026-10-15 12:07:04.629167+05:30
1737	163	699	2026-10-15 12:07:04.62917+05:30
1747	87	704	2026-10-15 12:07:04.769387+05:30
1748	177	704	2026-10-15 12:07:04.769391+05:30
1758	87	709	2026-10-15 12:07:04.91991+05:30
1759	177	709	2026-10-15 12:07:04.919913+05:30
1760	171	709	2026-10-15 12:07:04.919914+05:30
1774	87	714	2026-10-15 12:07:05.025078+05:30
1775	166	714	2026-10-15 12:07:05.025081+05:30
1787	88	719	2026-10-15 12:07:05.111067+05:30
1788	167	719	2026-10-15 12:07:05.11107+05:30
1789	169	719	2026-10-15 12:07:05.111071+05:30
1801	91	724	2026-10-15 12:07:05.195135+05:30
1802	171	724	2026-10-15 12:07:05.195139+05:30
1813	93	729	2026-10-15 12:07:05.273089+05:30
1826	98	734	2026-10-15 12:07:05.3502+05:30
1827	176	734	2026-10-15 12:07:05.350204+05:30
1828	166	734	2026-10-15 12:07:05.350204+05:30
1839	102	739	2026-10-15 12:07:05.430021+05:30
1840	168	739	2026-10-15 12:07:05.430024+05:30
1841	175	739	2026-10-15 12:07:05.430024+05:30
1852	103	744	2026-10-15 12:07:05.505723+05:30
1853	165	744	2026-10-15 12:07:05.505725+05:30
1866	105	749	2026-10-15 12:07:05.594897+05:30
1867	165	749	2026-10-15 12:07:05.5949+05:30
1868	176	749	2026-10-15 12:07:05.5949+05:30
1992	116	800	2026-10-15 12:51:31.150984+05:30
2001	118	805	2026-10-15 12:51:31.239053+05:30
2002	171	805	2026-10-15 12:51:31.239057+05:30
2003	168	805	2026-10-15 12:51:31.239058+05:30
2012	120	810	2026-10-15 12:51:31.331648+05:30
2013	165	810	2026-10-15 12:51:31.331651+05:30
2021	124	815	2026-10-15 12:51:31.423953+05:30
2022	165	815	2026-10-15 12:51:31.423956+05:30
2023	174	815	2026-10-15 12:51:31.423957+05:30
2423	74	968	2026-10-15 16:12:56.568783+05:30
2424	172	968	2026-10-15 16:12:56.568787+05:30
2425	171	968	2026-10-15 16:12:56.568787+05:30
2439	74	973	2026-10-15 16:12:56.66494+05:30
2467	23	46	2026-10-15 16:20:29.764366+05:30
538	34	222	2026-10-14 16:45:30.35774+05:30
539	177	222	2026-10-14 16:45:30.357743+05:30
549	34	227	2026-10-14 16:45:30.457073+05:30
550	177	227	2026-10-14 16:45:30.457077+05:30
560	34	232	2026-10-14 16:45:30.553718+05:30
561	177	232	2026-10-14 16:45:30.553721+05:30
1776	87	715	2026-10-15 12:07:05.039454+05:30
1777	165	715	2026-10-15 12:07:05.039459+05:30
1778	174	715	2026-10-15 12:07:05.03946+05:30
1790	88	720	2026-10-15 12:07:05.126575+05:30
1791	176	720	2026-10-15 12:07:05.126578+05:30
1803	91	725	2026-10-15 12:07:05.213542+05:30
1804	178	725	2026-10-15 12:07:05.213545+05:30
1805	163	725	2026-10-15 12:07:05.213545+05:30
1814	94	730	2026-10-15 12:07:05.286436+05:30
1815	171	730	2026-10-15 12:07:05.28644+05:30
1829	98	735	2026-10-15 12:07:05.364254+05:30
1830	170	735	2026-10-15 12:07:05.364257+05:30
1842	103	740	2026-10-15 12:07:05.445587+05:30
1843	170	740	2026-10-15 12:07:05.44559+05:30
1854	103	745	2026-10-15 12:07:05.520047+05:30
1855	171	745	2026-10-15 12:07:05.52005+05:30
1869	105	750	2026-10-15 12:07:05.610716+05:30
1870	171	750	2026-10-15 12:07:05.610718+05:30
1871	168	750	2026-10-15 12:07:05.610719+05:30
2030	173	816	2026-10-15 14:12:14.077617+05:30
2033	182	819	2026-10-15 14:43:20.134703+05:30
2034	171	819	2026-10-15 14:43:20.134707+05:30
2045	183	824	2026-10-15 14:43:21.805565+05:30
2046	165	824	2026-10-15 14:43:21.805568+05:30
2059	130	831	2026-10-15 14:48:22.373343+05:30
2060	168	831	2026-10-15 14:48:22.373346+05:30
2070	130	836	2026-10-15 14:48:22.4752+05:30
2071	171	836	2026-10-15 14:48:22.475203+05:30
2082	132	841	2026-10-15 14:48:22.579298+05:30
2083	168	841	2026-10-15 14:48:22.5793+05:30
2096	135	846	2026-10-15 14:48:22.710171+05:30
2097	172	846	2026-10-15 14:48:22.710174+05:30
2098	171	846	2026-10-15 14:48:22.710175+05:30
2111	135	851	2026-10-15 14:48:22.819802+05:30
2112	176	851	2026-10-15 14:48:22.819806+05:30
2133	154	862	2026-10-15 15:19:47.367388+05:30
2134	177	862	2026-10-15 15:19:47.367394+05:30
2145	143	867	2026-10-15 15:19:47.490464+05:30
2146	174	867	2026-10-15 15:19:47.490467+05:30
2156	126	872	2026-10-15 15:19:47.613026+05:30
2157	168	872	2026-10-15 15:19:47.613029+05:30
2168	106	878	2026-10-15 15:35:28.203523+05:30
2169	175	878	2026-10-15 15:35:28.203527+05:30
2170	173	878	2026-10-15 15:35:28.203527+05:30
2179	149	881	2026-10-15 15:42:40.033272+05:30
2180	171	881	2026-10-15 15:42:40.033278+05:30
2190	155	885	2026-10-15 15:45:28.778281+05:30
2191	176	885	2026-10-15 15:45:28.778283+05:30
2215	139	893	2026-10-15 15:56:09.936098+05:30
2216	174	893	2026-10-15 15:56:09.936101+05:30
2217	163	893	2026-10-15 15:56:09.936102+05:30
2218	178	893	2026-10-15 15:56:09.936102+05:30
2231	139	898	2026-10-15 15:56:10.031117+05:30
2232	178	898	2026-10-15 15:56:10.031121+05:30
2270	79	911	2026-10-15 16:07:39.811716+05:30
2271	176	911	2026-10-15 16:07:39.811719+05:30
2284	80	916	2026-10-15 16:07:39.894303+05:30
2285	172	916	2026-10-15 16:07:39.894306+05:30
2286	166	916	2026-10-15 16:07:39.894307+05:30
2295	80	921	2026-10-15 16:07:39.981092+05:30
2296	171	921	2026-10-15 16:07:39.981094+05:30
2307	80	926	2026-10-15 16:07:40.063226+05:30
2308	172	926	2026-10-15 16:07:40.063229+05:30
2309	171	926	2026-10-15 16:07:40.06323+05:30
2325	80	931	2026-10-15 16:07:40.149127+05:30
2326	176	931	2026-10-15 16:07:40.14913+05:30
2335	80	936	2026-10-15 16:07:40.225553+05:30
2336	172	936	2026-10-15 16:07:40.225556+05:30
2347	83	941	2026-10-15 16:07:40.306781+05:30
2348	166	941	2026-10-15 16:07:40.306784+05:30
2359	83	946	2026-10-15 16:07:40.392123+05:30
2360	171	946	2026-10-15 16:07:40.392126+05:30
2361	172	946	2026-10-15 16:07:40.392127+05:30
2374	83	951	2026-10-15 16:07:40.473697+05:30
2375	171	951	2026-10-15 16:07:40.473704+05:30
2387	83	956	2026-10-15 16:07:40.555515+05:30
2388	167	956	2026-10-15 16:07:40.555518+05:30
2400	84	961	2026-10-15 16:07:40.686593+05:30
2401	163	961	2026-10-15 16:07:40.686595+05:30
2402	167	961	2026-10-15 16:07:40.686596+05:30
2403	178	961	2026-10-15 16:07:40.686597+05:30
2415	85	966	2026-10-15 16:07:40.761308+05:30
2416	176	966	2026-10-15 16:07:40.761311+05:30
2426	74	969	2026-10-15 16:12:56.585279+05:30
2427	172	969	2026-10-15 16:12:56.585283+05:30
2428	171	969	2026-10-15 16:12:56.585284+05:30
2440	74	974	2026-10-15 16:12:56.677988+05:30
2445	82	978	2026-10-15 16:13:00.679398+05:30
2446	172	978	2026-10-15 16:13:00.679401+05:30
2447	166	978	2026-10-15 16:13:00.679401+05:30
2448	171	978	2026-10-15 16:13:00.679402+05:30
2453	161	980	2026-10-15 16:13:02.673615+05:30
2454	163	980	2026-10-15 16:13:02.673617+05:30
2455	167	980	2026-10-15 16:13:02.673618+05:30
2463	11	983	2026-10-15 16:20:21.469696+05:30
2468	23	47	2026-10-15 16:20:29.785971+05:30
540	34	223	2026-10-14 16:45:30.378541+05:30
541	171	223	2026-10-14 16:45:30.378545+05:30
551	34	228	2026-10-14 16:45:30.478233+05:30
552	172	228	2026-10-14 16:45:30.478237+05:30
609	36	233	2026-10-14 17:03:32.934371+05:30
610	176	233	2026-10-14 17:03:32.934376+05:30
611	171	233	2026-10-14 17:03:32.934377+05:30
612	36	234	2026-10-14 17:03:32.958422+05:30
613	172	234	2026-10-14 17:03:32.958425+05:30
614	37	235	2026-10-14 17:03:32.977091+05:30
615	37	236	2026-10-14 17:03:32.992314+05:30
616	37	237	2026-10-14 17:03:33.008134+05:30
617	39	238	2026-10-14 17:03:33.028467+05:30
618	165	238	2026-10-14 17:03:33.028472+05:30
619	39	239	2026-10-14 17:03:33.047606+05:30
620	165	239	2026-10-14 17:03:33.04761+05:30
621	163	239	2026-10-14 17:03:33.047611+05:30
622	39	240	2026-10-14 17:03:33.067152+05:30
623	175	240	2026-10-14 17:03:33.067155+05:30
624	39	241	2026-10-14 17:03:33.085389+05:30
625	171	241	2026-10-14 17:03:33.085393+05:30
626	39	242	2026-10-14 17:03:33.104759+05:30
627	175	242	2026-10-14 17:03:33.104763+05:30
628	168	242	2026-10-14 17:03:33.104764+05:30
629	39	243	2026-10-14 17:03:33.122698+05:30
630	165	243	2026-10-14 17:03:33.122702+05:30
631	39	244	2026-10-14 17:03:33.143263+05:30
632	171	244	2026-10-14 17:03:33.143268+05:30
633	39	245	2026-10-14 17:03:33.163421+05:30
634	171	245	2026-10-14 17:03:33.163425+05:30
635	168	245	2026-10-14 17:03:33.163426+05:30
636	177	245	2026-10-14 17:03:33.163427+05:30
637	39	246	2026-10-14 17:03:33.182152+05:30
638	177	246	2026-10-14 17:03:33.182156+05:30
639	175	246	2026-10-14 17:03:33.182157+05:30
640	39	247	2026-10-14 17:03:33.258449+05:30
641	171	247	2026-10-14 17:03:33.258453+05:30
642	39	248	2026-10-14 17:03:33.292419+05:30
643	175	248	2026-10-14 17:03:33.292426+05:30
644	39	249	2026-10-14 17:03:33.325096+05:30
645	165	249	2026-10-14 17:03:33.325102+05:30
646	39	250	2026-10-14 17:03:33.348645+05:30
647	169	250	2026-10-14 17:03:33.348649+05:30
648	39	251	2026-10-14 17:03:33.373867+05:30
649	170	251	2026-10-14 17:03:33.373871+05:30
650	40	252	2026-10-14 17:03:33.394721+05:30
651	168	252	2026-10-14 17:03:33.394729+05:30
652	40	253	2026-10-14 17:03:33.416548+05:30
653	163	253	2026-10-14 17:03:33.416552+05:30
654	174	253	2026-10-14 17:03:33.416553+05:30
655	38	254	2026-10-14 17:03:33.435956+05:30
656	167	254	2026-10-14 17:03:33.43596+05:30
657	163	254	2026-10-14 17:03:33.435961+05:30
658	43	255	2026-10-14 17:03:33.454541+05:30
659	44	256	2026-10-14 17:03:33.471499+05:30
660	163	256	2026-10-14 17:03:33.471503+05:30
661	167	256	2026-10-14 17:03:33.471504+05:30
662	44	257	2026-10-14 17:03:33.491624+05:30
663	168	257	2026-10-14 17:03:33.491628+05:30
664	165	257	2026-10-14 17:03:33.491629+05:30
665	163	257	2026-10-14 17:03:33.49163+05:30
666	44	258	2026-10-14 17:03:33.510883+05:30
667	171	258	2026-10-14 17:03:33.510888+05:30
668	165	258	2026-10-14 17:03:33.510889+05:30
669	45	259	2026-10-14 17:03:33.530984+05:30
670	175	259	2026-10-14 17:03:33.530988+05:30
671	166	259	2026-10-14 17:03:33.530989+05:30
672	45	260	2026-10-14 17:03:33.549767+05:30
673	163	260	2026-10-14 17:03:33.54977+05:30
674	45	261	2026-10-14 17:03:33.568411+05:30
675	168	261	2026-10-14 17:03:33.568415+05:30
676	45	262	2026-10-14 17:03:33.588039+05:30
677	176	262	2026-10-14 17:03:33.588043+05:30
678	45	263	2026-10-14 17:03:33.606645+05:30
679	175	263	2026-10-14 17:03:33.606649+05:30
680	45	264	2026-10-14 17:03:33.628386+05:30
681	175	264	2026-10-14 17:03:33.628391+05:30
682	45	265	2026-10-14 17:03:33.646149+05:30
683	176	265	2026-10-14 17:03:33.646152+05:30
684	45	266	2026-10-14 17:03:33.66468+05:30
685	175	266	2026-10-14 17:03:33.664684+05:30
686	45	267	2026-10-14 17:03:33.682434+05:30
687	176	267	2026-10-14 17:03:33.682437+05:30
688	45	268	2026-10-14 17:03:33.70141+05:30
689	168	268	2026-10-14 17:03:33.701413+05:30
690	45	269	2026-10-14 17:03:33.719341+05:30
691	175	269	2026-10-14 17:03:33.719345+05:30
692	45	270	2026-10-14 17:03:33.740097+05:30
693	175	270	2026-10-14 17:03:33.740102+05:30
694	45	271	2026-10-14 17:03:33.758539+05:30
695	167	271	2026-10-14 17:03:33.758542+05:30
696	45	272	2026-10-14 17:03:33.777311+05:30
697	169	272	2026-10-14 17:03:33.777315+05:30
698	176	272	2026-10-14 17:03:33.777316+05:30
699	45	273	2026-10-14 17:03:33.798552+05:30
700	176	273	2026-10-14 17:03:33.798556+05:30
701	45	274	2026-10-14 17:03:33.817568+05:30
702	175	274	2026-10-14 17:03:33.817572+05:30
703	177	274	2026-10-14 17:03:33.817573+05:30
704	45	275	2026-10-14 17:03:33.836586+05:30
705	163	275	2026-10-14 17:03:33.83659+05:30
706	45	276	2026-10-14 17:03:33.855987+05:30
707	163	276	2026-10-14 17:03:33.85599+05:30
708	45	277	2026-10-14 17:03:33.87709+05:30
709	175	277	2026-10-14 17:03:33.877094+05:30
710	45	278	2026-10-14 17:03:33.895842+05:30
711	169	278	2026-10-14 17:03:33.895845+05:30
712	45	279	2026-10-14 17:03:33.916091+05:30
713	163	279	2026-10-14 17:03:33.916094+05:30
714	45	280	2026-10-14 17:03:33.934178+05:30
715	177	280	2026-10-14 17:03:33.934181+05:30
725	45	285	2026-10-14 17:03:34.031115+05:30
726	163	285	2026-10-14 17:03:34.031119+05:30
727	167	285	2026-10-14 17:03:34.031119+05:30
737	45	290	2026-10-14 17:03:34.128559+05:30
738	172	290	2026-10-14 17:03:34.128564+05:30
749	45	295	2026-10-14 17:03:34.227897+05:30
750	177	295	2026-10-14 17:03:34.227901+05:30
751	175	295	2026-10-14 17:03:34.227902+05:30
761	45	300	2026-10-14 17:03:34.323762+05:30
762	163	300	2026-10-14 17:03:34.323766+05:30
763	169	300	2026-10-14 17:03:34.323766+05:30
773	45	305	2026-10-14 17:03:34.423448+05:30
774	177	305	2026-10-14 17:03:34.423451+05:30
775	165	305	2026-10-14 17:03:34.423452+05:30
786	45	310	2026-10-14 17:03:34.520762+05:30
787	175	310	2026-10-14 17:03:34.520766+05:30
788	177	310	2026-10-14 17:03:34.520767+05:30
799	45	315	2026-10-14 17:03:34.615206+05:30
800	177	315	2026-10-14 17:03:34.615209+05:30
813	45	320	2026-10-14 17:03:34.709693+05:30
814	163	320	2026-10-14 17:03:34.709697+05:30
815	165	320	2026-10-14 17:03:34.709697+05:30
826	45	325	2026-10-14 17:03:34.804153+05:30
827	168	325	2026-10-14 17:03:34.804156+05:30
828	164	325	2026-10-14 17:03:34.804157+05:30
839	45	330	2026-10-14 17:03:34.899846+05:30
840	176	330	2026-10-14 17:03:34.89985+05:30
852	45	335	2026-10-14 17:03:35.000132+05:30
853	163	335	2026-10-14 17:03:35.000136+05:30
862	45	340	2026-10-14 17:03:35.105143+05:30
863	169	340	2026-10-14 17:03:35.105146+05:30
864	177	340	2026-10-14 17:03:35.105147+05:30
875	45	345	2026-10-14 17:03:35.207005+05:30
876	168	345	2026-10-14 17:03:35.207008+05:30
877	163	345	2026-10-14 17:03:35.207009+05:30
887	45	350	2026-10-14 17:03:35.315187+05:30
888	177	350	2026-10-14 17:03:35.315191+05:30
897	45	355	2026-10-14 17:03:35.418088+05:30
898	176	355	2026-10-14 17:03:35.418092+05:30
911	45	360	2026-10-14 17:03:35.522561+05:30
912	172	360	2026-10-14 17:03:35.522566+05:30
922	45	365	2026-10-14 17:03:35.623492+05:30
923	168	365	2026-10-14 17:03:35.623495+05:30
924	177	365	2026-10-14 17:03:35.623496+05:30
933	45	370	2026-10-14 17:03:35.718887+05:30
934	172	370	2026-10-14 17:03:35.718891+05:30
944	45	375	2026-10-14 17:03:35.813308+05:30
945	168	375	2026-10-14 17:03:35.813312+05:30
955	45	380	2026-10-14 17:03:35.911496+05:30
956	172	380	2026-10-14 17:03:35.911501+05:30
967	45	385	2026-10-14 17:03:36.009266+05:30
968	177	385	2026-10-14 17:03:36.009269+05:30
969	175	385	2026-10-14 17:03:36.00927+05:30
979	45	390	2026-10-14 17:03:36.107968+05:30
980	177	390	2026-10-14 17:03:36.107972+05:30
990	45	395	2026-10-14 17:03:36.205443+05:30
991	168	395	2026-10-14 17:03:36.205447+05:30
1002	45	400	2026-10-14 17:03:36.302716+05:30
1003	166	400	2026-10-14 17:03:36.30272+05:30
1012	45	405	2026-10-14 17:03:36.395313+05:30
1013	163	405	2026-10-14 17:03:36.395317+05:30
1023	45	410	2026-10-14 17:03:36.492644+05:30
1024	163	410	2026-10-14 17:03:36.492648+05:30
1036	45	415	2026-10-14 17:03:36.589925+05:30
1037	175	415	2026-10-14 17:03:36.589928+05:30
1038	177	415	2026-10-14 17:03:36.589929+05:30
1050	45	420	2026-10-14 17:03:36.686917+05:30
1051	167	420	2026-10-14 17:03:36.686921+05:30
1064	45	425	2026-10-14 17:03:36.782622+05:30
1065	166	425	2026-10-14 17:03:36.782625+05:30
1074	45	430	2026-10-14 17:03:36.876466+05:30
1075	175	430	2026-10-14 17:03:36.876469+05:30
1086	45	435	2026-10-14 17:03:36.970542+05:30
1087	168	435	2026-10-14 17:03:36.970545+05:30
1088	177	435	2026-10-14 17:03:36.970546+05:30
1099	45	440	2026-10-14 17:03:37.06661+05:30
1100	168	440	2026-10-14 17:03:37.066613+05:30
1109	45	445	2026-10-14 17:03:37.159139+05:30
1110	177	445	2026-10-14 17:03:37.159142+05:30
1111	163	445	2026-10-14 17:03:37.159143+05:30
1121	45	450	2026-10-14 17:03:37.254273+05:30
1122	175	450	2026-10-14 17:03:37.254276+05:30
1134	45	455	2026-10-14 17:03:37.34805+05:30
1135	177	455	2026-10-14 17:03:37.348054+05:30
1147	45	460	2026-10-14 17:03:37.444632+05:30
1148	177	460	2026-10-14 17:03:37.444636+05:30
1149	165	460	2026-10-14 17:03:37.444637+05:30
1158	45	465	2026-10-14 17:03:37.539083+05:30
1159	177	465	2026-10-14 17:03:37.539086+05:30
1170	45	470	2026-10-14 17:03:37.634564+05:30
1171	172	470	2026-10-14 17:03:37.634568+05:30
1180	45	475	2026-10-14 17:03:37.730287+05:30
1181	175	475	2026-10-14 17:03:37.730291+05:30
1182	177	475	2026-10-14 17:03:37.730292+05:30
1183	166	475	2026-10-14 17:03:37.730293+05:30
1197	45	480	2026-10-14 17:03:37.827786+05:30
1198	175	480	2026-10-14 17:03:37.82779+05:30
1199	177	480	2026-10-14 17:03:37.82779+05:30
1210	45	485	2026-10-14 17:03:37.953652+05:30
1211	163	485	2026-10-14 17:03:37.953656+05:30
1212	165	485	2026-10-14 17:03:37.953657+05:30
1224	45	490	2026-10-14 17:03:38.064117+05:30
1225	166	490	2026-10-14 17:03:38.064123+05:30
1235	45	495	2026-10-14 17:03:38.165072+05:30
1236	163	495	2026-10-14 17:03:38.165076+05:30
1245	45	500	2026-10-14 17:03:38.260562+05:30
1246	166	500	2026-10-14 17:03:38.260566+05:30
1258	45	505	2026-10-14 17:03:38.358615+05:30
1259	165	505	2026-10-14 17:03:38.358618+05:30
1268	45	510	2026-10-14 17:03:38.455908+05:30
1269	176	510	2026-10-14 17:03:38.455911+05:30
1279	45	515	2026-10-14 17:03:38.553306+05:30
1280	172	515	2026-10-14 17:03:38.55331+05:30
1281	169	515	2026-10-14 17:03:38.553311+05:30
1291	45	520	2026-10-14 17:03:38.680624+05:30
1292	176	520	2026-10-14 17:03:38.680628+05:30
1293	175	520	2026-10-14 17:03:38.680629+05:30
1303	45	525	2026-10-14 17:03:38.779323+05:30
1304	175	525	2026-10-14 17:03:38.779327+05:30
1305	165	525	2026-10-14 17:03:38.779328+05:30
1314	45	530	2026-10-14 17:03:38.878004+05:30
1315	163	530	2026-10-14 17:03:38.878008+05:30
1323	45	535	2026-10-14 17:03:38.97447+05:30
1324	177	535	2026-10-14 17:03:38.974474+05:30
1334	45	540	2026-10-14 17:03:39.071184+05:30
1335	165	540	2026-10-14 17:03:39.071187+05:30
1347	45	545	2026-10-14 17:03:39.171447+05:30
1348	168	545	2026-10-14 17:03:39.171454+05:30
1358	45	550	2026-10-14 17:03:39.27589+05:30
1359	167	550	2026-10-14 17:03:39.275894+05:30
1360	163	550	2026-10-14 17:03:39.275895+05:30
1370	46	555	2026-10-14 17:03:39.367876+05:30
1371	166	555	2026-10-14 17:03:39.36788+05:30
1384	48	560	2026-10-14 17:03:39.463868+05:30
1385	165	560	2026-10-14 17:03:39.463872+05:30
1386	175	560	2026-10-14 17:03:39.463873+05:30
1874	163	750	2026-10-15 12:43:31.445847+05:30
1883	109	756	2026-10-15 12:51:30.077681+05:30
1884	175	756	2026-10-15 12:51:30.077685+05:30
1894	109	761	2026-10-15 12:51:30.212842+05:30
1895	169	761	2026-10-15 12:51:30.212846+05:30
1904	109	766	2026-10-15 12:51:30.335135+05:30
1905	169	766	2026-10-15 12:51:30.33514+05:30
1906	171	766	2026-10-15 12:51:30.335142+05:30
1918	109	771	2026-10-15 12:51:30.452612+05:30
1919	168	771	2026-10-15 12:51:30.452616+05:30
1920	169	771	2026-10-15 12:51:30.452617+05:30
1921	165	771	2026-10-15 12:51:30.452618+05:30
1934	109	776	2026-10-15 12:51:30.595557+05:30
1935	163	776	2026-10-15 12:51:30.595561+05:30
1947	109	781	2026-10-15 12:51:30.730997+05:30
1948	171	781	2026-10-15 12:51:30.731001+05:30
1959	109	786	2026-10-15 12:51:30.842759+05:30
1960	174	786	2026-10-15 12:51:30.842764+05:30
1970	109	791	2026-10-15 12:51:30.973523+05:30
1971	177	791	2026-10-15 12:51:30.973527+05:30
716	45	281	2026-10-14 17:03:33.953471+05:30
717	167	281	2026-10-14 17:03:33.953475+05:30
718	163	281	2026-10-14 17:03:33.953475+05:30
728	45	286	2026-10-14 17:03:34.050722+05:30
729	177	286	2026-10-14 17:03:34.050726+05:30
739	45	291	2026-10-14 17:03:34.149038+05:30
740	172	291	2026-10-14 17:03:34.149042+05:30
741	165	291	2026-10-14 17:03:34.149042+05:30
742	166	291	2026-10-14 17:03:34.149043+05:30
752	45	296	2026-10-14 17:03:34.247687+05:30
753	177	296	2026-10-14 17:03:34.247691+05:30
754	175	296	2026-10-14 17:03:34.247692+05:30
764	45	301	2026-10-14 17:03:34.346043+05:30
765	172	301	2026-10-14 17:03:34.346049+05:30
776	45	306	2026-10-14 17:03:34.442263+05:30
777	177	306	2026-10-14 17:03:34.442267+05:30
789	45	311	2026-10-14 17:03:34.538249+05:30
790	175	311	2026-10-14 17:03:34.538252+05:30
791	177	311	2026-10-14 17:03:34.538253+05:30
801	45	316	2026-10-14 17:03:34.634113+05:30
802	165	316	2026-10-14 17:03:34.634116+05:30
803	177	316	2026-10-14 17:03:34.634117+05:30
816	45	321	2026-10-14 17:03:34.727793+05:30
817	168	321	2026-10-14 17:03:34.727797+05:30
818	163	321	2026-10-14 17:03:34.727798+05:30
829	45	326	2026-10-14 17:03:34.822252+05:30
830	168	326	2026-10-14 17:03:34.822255+05:30
831	163	326	2026-10-14 17:03:34.822256+05:30
841	45	331	2026-10-14 17:03:34.921269+05:30
842	169	331	2026-10-14 17:03:34.921274+05:30
843	167	331	2026-10-14 17:03:34.921275+05:30
854	45	336	2026-10-14 17:03:35.02218+05:30
855	167	336	2026-10-14 17:03:35.022184+05:30
865	45	341	2026-10-14 17:03:35.125188+05:30
866	168	341	2026-10-14 17:03:35.125191+05:30
878	45	346	2026-10-14 17:03:35.230661+05:30
879	163	346	2026-10-14 17:03:35.230665+05:30
889	45	351	2026-10-14 17:03:35.336801+05:30
890	175	351	2026-10-14 17:03:35.336805+05:30
899	45	356	2026-10-14 17:03:35.439813+05:30
900	168	356	2026-10-14 17:03:35.439817+05:30
901	163	356	2026-10-14 17:03:35.439817+05:30
913	45	361	2026-10-14 17:03:35.543935+05:30
914	176	361	2026-10-14 17:03:35.543939+05:30
925	45	366	2026-10-14 17:03:35.642432+05:30
926	165	366	2026-10-14 17:03:35.642435+05:30
935	45	371	2026-10-14 17:03:35.736979+05:30
936	168	371	2026-10-14 17:03:35.736982+05:30
946	45	376	2026-10-14 17:03:35.834986+05:30
947	172	376	2026-10-14 17:03:35.834989+05:30
957	45	381	2026-10-14 17:03:35.932046+05:30
958	175	381	2026-10-14 17:03:35.93205+05:30
959	177	381	2026-10-14 17:03:35.93205+05:30
970	45	386	2026-10-14 17:03:36.031344+05:30
971	177	386	2026-10-14 17:03:36.031347+05:30
981	45	391	2026-10-14 17:03:36.128276+05:30
982	168	391	2026-10-14 17:03:36.128281+05:30
983	175	391	2026-10-14 17:03:36.128282+05:30
992	45	396	2026-10-14 17:03:36.223846+05:30
993	163	396	2026-10-14 17:03:36.223849+05:30
1004	45	401	2026-10-14 17:03:36.321067+05:30
1005	175	401	2026-10-14 17:03:36.32107+05:30
1014	45	406	2026-10-14 17:03:36.414907+05:30
1015	172	406	2026-10-14 17:03:36.41491+05:30
1025	45	411	2026-10-14 17:03:36.513166+05:30
1026	168	411	2026-10-14 17:03:36.51317+05:30
1027	177	411	2026-10-14 17:03:36.513171+05:30
1039	45	416	2026-10-14 17:03:36.60811+05:30
1040	177	416	2026-10-14 17:03:36.608114+05:30
1041	175	416	2026-10-14 17:03:36.608115+05:30
1052	45	421	2026-10-14 17:03:36.705972+05:30
1053	163	421	2026-10-14 17:03:36.705975+05:30
1066	45	426	2026-10-14 17:03:36.801124+05:30
1067	163	426	2026-10-14 17:03:36.801127+05:30
1076	45	431	2026-10-14 17:03:36.89418+05:30
1077	174	431	2026-10-14 17:03:36.894183+05:30
1089	45	436	2026-10-14 17:03:36.991564+05:30
1090	169	436	2026-10-14 17:03:36.991568+05:30
1101	45	441	2026-10-14 17:03:37.085503+05:30
1102	175	441	2026-10-14 17:03:37.085507+05:30
1112	45	446	2026-10-14 17:03:37.177538+05:30
1113	175	446	2026-10-14 17:03:37.177541+05:30
1114	177	446	2026-10-14 17:03:37.177542+05:30
1123	45	451	2026-10-14 17:03:37.272297+05:30
1124	177	451	2026-10-14 17:03:37.272303+05:30
1125	165	451	2026-10-14 17:03:37.272304+05:30
1136	45	456	2026-10-14 17:03:37.368996+05:30
1137	172	456	2026-10-14 17:03:37.369+05:30
1138	166	456	2026-10-14 17:03:37.369+05:30
1150	45	461	2026-10-14 17:03:37.465424+05:30
1151	175	461	2026-10-14 17:03:37.465428+05:30
1160	45	466	2026-10-14 17:03:37.557662+05:30
1161	169	466	2026-10-14 17:03:37.557666+05:30
1162	168	466	2026-10-14 17:03:37.557667+05:30
1172	45	471	2026-10-14 17:03:37.653305+05:30
1173	175	471	2026-10-14 17:03:37.653308+05:30
1184	45	476	2026-10-14 17:03:37.748918+05:30
1185	168	476	2026-10-14 17:03:37.748922+05:30
1186	177	476	2026-10-14 17:03:37.748923+05:30
1200	45	481	2026-10-14 17:03:37.846487+05:30
1201	168	481	2026-10-14 17:03:37.846491+05:30
1202	163	481	2026-10-14 17:03:37.846491+05:30
1213	45	486	2026-10-14 17:03:37.979877+05:30
1214	177	486	2026-10-14 17:03:37.979881+05:30
1226	45	491	2026-10-14 17:03:38.085033+05:30
1227	177	491	2026-10-14 17:03:38.085036+05:30
1228	165	491	2026-10-14 17:03:38.085037+05:30
1237	45	496	2026-10-14 17:03:38.186321+05:30
1238	176	496	2026-10-14 17:03:38.186325+05:30
1247	45	501	2026-10-14 17:03:38.280113+05:30
1248	168	501	2026-10-14 17:03:38.280116+05:30
1260	45	506	2026-10-14 17:03:38.378+05:30
1261	177	506	2026-10-14 17:03:38.378004+05:30
1270	45	511	2026-10-14 17:03:38.474511+05:30
1271	177	511	2026-10-14 17:03:38.474515+05:30
1282	45	516	2026-10-14 17:03:38.571403+05:30
1283	175	516	2026-10-14 17:03:38.571407+05:30
1294	45	521	2026-10-14 17:03:38.70025+05:30
1295	168	521	2026-10-14 17:03:38.700254+05:30
1306	45	526	2026-10-14 17:03:38.798826+05:30
1307	176	526	2026-10-14 17:03:38.79883+05:30
1316	45	531	2026-10-14 17:03:38.898198+05:30
1317	177	531	2026-10-14 17:03:38.898202+05:30
1325	45	536	2026-10-14 17:03:38.99357+05:30
1326	163	536	2026-10-14 17:03:38.993574+05:30
1336	45	541	2026-10-14 17:03:39.090182+05:30
1337	166	541	2026-10-14 17:03:39.090186+05:30
1338	177	541	2026-10-14 17:03:39.090187+05:30
1349	45	546	2026-10-14 17:03:39.19897+05:30
1350	168	546	2026-10-14 17:03:39.198973+05:30
1361	45	551	2026-10-14 17:03:39.294572+05:30
1362	177	551	2026-10-14 17:03:39.294575+05:30
1372	46	556	2026-10-14 17:03:39.390433+05:30
1373	171	556	2026-10-14 17:03:39.390437+05:30
1374	172	556	2026-10-14 17:03:39.390438+05:30
1375	175	556	2026-10-14 17:03:39.390439+05:30
1376	177	556	2026-10-14 17:03:39.39044+05:30
1387	48	561	2026-10-14 17:03:39.48228+05:30
1388	163	561	2026-10-14 17:03:39.482283+05:30
1875	107	752	2026-10-15 12:51:29.946413+05:30
1876	174	752	2026-10-15 12:51:29.946416+05:30
1885	109	757	2026-10-15 12:51:30.105472+05:30
1886	167	757	2026-10-15 12:51:30.105476+05:30
1896	109	762	2026-10-15 12:51:30.23906+05:30
1897	166	762	2026-10-15 12:51:30.239065+05:30
1907	109	767	2026-10-15 12:51:30.356642+05:30
1908	165	767	2026-10-15 12:51:30.356648+05:30
1922	109	772	2026-10-15 12:51:30.47574+05:30
1923	165	772	2026-10-15 12:51:30.475744+05:30
1924	176	772	2026-10-15 12:51:30.475745+05:30
1925	171	772	2026-10-15 12:51:30.475746+05:30
1936	109	777	2026-10-15 12:51:30.618769+05:30
1937	167	777	2026-10-15 12:51:30.618773+05:30
1949	109	782	2026-10-15 12:51:30.752285+05:30
1950	177	782	2026-10-15 12:51:30.752289+05:30
1951	168	782	2026-10-15 12:51:30.75229+05:30
1961	109	787	2026-10-15 12:51:30.863842+05:30
719	45	282	2026-10-14 17:03:33.972105+05:30
720	176	282	2026-10-14 17:03:33.972108+05:30
730	45	287	2026-10-14 17:03:34.069034+05:30
731	177	287	2026-10-14 17:03:34.069038+05:30
743	45	292	2026-10-14 17:03:34.170849+05:30
744	172	292	2026-10-14 17:03:34.170852+05:30
755	45	297	2026-10-14 17:03:34.267656+05:30
756	172	297	2026-10-14 17:03:34.267659+05:30
766	45	302	2026-10-14 17:03:34.36557+05:30
767	177	302	2026-10-14 17:03:34.365573+05:30
768	163	302	2026-10-14 17:03:34.365574+05:30
778	45	307	2026-10-14 17:03:34.463361+05:30
779	177	307	2026-10-14 17:03:34.463365+05:30
780	163	307	2026-10-14 17:03:34.463366+05:30
792	45	312	2026-10-14 17:03:34.557544+05:30
793	175	312	2026-10-14 17:03:34.557548+05:30
794	177	312	2026-10-14 17:03:34.557548+05:30
804	45	317	2026-10-14 17:03:34.65232+05:30
805	177	317	2026-10-14 17:03:34.652324+05:30
806	165	317	2026-10-14 17:03:34.652325+05:30
819	45	322	2026-10-14 17:03:34.747239+05:30
820	165	322	2026-10-14 17:03:34.747243+05:30
821	177	322	2026-10-14 17:03:34.747244+05:30
832	45	327	2026-10-14 17:03:34.843305+05:30
833	172	327	2026-10-14 17:03:34.843308+05:30
844	45	332	2026-10-14 17:03:34.940633+05:30
845	169	332	2026-10-14 17:03:34.940637+05:30
846	175	332	2026-10-14 17:03:34.940637+05:30
856	45	337	2026-10-14 17:03:35.042436+05:30
857	168	337	2026-10-14 17:03:35.042439+05:30
867	45	342	2026-10-14 17:03:35.145484+05:30
868	168	342	2026-10-14 17:03:35.145489+05:30
869	175	342	2026-10-14 17:03:35.145491+05:30
880	45	347	2026-10-14 17:03:35.250389+05:30
881	175	347	2026-10-14 17:03:35.250393+05:30
882	177	347	2026-10-14 17:03:35.250394+05:30
891	45	352	2026-10-14 17:03:35.356847+05:30
892	177	352	2026-10-14 17:03:35.356851+05:30
902	45	357	2026-10-14 17:03:35.459724+05:30
903	172	357	2026-10-14 17:03:35.459728+05:30
904	175	357	2026-10-14 17:03:35.459729+05:30
905	177	357	2026-10-14 17:03:35.45973+05:30
915	45	362	2026-10-14 17:03:35.563856+05:30
916	176	362	2026-10-14 17:03:35.563859+05:30
927	45	367	2026-10-14 17:03:35.662881+05:30
928	172	367	2026-10-14 17:03:35.662884+05:30
937	45	372	2026-10-14 17:03:35.756261+05:30
938	163	372	2026-10-14 17:03:35.756265+05:30
948	45	377	2026-10-14 17:03:35.85323+05:30
949	172	377	2026-10-14 17:03:35.853234+05:30
960	45	382	2026-10-14 17:03:35.952161+05:30
961	175	382	2026-10-14 17:03:35.952165+05:30
962	177	382	2026-10-14 17:03:35.952166+05:30
972	45	387	2026-10-14 17:03:36.051537+05:30
973	177	387	2026-10-14 17:03:36.05154+05:30
984	45	392	2026-10-14 17:03:36.148004+05:30
985	178	392	2026-10-14 17:03:36.148007+05:30
994	45	397	2026-10-14 17:03:36.244144+05:30
995	168	397	2026-10-14 17:03:36.244147+05:30
996	175	397	2026-10-14 17:03:36.244148+05:30
1006	45	402	2026-10-14 17:03:36.340347+05:30
1007	166	402	2026-10-14 17:03:36.340351+05:30
1016	45	407	2026-10-14 17:03:36.432773+05:30
1017	168	407	2026-10-14 17:03:36.432776+05:30
1028	45	412	2026-10-14 17:03:36.531962+05:30
1029	168	412	2026-10-14 17:03:36.531965+05:30
1042	45	417	2026-10-14 17:03:36.629669+05:30
1043	177	417	2026-10-14 17:03:36.629673+05:30
1054	45	422	2026-10-14 17:03:36.724272+05:30
1055	167	422	2026-10-14 17:03:36.724277+05:30
1056	174	422	2026-10-14 17:03:36.724278+05:30
1057	163	422	2026-10-14 17:03:36.72428+05:30
1068	45	427	2026-10-14 17:03:36.819093+05:30
1069	175	427	2026-10-14 17:03:36.819096+05:30
1078	45	432	2026-10-14 17:03:36.915443+05:30
1079	174	432	2026-10-14 17:03:36.915447+05:30
1091	45	437	2026-10-14 17:03:37.010775+05:30
1092	175	437	2026-10-14 17:03:37.010778+05:30
1093	177	437	2026-10-14 17:03:37.010779+05:30
1103	45	442	2026-10-14 17:03:37.10394+05:30
1104	166	442	2026-10-14 17:03:37.103943+05:30
1115	45	447	2026-10-14 17:03:37.196618+05:30
1116	177	447	2026-10-14 17:03:37.196621+05:30
1126	45	452	2026-10-14 17:03:37.291474+05:30
1127	169	452	2026-10-14 17:03:37.291478+05:30
1128	168	452	2026-10-14 17:03:37.291479+05:30
1139	45	457	2026-10-14 17:03:37.387272+05:30
1140	165	457	2026-10-14 17:03:37.387275+05:30
1141	177	457	2026-10-14 17:03:37.387276+05:30
1152	45	462	2026-10-14 17:03:37.484574+05:30
1153	177	462	2026-10-14 17:03:37.484577+05:30
1163	45	467	2026-10-14 17:03:37.577295+05:30
1164	175	467	2026-10-14 17:03:37.577299+05:30
1165	177	467	2026-10-14 17:03:37.5773+05:30
1174	45	472	2026-10-14 17:03:37.671006+05:30
1175	168	472	2026-10-14 17:03:37.671009+05:30
1187	45	477	2026-10-14 17:03:37.769908+05:30
1188	165	477	2026-10-14 17:03:37.769912+05:30
1189	177	477	2026-10-14 17:03:37.769912+05:30
1203	45	482	2026-10-14 17:03:37.86595+05:30
1204	175	482	2026-10-14 17:03:37.865954+05:30
1215	45	487	2026-10-14 17:03:38.000738+05:30
1216	177	487	2026-10-14 17:03:38.000741+05:30
1217	165	487	2026-10-14 17:03:38.000742+05:30
1229	45	492	2026-10-14 17:03:38.104965+05:30
1230	177	492	2026-10-14 17:03:38.104969+05:30
1239	45	497	2026-10-14 17:03:38.206267+05:30
1240	175	497	2026-10-14 17:03:38.20627+05:30
1249	45	502	2026-10-14 17:03:38.299736+05:30
1250	169	502	2026-10-14 17:03:38.299739+05:30
1251	176	502	2026-10-14 17:03:38.29974+05:30
1262	45	507	2026-10-14 17:03:38.396596+05:30
1263	177	507	2026-10-14 17:03:38.3966+05:30
1272	45	512	2026-10-14 17:03:38.494523+05:30
1273	177	512	2026-10-14 17:03:38.494528+05:30
1274	175	512	2026-10-14 17:03:38.494529+05:30
1284	45	517	2026-10-14 17:03:38.612546+05:30
1285	165	517	2026-10-14 17:03:38.61255+05:30
1286	166	517	2026-10-14 17:03:38.612552+05:30
1296	45	522	2026-10-14 17:03:38.718838+05:30
1297	168	522	2026-10-14 17:03:38.718841+05:30
1308	45	527	2026-10-14 17:03:38.819483+05:30
1309	177	527	2026-10-14 17:03:38.819487+05:30
1318	45	532	2026-10-14 17:03:38.917786+05:30
1327	45	537	2026-10-14 17:03:39.012311+05:30
1328	175	537	2026-10-14 17:03:39.012315+05:30
1339	45	542	2026-10-14 17:03:39.108827+05:30
1340	177	542	2026-10-14 17:03:39.108831+05:30
1341	168	542	2026-10-14 17:03:39.108832+05:30
1351	45	547	2026-10-14 17:03:39.218417+05:30
1352	177	547	2026-10-14 17:03:39.218421+05:30
1363	45	552	2026-10-14 17:03:39.312887+05:30
1364	171	552	2026-10-14 17:03:39.312891+05:30
1377	46	557	2026-10-14 17:03:39.409658+05:30
1378	176	557	2026-10-14 17:03:39.409663+05:30
1379	171	557	2026-10-14 17:03:39.409664+05:30
1389	48	562	2026-10-14 17:03:39.503075+05:30
1390	168	562	2026-10-14 17:03:39.503079+05:30
1391	171	562	2026-10-14 17:03:39.503079+05:30
1877	108	753	2026-10-15 12:51:29.973104+05:30
1878	163	753	2026-10-15 12:51:29.973108+05:30
1887	109	758	2026-10-15 12:51:30.133007+05:30
1888	178	758	2026-10-15 12:51:30.133012+05:30
1898	109	763	2026-10-15 12:51:30.260938+05:30
1899	172	763	2026-10-15 12:51:30.260943+05:30
1909	109	768	2026-10-15 12:51:30.380969+05:30
1910	169	768	2026-10-15 12:51:30.380972+05:30
1911	166	768	2026-10-15 12:51:30.380974+05:30
1926	109	773	2026-10-15 12:51:30.505109+05:30
1927	165	773	2026-10-15 12:51:30.505113+05:30
1928	177	773	2026-10-15 12:51:30.505114+05:30
1938	109	778	2026-10-15 12:51:30.654235+05:30
1939	171	778	2026-10-15 12:51:30.654241+05:30
1952	109	783	2026-10-15 12:51:30.77579+05:30
1953	171	783	2026-10-15 12:51:30.775795+05:30
1963	109	788	2026-10-15 12:51:30.88927+05:30
1964	177	788	2026-10-15 12:51:30.889274+05:30
721	45	283	2026-10-14 17:03:33.992323+05:30
722	175	283	2026-10-14 17:03:33.992326+05:30
732	45	288	2026-10-14 17:03:34.087998+05:30
733	163	288	2026-10-14 17:03:34.088002+05:30
734	167	288	2026-10-14 17:03:34.088003+05:30
745	45	293	2026-10-14 17:03:34.189442+05:30
746	175	293	2026-10-14 17:03:34.189445+05:30
757	45	298	2026-10-14 17:03:34.286171+05:30
758	163	298	2026-10-14 17:03:34.286174+05:30
769	45	303	2026-10-14 17:03:34.386032+05:30
770	177	303	2026-10-14 17:03:34.386035+05:30
781	45	308	2026-10-14 17:03:34.48267+05:30
782	177	308	2026-10-14 17:03:34.482674+05:30
795	45	313	2026-10-14 17:03:34.577415+05:30
796	177	313	2026-10-14 17:03:34.577419+05:30
807	45	318	2026-10-14 17:03:34.671046+05:30
808	177	318	2026-10-14 17:03:34.671049+05:30
809	175	318	2026-10-14 17:03:34.67105+05:30
822	45	323	2026-10-14 17:03:34.765207+05:30
823	163	323	2026-10-14 17:03:34.76521+05:30
834	45	328	2026-10-14 17:03:34.861767+05:30
835	167	328	2026-10-14 17:03:34.861775+05:30
836	169	328	2026-10-14 17:03:34.861776+05:30
847	45	333	2026-10-14 17:03:34.960469+05:30
848	176	333	2026-10-14 17:03:34.960472+05:30
849	168	333	2026-10-14 17:03:34.960473+05:30
858	45	338	2026-10-14 17:03:35.063699+05:30
859	164	338	2026-10-14 17:03:35.063703+05:30
870	45	343	2026-10-14 17:03:35.165148+05:30
871	177	343	2026-10-14 17:03:35.165151+05:30
872	165	343	2026-10-14 17:03:35.165152+05:30
883	45	348	2026-10-14 17:03:35.272576+05:30
884	168	348	2026-10-14 17:03:35.27258+05:30
893	45	353	2026-10-14 17:03:35.377339+05:30
894	168	353	2026-10-14 17:03:35.377343+05:30
906	45	358	2026-10-14 17:03:35.480905+05:30
907	172	358	2026-10-14 17:03:35.480909+05:30
908	168	358	2026-10-14 17:03:35.48091+05:30
917	45	363	2026-10-14 17:03:35.583277+05:30
918	168	363	2026-10-14 17:03:35.58328+05:30
929	45	368	2026-10-14 17:03:35.681271+05:30
930	177	368	2026-10-14 17:03:35.681274+05:30
939	45	373	2026-10-14 17:03:35.774034+05:30
940	168	373	2026-10-14 17:03:35.774038+05:30
941	175	373	2026-10-14 17:03:35.774039+05:30
950	45	378	2026-10-14 17:03:35.872516+05:30
951	163	378	2026-10-14 17:03:35.872519+05:30
952	175	378	2026-10-14 17:03:35.87252+05:30
963	45	383	2026-10-14 17:03:35.970811+05:30
964	166	383	2026-10-14 17:03:35.970814+05:30
974	45	388	2026-10-14 17:03:36.070303+05:30
975	177	388	2026-10-14 17:03:36.070306+05:30
986	45	393	2026-10-14 17:03:36.168025+05:30
987	163	393	2026-10-14 17:03:36.168028+05:30
997	45	398	2026-10-14 17:03:36.263517+05:30
998	177	398	2026-10-14 17:03:36.263521+05:30
1008	45	403	2026-10-14 17:03:36.358333+05:30
1009	176	403	2026-10-14 17:03:36.358337+05:30
1018	45	408	2026-10-14 17:03:36.453809+05:30
1019	172	408	2026-10-14 17:03:36.453813+05:30
1020	175	408	2026-10-14 17:03:36.453813+05:30
1030	45	413	2026-10-14 17:03:36.551935+05:30
1031	168	413	2026-10-14 17:03:36.551939+05:30
1032	163	413	2026-10-14 17:03:36.55194+05:30
1033	175	413	2026-10-14 17:03:36.55194+05:30
1044	45	418	2026-10-14 17:03:36.648849+05:30
1045	168	418	2026-10-14 17:03:36.648853+05:30
1046	165	418	2026-10-14 17:03:36.648854+05:30
1058	45	423	2026-10-14 17:03:36.745135+05:30
1059	177	423	2026-10-14 17:03:36.745139+05:30
1070	45	428	2026-10-14 17:03:36.838283+05:30
1071	175	428	2026-10-14 17:03:36.838287+05:30
1080	45	433	2026-10-14 17:03:36.933468+05:30
1081	174	433	2026-10-14 17:03:36.933471+05:30
1082	163	433	2026-10-14 17:03:36.933472+05:30
1094	45	438	2026-10-14 17:03:37.029299+05:30
1095	169	438	2026-10-14 17:03:37.029302+05:30
1105	45	443	2026-10-14 17:03:37.122748+05:30
1106	175	443	2026-10-14 17:03:37.122751+05:30
1117	45	448	2026-10-14 17:03:37.215853+05:30
1118	175	448	2026-10-14 17:03:37.215857+05:30
1129	45	453	2026-10-14 17:03:37.309326+05:30
1130	175	453	2026-10-14 17:03:37.30933+05:30
1131	177	453	2026-10-14 17:03:37.30933+05:30
1142	45	458	2026-10-14 17:03:37.40751+05:30
1143	177	458	2026-10-14 17:03:37.407514+05:30
1154	45	463	2026-10-14 17:03:37.502193+05:30
1155	177	463	2026-10-14 17:03:37.502196+05:30
1166	45	468	2026-10-14 17:03:37.597257+05:30
1167	172	468	2026-10-14 17:03:37.59726+05:30
1176	45	473	2026-10-14 17:03:37.690508+05:30
1177	167	473	2026-10-14 17:03:37.690511+05:30
1190	45	478	2026-10-14 17:03:37.788889+05:30
1191	175	478	2026-10-14 17:03:37.788892+05:30
1192	177	478	2026-10-14 17:03:37.788893+05:30
1205	45	483	2026-10-14 17:03:37.883922+05:30
1206	165	483	2026-10-14 17:03:37.883926+05:30
1218	45	488	2026-10-14 17:03:38.022133+05:30
1219	175	488	2026-10-14 17:03:38.022136+05:30
1231	45	493	2026-10-14 17:03:38.125115+05:30
1232	177	493	2026-10-14 17:03:38.125163+05:30
1241	45	498	2026-10-14 17:03:38.223366+05:30
1252	45	503	2026-10-14 17:03:38.319228+05:30
1253	172	503	2026-10-14 17:03:38.319231+05:30
1254	166	503	2026-10-14 17:03:38.319232+05:30
1264	45	508	2026-10-14 17:03:38.416036+05:30
1265	177	508	2026-10-14 17:03:38.416039+05:30
1275	45	513	2026-10-14 17:03:38.515582+05:30
1276	163	513	2026-10-14 17:03:38.515585+05:30
1287	45	518	2026-10-14 17:03:38.638748+05:30
1288	177	518	2026-10-14 17:03:38.638752+05:30
1298	45	523	2026-10-14 17:03:38.737748+05:30
1299	163	523	2026-10-14 17:03:38.737752+05:30
1300	165	523	2026-10-14 17:03:38.737753+05:30
1310	45	528	2026-10-14 17:03:38.838615+05:30
1311	175	528	2026-10-14 17:03:38.838618+05:30
1319	45	533	2026-10-14 17:03:38.936362+05:30
1320	177	533	2026-10-14 17:03:38.936367+05:30
1329	45	538	2026-10-14 17:03:39.032733+05:30
1330	172	538	2026-10-14 17:03:39.032736+05:30
1342	45	543	2026-10-14 17:03:39.128408+05:30
1343	163	543	2026-10-14 17:03:39.128412+05:30
1344	172	543	2026-10-14 17:03:39.128413+05:30
1353	45	548	2026-10-14 17:03:39.236802+05:30
1354	177	548	2026-10-14 17:03:39.236805+05:30
1365	45	553	2026-10-14 17:03:39.330058+05:30
1366	168	553	2026-10-14 17:03:39.330061+05:30
1380	46	558	2026-10-14 17:03:39.429914+05:30
1381	176	558	2026-10-14 17:03:39.429918+05:30
1382	171	558	2026-10-14 17:03:39.429918+05:30
1392	48	563	2026-10-14 17:03:39.522854+05:30
1393	165	563	2026-10-14 17:03:39.522858+05:30
1394	169	563	2026-10-14 17:03:39.522858+05:30
1395	166	563	2026-10-14 17:03:39.522859+05:30
1879	109	754	2026-10-15 12:51:29.999921+05:30
1880	175	754	2026-10-15 12:51:29.999924+05:30
1889	109	759	2026-10-15 12:51:30.155277+05:30
1890	165	759	2026-10-15 12:51:30.155281+05:30
1891	171	759	2026-10-15 12:51:30.155282+05:30
1900	109	764	2026-10-15 12:51:30.288432+05:30
1901	166	764	2026-10-15 12:51:30.288435+05:30
1912	109	769	2026-10-15 12:51:30.402963+05:30
1913	165	769	2026-10-15 12:51:30.402966+05:30
1914	168	769	2026-10-15 12:51:30.402967+05:30
1915	175	769	2026-10-15 12:51:30.402968+05:30
1929	109	774	2026-10-15 12:51:30.541033+05:30
1930	168	774	2026-10-15 12:51:30.541039+05:30
1931	166	774	2026-10-15 12:51:30.541041+05:30
1940	109	779	2026-10-15 12:51:30.682132+05:30
1941	171	779	2026-10-15 12:51:30.682136+05:30
1942	177	779	2026-10-15 12:51:30.682137+05:30
1954	109	784	2026-10-15 12:51:30.797638+05:30
1955	174	784	2026-10-15 12:51:30.797642+05:30
1956	163	784	2026-10-15 12:51:30.797643+05:30
1965	109	789	2026-10-15 12:51:30.921335+05:30
1966	177	789	2026-10-15 12:51:30.921342+05:30
1967	168	789	2026-10-15 12:51:30.921343+05:30
723	45	284	2026-10-14 17:03:34.012091+05:30
724	177	284	2026-10-14 17:03:34.012095+05:30
735	45	289	2026-10-14 17:03:34.107654+05:30
736	175	289	2026-10-14 17:03:34.107657+05:30
747	45	294	2026-10-14 17:03:34.208797+05:30
748	169	294	2026-10-14 17:03:34.208801+05:30
759	45	299	2026-10-14 17:03:34.305608+05:30
760	163	299	2026-10-14 17:03:34.305612+05:30
771	45	304	2026-10-14 17:03:34.404031+05:30
772	172	304	2026-10-14 17:03:34.404035+05:30
783	45	309	2026-10-14 17:03:34.502418+05:30
784	175	309	2026-10-14 17:03:34.502421+05:30
785	177	309	2026-10-14 17:03:34.502422+05:30
797	45	314	2026-10-14 17:03:34.597347+05:30
798	175	314	2026-10-14 17:03:34.59735+05:30
810	45	319	2026-10-14 17:03:34.689159+05:30
811	177	319	2026-10-14 17:03:34.689163+05:30
812	175	319	2026-10-14 17:03:34.689163+05:30
824	45	324	2026-10-14 17:03:34.783226+05:30
825	163	324	2026-10-14 17:03:34.783232+05:30
837	45	329	2026-10-14 17:03:34.881845+05:30
838	176	329	2026-10-14 17:03:34.881849+05:30
850	45	334	2026-10-14 17:03:34.980787+05:30
851	163	334	2026-10-14 17:03:34.98079+05:30
860	45	339	2026-10-14 17:03:35.08604+05:30
861	177	339	2026-10-14 17:03:35.086044+05:30
873	45	344	2026-10-14 17:03:35.187311+05:30
874	175	344	2026-10-14 17:03:35.187315+05:30
885	45	349	2026-10-14 17:03:35.292667+05:30
886	163	349	2026-10-14 17:03:35.29267+05:30
895	45	354	2026-10-14 17:03:35.398386+05:30
896	163	354	2026-10-14 17:03:35.398389+05:30
909	45	359	2026-10-14 17:03:35.501715+05:30
910	167	359	2026-10-14 17:03:35.501719+05:30
919	45	364	2026-10-14 17:03:35.601406+05:30
920	175	364	2026-10-14 17:03:35.601409+05:30
921	177	364	2026-10-14 17:03:35.60141+05:30
931	45	369	2026-10-14 17:03:35.700927+05:30
932	177	369	2026-10-14 17:03:35.700931+05:30
942	45	374	2026-10-14 17:03:35.794237+05:30
943	177	374	2026-10-14 17:03:35.794241+05:30
953	45	379	2026-10-14 17:03:35.891204+05:30
954	168	379	2026-10-14 17:03:35.891208+05:30
965	45	384	2026-10-14 17:03:35.990152+05:30
966	175	384	2026-10-14 17:03:35.990156+05:30
976	45	389	2026-10-14 17:03:36.08987+05:30
977	172	389	2026-10-14 17:03:36.089873+05:30
978	169	389	2026-10-14 17:03:36.089874+05:30
988	45	394	2026-10-14 17:03:36.186257+05:30
989	177	394	2026-10-14 17:03:36.186261+05:30
999	45	399	2026-10-14 17:03:36.282897+05:30
1000	163	399	2026-10-14 17:03:36.2829+05:30
1001	172	399	2026-10-14 17:03:36.282901+05:30
1010	45	404	2026-10-14 17:03:36.377594+05:30
1011	169	404	2026-10-14 17:03:36.377599+05:30
1021	45	409	2026-10-14 17:03:36.472414+05:30
1022	165	409	2026-10-14 17:03:36.472417+05:30
1034	45	414	2026-10-14 17:03:36.570219+05:30
1035	168	414	2026-10-14 17:03:36.570222+05:30
1047	45	419	2026-10-14 17:03:36.668671+05:30
1048	177	419	2026-10-14 17:03:36.668674+05:30
1049	165	419	2026-10-14 17:03:36.668675+05:30
1060	45	424	2026-10-14 17:03:36.764261+05:30
1061	177	424	2026-10-14 17:03:36.764265+05:30
1062	175	424	2026-10-14 17:03:36.764266+05:30
1063	166	424	2026-10-14 17:03:36.764266+05:30
1072	45	429	2026-10-14 17:03:36.856836+05:30
1073	177	429	2026-10-14 17:03:36.85684+05:30
1083	45	434	2026-10-14 17:03:36.952805+05:30
1084	172	434	2026-10-14 17:03:36.952808+05:30
1085	175	434	2026-10-14 17:03:36.952809+05:30
1096	45	439	2026-10-14 17:03:37.048388+05:30
1097	175	439	2026-10-14 17:03:37.048392+05:30
1098	177	439	2026-10-14 17:03:37.048393+05:30
1107	45	444	2026-10-14 17:03:37.140275+05:30
1108	175	444	2026-10-14 17:03:37.140279+05:30
1119	45	449	2026-10-14 17:03:37.235903+05:30
1120	177	449	2026-10-14 17:03:37.235906+05:30
1132	45	454	2026-10-14 17:03:37.328357+05:30
1133	165	454	2026-10-14 17:03:37.328361+05:30
1144	45	459	2026-10-14 17:03:37.425183+05:30
1145	177	459	2026-10-14 17:03:37.425187+05:30
1146	165	459	2026-10-14 17:03:37.425188+05:30
1156	45	464	2026-10-14 17:03:37.520148+05:30
1157	165	464	2026-10-14 17:03:37.520151+05:30
1168	45	469	2026-10-14 17:03:37.616103+05:30
1169	177	469	2026-10-14 17:03:37.616107+05:30
1178	45	474	2026-10-14 17:03:37.709839+05:30
1179	163	474	2026-10-14 17:03:37.709842+05:30
1193	45	479	2026-10-14 17:03:37.808021+05:30
1194	174	479	2026-10-14 17:03:37.808025+05:30
1195	172	479	2026-10-14 17:03:37.808026+05:30
1196	177	479	2026-10-14 17:03:37.808027+05:30
1207	45	484	2026-10-14 17:03:37.906011+05:30
1208	165	484	2026-10-14 17:03:37.906015+05:30
1209	168	484	2026-10-14 17:03:37.906017+05:30
1220	45	489	2026-10-14 17:03:38.041993+05:30
1221	168	489	2026-10-14 17:03:38.041996+05:30
1222	172	489	2026-10-14 17:03:38.041997+05:30
1223	163	489	2026-10-14 17:03:38.041998+05:30
1233	45	494	2026-10-14 17:03:38.144317+05:30
1234	163	494	2026-10-14 17:03:38.14432+05:30
1242	45	499	2026-10-14 17:03:38.241105+05:30
1243	175	499	2026-10-14 17:03:38.241108+05:30
1244	177	499	2026-10-14 17:03:38.241109+05:30
1255	45	504	2026-10-14 17:03:38.33987+05:30
1256	172	504	2026-10-14 17:03:38.339878+05:30
1257	177	504	2026-10-14 17:03:38.339879+05:30
1266	45	509	2026-10-14 17:03:38.43662+05:30
1267	176	509	2026-10-14 17:03:38.436624+05:30
1277	45	514	2026-10-14 17:03:38.535232+05:30
1278	167	514	2026-10-14 17:03:38.535235+05:30
1289	45	519	2026-10-14 17:03:38.660777+05:30
1290	177	519	2026-10-14 17:03:38.660781+05:30
1301	45	524	2026-10-14 17:03:38.756477+05:30
1302	163	524	2026-10-14 17:03:38.756481+05:30
1312	45	529	2026-10-14 17:03:38.858839+05:30
1313	177	529	2026-10-14 17:03:38.858843+05:30
1321	45	534	2026-10-14 17:03:38.956347+05:30
1322	165	534	2026-10-14 17:03:38.956351+05:30
1331	45	539	2026-10-14 17:03:39.052446+05:30
1332	172	539	2026-10-14 17:03:39.05245+05:30
1333	177	539	2026-10-14 17:03:39.05245+05:30
1345	45	544	2026-10-14 17:03:39.148707+05:30
1346	169	544	2026-10-14 17:03:39.148711+05:30
1355	45	549	2026-10-14 17:03:39.255758+05:30
1356	169	549	2026-10-14 17:03:39.255762+05:30
1357	165	549	2026-10-14 17:03:39.255763+05:30
1367	46	554	2026-10-14 17:03:39.349476+05:30
1368	175	554	2026-10-14 17:03:39.349479+05:30
1369	165	554	2026-10-14 17:03:39.34948+05:30
1383	47	559	2026-10-14 17:03:39.446446+05:30
1396	48	564	2026-10-14 17:03:39.542047+05:30
1397	165	564	2026-10-14 17:03:39.54205+05:30
1398	169	564	2026-10-14 17:03:39.542051+05:30
1399	171	564	2026-10-14 17:03:39.542052+05:30
1881	109	755	2026-10-15 12:51:30.042723+05:30
1882	175	755	2026-10-15 12:51:30.042727+05:30
1892	109	760	2026-10-15 12:51:30.189052+05:30
1893	175	760	2026-10-15 12:51:30.189055+05:30
1902	109	765	2026-10-15 12:51:30.310488+05:30
1903	177	765	2026-10-15 12:51:30.310491+05:30
1916	109	770	2026-10-15 12:51:30.431087+05:30
1917	166	770	2026-10-15 12:51:30.431115+05:30
1932	109	775	2026-10-15 12:51:30.567063+05:30
1933	177	775	2026-10-15 12:51:30.567068+05:30
1943	109	780	2026-10-15 12:51:30.708996+05:30
1944	176	780	2026-10-15 12:51:30.708999+05:30
1945	168	780	2026-10-15 12:51:30.709+05:30
1946	171	780	2026-10-15 12:51:30.709001+05:30
1957	109	785	2026-10-15 12:51:30.820486+05:30
1958	165	785	2026-10-15 12:51:30.82049+05:30
1968	109	790	2026-10-15 12:51:30.953871+05:30
1969	175	790	2026-10-15 12:51:30.953875+05:30
1981	112	795	2026-10-15 12:51:31.057836+05:30
1982	168	795	2026-10-15 12:51:31.057852+05:30
1983	171	795	2026-10-15 12:51:31.057853+05:30
\.


--
-- Data for Name: site_figures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.site_figures (id, account_id, start_date, end_date, site_figure, calculated_by, calculated_at) FROM stdin;
\.


--
-- Name: account_websites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_websites_id_seq', 988, true);


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_id_seq', 988, true);


--
-- Name: figures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.figures_id_seq', 8, true);


--
-- Name: parties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parties_id_seq', 183, true);


--
-- Name: party_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.party_accounts_id_seq', 2475, true);


--
-- Name: site_figures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.site_figures_id_seq', 1, false);


--
-- Name: account_websites account_websites_account_id_website_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_websites
    ADD CONSTRAINT account_websites_account_id_website_key UNIQUE (account_id, website);


--
-- Name: account_websites account_websites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_websites
    ADD CONSTRAINT account_websites_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: admin_credentials admin_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_credentials
    ADD CONSTRAINT admin_credentials_pkey PRIMARY KEY (id);


--
-- Name: admin_credentials admin_credentials_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_credentials
    ADD CONSTRAINT admin_credentials_username_key UNIQUE (username);


--
-- Name: figures figures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.figures
    ADD CONSTRAINT figures_pkey PRIMARY KEY (id);


--
-- Name: parties parties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parties
    ADD CONSTRAINT parties_pkey PRIMARY KEY (id);


--
-- Name: party_accounts party_accounts_party_id_account_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.party_accounts
    ADD CONSTRAINT party_accounts_party_id_account_id_key UNIQUE (party_id, account_id);


--
-- Name: party_accounts party_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.party_accounts
    ADD CONSTRAINT party_accounts_pkey PRIMARY KEY (id);


--
-- Name: site_figures site_figures_account_id_start_date_end_date_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_figures
    ADD CONSTRAINT site_figures_account_id_start_date_end_date_key UNIQUE (account_id, start_date, end_date);


--
-- Name: site_figures site_figures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_figures
    ADD CONSTRAINT site_figures_pkey PRIMARY KEY (id);


--
-- Name: ix_account_websites_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_account_websites_account_id ON public.account_websites USING btree (account_id);


--
-- Name: ix_account_websites_website; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_account_websites_website ON public.account_websites USING btree (website);


--
-- Name: ix_figures_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_figures_account_id ON public.figures USING btree (account_id);


--
-- Name: ix_figures_figure_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_figures_figure_date ON public.figures USING btree (figure_date);


--
-- Name: ix_figures_lookup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_figures_lookup ON public.figures USING btree (party_id, account_id, start_date, end_date);


--
-- Name: ix_figures_party_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_figures_party_id ON public.figures USING btree (party_id);


--
-- Name: ix_figures_start_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_figures_start_date ON public.figures USING btree (start_date);


--
-- Name: ix_parties_kind; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_parties_kind ON public.parties USING btree (kind);


--
-- Name: ix_parties_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_parties_name_key ON public.parties USING btree (name_key);


--
-- Name: ix_party_accounts_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_party_accounts_account_id ON public.party_accounts USING btree (account_id);


--
-- Name: ix_party_accounts_party_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_party_accounts_party_id ON public.party_accounts USING btree (party_id);


--
-- Name: ix_site_figures_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_site_figures_account_id ON public.site_figures USING btree (account_id);


--
-- Name: ix_site_figures_start_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_site_figures_start_date ON public.site_figures USING btree (start_date);


--
-- Name: uq_capper_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_capper_name ON public.parties USING btree (name_key) WHERE (kind = 'capper'::public.partykind);


--
-- Name: account_websites account_websites_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_websites
    ADD CONSTRAINT account_websites_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: figures figures_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.figures
    ADD CONSTRAINT figures_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: figures figures_entered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.figures
    ADD CONSTRAINT figures_entered_by_fkey FOREIGN KEY (entered_by) REFERENCES public.admin_credentials(id);


--
-- Name: figures figures_party_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.figures
    ADD CONSTRAINT figures_party_id_fkey FOREIGN KEY (party_id) REFERENCES public.parties(id);


--
-- Name: party_accounts party_accounts_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.party_accounts
    ADD CONSTRAINT party_accounts_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: party_accounts party_accounts_party_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.party_accounts
    ADD CONSTRAINT party_accounts_party_id_fkey FOREIGN KEY (party_id) REFERENCES public.parties(id);


--
-- Name: site_figures site_figures_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_figures
    ADD CONSTRAINT site_figures_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: site_figures site_figures_calculated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.site_figures
    ADD CONSTRAINT site_figures_calculated_by_fkey FOREIGN KEY (calculated_by) REFERENCES public.admin_credentials(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict vVfY2LDKcZ1g6bLSzD8vqJVXDvQASrHS0NeHGcUEGbJtqJocN0TieLeFV81WlIt

