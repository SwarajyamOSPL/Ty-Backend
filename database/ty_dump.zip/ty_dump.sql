--
-- PostgreSQL database dump
--

\restrict hbDPAkfquavoQQQypFoytg9zmaDnPW9ThVzteApq17u9C16NVHzcvbwGBGZgzUs

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: partykind; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.partykind AS ENUM (
    'partner',
    'capper'
);


ALTER TYPE public.partykind OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    website character varying(255) NOT NULL,
    username character varying(255),
    password_enc text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounts_id_seq OWNER TO postgres;

--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: admin_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_credentials (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    CONSTRAINT single_admin CHECK ((id = 1))
);


ALTER TABLE public.admin_credentials OWNER TO postgres;

--
-- Name: figures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.figures (
    id integer NOT NULL,
    party_id integer NOT NULL,
    account_id integer NOT NULL,
    amount numeric(14,2) NOT NULL,
    figure_date date NOT NULL,
    entered_by integer,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.figures OWNER TO postgres;

--
-- Name: figures_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.figures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.figures_id_seq OWNER TO postgres;

--
-- Name: figures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.figures_id_seq OWNED BY public.figures.id;


--
-- Name: parties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parties (
    id integer NOT NULL,
    kind public.partykind NOT NULL,
    name character varying(255) NOT NULL,
    name_key character varying(255) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.parties OWNER TO postgres;

--
-- Name: parties_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parties_id_seq OWNER TO postgres;

--
-- Name: parties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parties_id_seq OWNED BY public.parties.id;


--
-- Name: party_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.party_accounts (
    id integer NOT NULL,
    party_id integer NOT NULL,
    account_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.party_accounts OWNER TO postgres;

--
-- Name: party_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.party_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.party_accounts_id_seq OWNER TO postgres;

--
-- Name: party_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.party_accounts_id_seq OWNED BY public.party_accounts.id;


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: figures id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.figures ALTER COLUMN id SET DEFAULT nextval('public.figures_id_seq'::regclass);


--
-- Name: parties id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parties ALTER COLUMN id SET DEFAULT nextval('public.parties_id_seq'::regclass);


--
-- Name: party_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.party_accounts ALTER COLUMN id SET DEFAULT nextval('public.party_accounts_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, website, username, password_enc, created_at) FROM stdin;
\.


--
-- Data for Name: admin_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_credentials (id, username, password_hash) FROM stdin;
1	admin	bb6d8779958b1817d1ec4651e15cb250$fbe903a2a8f992250216f743eec0a1ed224bcf0e236f5e1aaadc74311bce90d1
\.


--
-- Data for Name: figures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.figures (id, party_id, account_id, amount, figure_date, entered_by, created_at) FROM stdin;
\.


--
-- Data for Name: parties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parties (id, kind, name, name_key, created_at) FROM stdin;
\.


--
-- Data for Name: party_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.party_accounts (id, party_id, account_id, created_at) FROM stdin;
\.


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_id_seq', 1, false);


--
-- Name: figures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.figures_id_seq', 1, false);


--
-- Name: parties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parties_id_seq', 1, false);


--
-- Name: party_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.party_accounts_id_seq', 1, false);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: admin_credentials admin_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_credentials
    ADD CONSTRAINT admin_credentials_pkey PRIMARY KEY (id);


--
-- Name: admin_credentials admin_credentials_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_credentials
    ADD CONSTRAINT admin_credentials_username_key UNIQUE (username);


--
-- Name: figures figures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.figures
    ADD CONSTRAINT figures_pkey PRIMARY KEY (id);


--
-- Name: parties parties_kind_name_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parties
    ADD CONSTRAINT parties_kind_name_key_key UNIQUE (kind, name_key);


--
-- Name: parties parties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parties
    ADD CONSTRAINT parties_pkey PRIMARY KEY (id);


--
-- Name: party_accounts party_accounts_party_id_account_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.party_accounts
    ADD CONSTRAINT party_accounts_party_id_account_id_key UNIQUE (party_id, account_id);


--
-- Name: party_accounts party_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.party_accounts
    ADD CONSTRAINT party_accounts_pkey PRIMARY KEY (id);


--
-- Name: ix_accounts_website; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_accounts_website ON public.accounts USING btree (website);


--
-- Name: ix_figures_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_figures_account_id ON public.figures USING btree (account_id);


--
-- Name: ix_figures_figure_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_figures_figure_date ON public.figures USING btree (figure_date);


--
-- Name: ix_figures_party_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_figures_party_id ON public.figures USING btree (party_id);


--
-- Name: ix_parties_kind; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_parties_kind ON public.parties USING btree (kind);


--
-- Name: ix_parties_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_parties_name_key ON public.parties USING btree (name_key);


--
-- Name: ix_party_accounts_account_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_party_accounts_account_id ON public.party_accounts USING btree (account_id);


--
-- Name: ix_party_accounts_party_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_party_accounts_party_id ON public.party_accounts USING btree (party_id);


--
-- Name: figures figures_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.figures
    ADD CONSTRAINT figures_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: figures figures_entered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.figures
    ADD CONSTRAINT figures_entered_by_fkey FOREIGN KEY (entered_by) REFERENCES public.admin_credentials(id);


--
-- Name: figures figures_party_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.figures
    ADD CONSTRAINT figures_party_id_fkey FOREIGN KEY (party_id) REFERENCES public.parties(id);


--
-- Name: party_accounts party_accounts_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.party_accounts
    ADD CONSTRAINT party_accounts_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: party_accounts party_accounts_party_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.party_accounts
    ADD CONSTRAINT party_accounts_party_id_fkey FOREIGN KEY (party_id) REFERENCES public.parties(id);


--
-- PostgreSQL database dump complete
--

\unrestrict hbDPAkfquavoQQQypFoytg9zmaDnPW9ThVzteApq17u9C16NVHzcvbwGBGZgzUs

